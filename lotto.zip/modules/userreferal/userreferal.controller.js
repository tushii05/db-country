﻿const express = require('express');
const router = express.Router();
const db = require('../../_helpers/db');
const Joi = require('joi');
const { validateRequest } = require('../../_middleware/validate-request');
const userReferalService = require('./userreferal.service');
module.exports = router;


router.get('/', getAllSchema, getAll);
router.post('/store', storeSchema, store);
router.get('/:id', getById);
router.put('/update', update);
module.exports = router;

function getAllSchema(req, res, next) {
    const schema = Joi.object({
        offset: Joi.number().integer().min(0).empty(''),
        limit: Joi.number().integer().min(1).empty(''),
        orderBy: Joi.string().valid('id', 'createdAt', 'ticket_number').empty(''),
        orderType: Joi.string().valid('DESC', 'ASC').empty(''),
        search: Joi.string().empty(''),
    });
    validateRequest(req, next, schema, 'query');
}
function getAll(req, res, next) {
    userReferalService.getAll(req.query)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}


async function store(req, res, next) {
    const data = req.body;
    const createdRecords = [];
    const commissionTypes = data.map((item) => item.commission_type);
    await db.Referral.destroy({ where: { commission_type: commissionTypes } });

    for (const item of data) {
        const record = await userReferalService.create(item);
        createdRecords.push(record);
    }
    res.json({ message: 'Success', data: createdRecords });
}


function storeSchema(req, res, next) {
    const schema = Joi.array().items(
        Joi.object({
            level: Joi.string().required(),
            percent: Joi.number().required(),
            commission_type: Joi.string().required(),
        })
    );
    validateRequest(req, next, schema);
}


function getById(req, res, next) {
    userReferalService.getById(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function update(req, res, next) {
    const params = { commission_type: req.body.commission_type, status: req.body.status };
    userReferalService.update(params)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}
