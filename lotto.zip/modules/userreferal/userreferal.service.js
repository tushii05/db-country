﻿const db = require('../../_helpers/db');
module.exports = {
    getAll,
    getById,
    create,
    update
};

async function getAll({ offset = 0, limit = 100, orderBy = 'id', orderType = 'DESC' }) {
    return await db.Referral.findAll({
        offset: parseInt(offset),
        limit: parseInt(limit),
        order: [[orderBy, orderType]]
    });
}

async function getById(id) {
    return await getById(id);
}

async function create(params) {
    const d = await db.Referral.create(params);
    return d;
}

//Helper Function 

async function getById(id) {
    const referral = await db.Referral.findByPk(id);
    if (!referral) throw 'referral not found';
    return referral;
}

async function update(params) {
    const referrals = await db.Referral.findAll({ where: { commission_type: params.commission_type } });
    if (!referrals || referrals.length === 0) throw 'referrals not found';
    for (const referral of referrals) {
        Object.assign(referral, { status: params.status });
        await referral.save();
    }
    return referrals;
}