const { DataTypes, literal } = require('sequelize');

module.exports = model;

function model(sequelize) {
    const attributes = {
        level: { type: DataTypes.STRING, allowNull: false },
        percent: { type: DataTypes.STRING, allowNull: false },
        commission_type: { type: DataTypes.STRING, allowNull: false, comment: "0: Buy, 1: Win, 2: Deposit" },
        status: { type: DataTypes.TINYINT, allowNull: true, defaultValue: 0, comment: "0: Disable, 1: Enable" },
    };
    const options = {
        defaultScope: {
            // exclude hash by default
            attributes: { exclude: [''] }
        },
        scopes: {
            // include hash with this scope
            withHash: { attributes: {}, }
        }
    };
    return sequelize.define('Referral', attributes, options);
}