﻿const express = require('express');
const router = express.Router();
const Joi = require('joi');
const { validateRequest } = require('../../_middleware/validate-request');
const authorize = require('../../_middleware/user');
const lotteryPhaseService = require('./gamephase.service');

// routes
router.post('/store', storeSchema, store);
router.get('/', getAllSchema, getAll);
router.get('/:id', getById);
router.put('/:id', update);
router.delete('/:id', authorize.admin(), _delete);

module.exports = router;



function storeSchema(req, res, next) {
    const schema = Joi.object({
        gameInformationId: Joi.number().integer().required(),
        game: Joi.string().required(),
        gameData: Joi.string().required(),
    });
    validateRequest(req, next, schema);
}

function store(req, res, next) {
    lotteryPhaseService
        .create(req.body)
        .then(data => { res.json({ message: 'Success', data }) })
        .catch(next);
}

function getAllSchema(req, res, next) {
    const schema = Joi.object({
        offset: Joi.number().integer().min(0).empty(''),
        limit: Joi.number().integer().min(1).empty(''),
        orderBy: Joi.string().valid('id', 'createdAt', 'game').empty(''),
        orderType: Joi.string().valid('DESC', 'ASC').empty(''),
        search: Joi.string().empty(''),
    });
    validateRequest(req, next, schema, 'query');
}

function getAll(req, res, next) {
    lotteryPhaseService.getAll(req.query)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function getById(req, res, next) {
    lotteryPhaseService.getById(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function update(req, res, next) {
    console.warn('update calling.....')
    lotteryPhaseService.update(req.params.id, req.body)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function _delete(req, res, next) {
    lotteryPhaseService.delete(req.user, req.params.id)
        .then(() => res.json({ message: 'Success' }))
        .catch(next);
}

// Helper functions Tushar_🙂🙂🙂🙂
