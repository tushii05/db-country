const { DataTypes, literal } = require('sequelize');

module.exports = model;

function model(sequelize) {
    const attributes = {
        userId: { type: DataTypes.TINYINT, allowNull: false },
        game: { type: DataTypes.STRING, allowNull: false },
        gameData: { type: DataTypes.TEXT, allowNull: false },
        status: { type: DataTypes.TINYINT, allowNull: false,defaultValue : 0 }
    };

    const options = {
        defaultScope: {
            attributes: { exclude: [] }
        },
        scopes: {
            withHash: { attributes: {} }
        }
    };

    return sequelize.define('gamePhase', attributes, options);
}