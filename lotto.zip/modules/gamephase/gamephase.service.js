﻿const db = require('../../_helpers/db');
const { Sequelize, literal } = require('sequelize');
const { Op } = require("sequelize");


module.exports = {
    getAll,
    getById,
    create,
    update,
    delete: _delete
};


async function getAll({ offset = 0, limit = 100, orderBy = 'id', orderType = 'DESC', search = null }) {
    let where = {};
    if (search !== null) {
        where = {
            [Op.or]: [
                { game: { [Op.like]: `%${search}%` } },
                { '$gameInformation.gameName$': { [Op.like]: `%${search}%` } }
            ]
        }

    }
    return await db.GamePhase.findAndCountAll({

        include: [{
            model: db.GameInfo,
        }],
        where,
        offset: parseInt(offset),
        limit: parseInt(limit),
        order: [[orderBy, orderType]]
    });
}

async function getById(id) {
    return await getGamePhase(id);
}

async function create(params) {
    params.userId = 1;
    params.status = 1;
    // if(!user) throw 'unauthorize';
    const d = await db.GamePhase.create(params);
    return d;
}
// helper functions

async function getGamePhase(id) {
    const lottery = await db.GamePhase.findOne({
        where: { id: id },
        include: [{
            model: db.GameInfo,
        }]
    });

    if (!lottery) throw 'Game Phase not found ';
    return lottery;
}


async function update(id, params) {
    const lottery = await db.GamePhase.findOne({ where: { id: id } });
    console.warn('lottery:-', lottery)
    lottery.userId = 1;
    lottery.status = params.status;
    if (!lottery) throw 'Game Phase not found'
    console.warn('lottery:- ', lottery)
    Object.assign(lottery, params);
    return await lottery.save();
}


async function _delete(user, id) {
    if (!user) throw 'unauthorize';
    const lottery = await getGamePhase(id);
    await lottery.destroy();
}
