﻿const db = require('../../_helpers/db');
const { Sequelize, literal } = require('sequelize');
const { Op } = require("sequelize");
const { sendEmail } = require('../../_middleware/email');
const moment = require('moment')
const { generateRandom } = require("../../_middleware/random-number");


module.exports = {
    getAll,
    getById,
    create,
    update,
    delete: _delete,
    getAllWithPhase
};


async function getAll({ offset = 0, limit = 100, orderBy = 'id', orderType = 'DESC', search = null }) {
    let where = {};
    if (search !== null) {
        where = {
            [Op.or]: [
                {
                    gameName: { [Op.like]: `%${search}%` }
                }
            ]
        }
    }
    const gameInfoCount = await db.GameInfo.count({
        where
    });

    return await db.GameInfo.findAll({
        where,
        include: [
            { model: db.generateRandomNoLottery },
            { model: db.GamePhase },
            { model: db.Currency },
            // { model: db.Timezone },
        ],
        offset: parseInt(offset),
        limit: parseInt(limit),
        order: [[orderBy, orderType]]
    }).then((rows) => {
        return {
            count: gameInfoCount,
            rows
        };
    });
}


async function getAllWithPhase({ offset = 0, limit = 100, orderBy = 'id', orderType = 'DESC', search = null }) {
    let where = {};
    if (search !== null) {
        where = {
            [Op.or]: [
                { gameName: { [Op.like]: `%${search}%` } }
            ]
        }
    }
    return await db.GameInfo.findAndCountAll({
        where,
        include: [{ model: db.GamePhase },
        { model: db.Currency },
            // { model: db.Timezone }
        ],
        offset: parseInt(offset),
        limit: parseInt(limit),
        order: [[orderBy, orderType]]
    });
}

async function getById(id) {
    return await getLottery(id);
}


function getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
}

// async function generateRandom(min = 1000000000, max = 9999999999) {
//     return new Promise((resolve, reject) => {
//         const range = max - min;
//         const bytes = Math.ceil(Math.log2(range) / 8);
//         const hash = crypto.createHash('sha1');
//         hash.update(crypto.randomBytes(bytes));
//         const random = hash.digest().readUIntBE(0, bytes);
//         const number = min + (random % range);
//         resolve(number);
//     });
// }


// async function generateRandomLoop(length, id) {
//     let numbers = [];
//     for (let i = 1; i <= length; i++) {
//         let number = await generateRandom();
//         while (numbers.includes(number)) {
//             number = await generateRandom();
//         }
//         numbers.push(number);
//     }
//     if (numbers.length > 0) {
//         for (const number of numbers) {
//             try {
//                 let data = await db.generateRandomNoLottery.findOne({ where: { number: number, gameInformationId: id } });
//                 if (!data) {
//                     await db.generateRandomNoLottery.create({ number: number, gameInformationId: id });
//                 } else {
//                     i--;
//                 }
//             } catch (error) {
//                 console.error(error);
//             }
//         }
//     }
// }

async function generateRandomLoop(length, id) {
    let generatedNumbers = new Set();
    while (generatedNumbers.size < length) {
        let number = await generateRandom();
        try {
            let data = await db.generateRandomNoLottery.findOne({ where: { number: number, gameInformationId: id } });
            if (!data) {
                await db.generateRandomNoLottery.create({ number: number, gameInformationId: id });
                generatedNumbers.add(number);
            }
        } catch (error) {
            console.error(error);
        }
    }
}

function convertLocalTimeToUTC(localTime, timeZone) {
    const localDateTime = moment.tz(localTime, 'HH:mm', timeZone);
    const utcDateTime = localDateTime.utc().format('HH:mm');
    return utcDateTime;
}

async function create(params) {
    params.userId = 1;
    console.log(params.startTime, "params.startTime")

    const localTime = params.startTime;
    const timeZone = params.timeZone;
    const startTimeUtc = convertLocalTimeToUTC(localTime, timeZone);
    params.startTime = startTimeUtc;
    console.log(params.startTime, "params.startTime")
    console.log(params.timeZone, "params.timeZone")

    const d = await db.GameInfo.create(params);
    generateRandomLoop(params.maxNumberTickets, d.id);

    const users = await db.User.findAll();
    const emailPromises = users.map(async (user) => {

        const html = `Dear <b>${user.fname} ${user.lname}</b>, <br> <br> We are super excited to announce our new <b>${params.gameName}</b> with only <b>${params.maxNumberTickets}</b> tickets <br> to sale whose drawings are starting on Date is <b>${params.gameDuration}<b> Time is <b>${params.startTime}</b>. 
        <br>
        Hurry up and grab your tickets to jackpot soon.
        <br>
        Want to know the winning and other details about the <b>${params.gameName}</b>? <br>
        <a href="${process.env.ASSET_URL}/lotteries" >Click Here</a> to see and play now.
        <br>
        The team Lifetime Lotto.`;
        const subject = "New lottery created";
        await sendEmail(user.email, subject, html);
    });

    await Promise.all(emailPromises);
    return { message: 'Game created successfully', data: d };
}


// Helper functions Tushar_🙂🙂🙂🙂

async function getLottery(id) {
    const lottery = await db.GameInfo.findOne({
        where: { id: id },
        include: [{ model: db.GamePhase }, { model: db.Currency },
        //  { model: db.Timezone }, 
        { model: db.generateRandomNoLottery }]
    });
    if (!lottery) throw 'Lottery not found';
    return lottery;
}


async function update(id, params) {
    const lottery = await db.GameInfo.findOne({ where: { id: id } });
    if (!lottery) throw 'Lottery not found'
    console.log(params.startTime, "params.startTime")

    const localTime = params.startTime;
    const timeZone = params.timeZone;
    const startTimeUtc = convertLocalTimeToUTC(localTime, timeZone);
    params.startTime = startTimeUtc;
    console.log(params.startTime, "params.startTime")
    console.log(params.timeZone, "params.timeZone")

    const ticketDifference = params.maxNumberTickets - lottery.maxNumberTickets;
    Object.assign(lottery, params);
    const updatedLottery = await lottery.save();
    if (ticketDifference > 0) {
        await generateRandomLoop(ticketDifference, updatedLottery.id);
    }
    return updatedLottery;
}


async function _delete(user, id) {
    if (!user) throw 'unauthorize';
    const lottery = await getLottery(id);
    await lottery.destroy();
}