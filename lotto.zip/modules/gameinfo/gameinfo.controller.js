﻿const express = require('express');
const router = express.Router();
const Joi = require('joi');
const { validateRequest } = require('../../_middleware/validate-request');
const authorize = require('../../_middleware/user');
const modelSerice = require('./gameinfo.service');
let multer = require('multer');
const fs = require('fs');
const jwt = require('jsonwebtoken');

// routes
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, "uploads/lottery");
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + "-" + file.originalname.toLowerCase().split(' ').join('-'));
    }
});
const upload = multer({
    storage: storage,
    fileFilter: (req, file, cb) => {
        if (file.mimetype == "image/png" || file.mimetype == "image/jpg" || file.mimetype == "image/jpeg") {
            cb(null, true);
        } else {
            return cb('Only .png, .jpg and .jpeg format allowed!', false);
        }
    }
});

const cpUpload = upload.single('image');
function uploadImage(req, res, next) {
    cpUpload(req, res, function (err) {
        if (!fs.existsSync("lottery")) {
            fs.mkdirSync("lottery");
        }
        if (err instanceof multer.MulterError) {
            return res.status(400).json({ message: JSON.stringify(err) });
        } else if (err) {
            return res.status(400).json({ message: err });
        }
        next();
    });
}

router.post('/store', storeSchema, uploadImage, store);
router.get('/', getAllSchema, getAll);
router.get('/phase', getAllSchema, getAllWithPhase);
router.get('/:id', getById);
router.put('/:id', storeSchema, uploadImage, update);
router.delete('/:id', authorize.admin(), _delete);

module.exports = router;




function storeSchema(req, res, next) {
    const schema = Joi.object({
        gameCurrency: Joi.string().empty(''),
        gameNumber: Joi.string().empty(''),
        gameName: Joi.string().empty(''),
        gameSlogan: Joi.string().empty(''),
        sold: Joi.number().integer().empty(''),
        gameDuration: Joi.string().empty(''),
        maxNumberTickets: Joi.string().empty(''),
        buyTicketLimit: Joi.string().empty(''),
        ticketPrice: Joi.string().empty(''),
        minPrizePool: Joi.string().empty(''),
        startTime: Joi.string().empty(''),
        timeZone: Joi.string().empty(''),
        status: Joi.number().integer().empty(''),
        nextDraw: Joi.number().integer().empty(''),
        instruction: Joi.string().empty('')
    });
    validateRequest(req, next, schema);
}

function store(req, res, next) {
    if (req.file) {
        req.body.image = `${process.env.ASSET_URL}/lottery/${req.file.filename}`;
    }
    modelSerice.create(req.body)
        .then(data => {
            res.json({ message: 'Success', data })
        })
        .catch(next);
}

function getAllSchema(req, res, next) {
    const schema = Joi.object({
        offset: Joi.number().integer().min(0).empty(''),
        limit: Joi.number().integer().min(1).empty(''),
        orderBy: Joi.string().valid('id', 'createdAt', 'name', 'email').empty(''),
        orderType: Joi.string().valid('DESC', 'ASC').empty(''),
        search: Joi.string().empty('')
    });
    validateRequest(req, next, schema, 'query');
}

function getAll(req, res, next) {
    modelSerice.getAll(req.query)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}


function getAllWithPhase(req, res, next) {
    modelSerice.getAllWithPhase(req.query)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function getById(req, res, next) {
    modelSerice.getById(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

async function update(req, res, next) {
    try {
        if (req.file) {
            req.body.image = `${process.env.ASSET_URL}/lottery/${req.file.filename}`;
        }
        let currentData = await modelSerice.getById(req.params.id);
        if (req.body.sold) {
            req.body.sold = currentData.sold + parseInt(req.body.sold);
        }
        let data = await modelSerice.update(req.params.id, req.body);
        res.json({ message: 'Success', data });
    } catch (error) {
        next(error);
    }
}

function _delete(req, res, next) {
    modelSerice.delete(req.user, req.params.id)
        .then(() => res.json({ message: 'Success' }))
        .catch(next);
}

// Helper functions Tushar_🙂🙂🙂🙂
