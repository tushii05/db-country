const express = require('express');
const router = express.Router();


// Helper Functions 


router.put('/:number/:gameInformationId', (req, res) => {
    db.generateRandomNoLottery.update({
        status: 1
    }, {
        where: {
            number: req.params.number,
            gameInformationId: req.params.gameInformationId,
            status: 0
        }
    })
        .then(result => {
            if (result[0] === 0) {
                return res.status(404).send({
                    message: 'Lottery Number and Game Information id not found'
                });
            }
            res.send({
                message: 'Status updated successfully'
            });
        })
        .catch(err => {
            res.status(500).send({
                error: err
            });
        });
});

module.exports = router;