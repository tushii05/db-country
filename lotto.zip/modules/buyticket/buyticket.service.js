﻿const db = require('../../_helpers/db');
const { Op } = require("sequelize");
const { sendEmail } = require('../../_middleware/email');

module.exports = {
    getAll,
    getById,
    create
};
async function getAll({ offset = 0, limit = 100, orderBy = 'id', orderType = 'DESC', search = null }) {
    let where = {};
    if (search !== null) {
        where = { '$User.fname$': { [Op.like]: `%${search}%` } }
    }

    return await db.buyTicket.findAndCountAll({
        where,
        include: [
            { model: db.GameInfo, },
            { model: db.User },
            { model: db.GamePhase }
        ],
        offset: parseInt(offset),
        limit: parseInt(limit),
        order: [[orderBy, orderType]]
    });
}


async function getById(id) {
    return await getLotteryTicket(id);
}


async function create(params) {
    let ticketArr = [];
    if (params.tickets) {
        for (const value of params.tickets) {
            ticketArr.push(value.ticketNumber);
        }
    }
    const Lottery = {
        "lotteryId": params.lotteryId,
        "UserId": params.userId,
        "gamePhaseId": params.gamePhaseId,
        "gameCurrencyId": params.gameCurrencyId,
        "timeZoneId": params.timeZoneId,
        "ticketPrice": params.ticketPrice,
        "tickets": ticketArr.join(","),
        "totalPrice": params.totalPrice,
        "transactionId": params.transactionId,
        "paymentStatus": ""
    }
    const LotterSql = await db.buyTicket.create(Lottery);
    let totalBuyTicket = await db.buyTicket.findOne({
        attributes: [
            [db.sequelize.fn("SUM", db.sequelize.cast(db.sequelize.col("totalPrice"), 'integer')), "totalPrice"]
        ],
        where: { UserId: params.userId }
    });

    await db.User.update(
        { BuyTicketId: LotterSql.id, totalTicketAmount: totalBuyTicket.dataValues.totalPrice },
        { where: { id: params.userId } }
    )

    try {

        const [user, buyTicket] = await Promise.all([
            db.User.findOne({ where: { id: params.userId } }),
            db.buyTicket.findOne({ where: { id: LotterSql.id } })
        ]);

        if (!user || !user.email || user.email.trim() === "") {
            throw new Error("User email not found");
        }

        const html = `Dear <b>${user.fname} ${user.lname}</b>,<br> <br>
        Congratulations! You have successfully purchased ticket's on Lifetime Lotto.<br>
        Your ticket number's are: ${buyTicket.tickets}.<br>
        To know more details about your ticket's <a href="${process.env.ASSET_URL}/ticketlist">Click Here</a>.<br>
        We hope you enjoy playing on Lifetime Lotto and make the most out of your ticket's.<br>
        <br>
        The team Lifetime Lotto`;
        const subject = "Lottery Ticket Purchase Successful";
        await sendEmail(user.email, subject, html);
        return buyTicket;

    } catch (error) {

        throw error;

    }
}



// Helper functions Tushar_🙂🙂🙂🙂

async function getLotteryTicket(id) {
    const ticket = await db.buyTicket.findByPk(id);
    if (!ticket) throw 'Lottery Ticket not found';
    return await db.buyTicket.findOne({
        where: { id: id },
        include: [
            { model: db.GameInfo, },
            { model: db.User },
            { model: db.GamePhase }
        ]
    });
}