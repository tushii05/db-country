﻿const express = require('express');
const router = express.Router();
const Joi = require('joi');
const { validateRequest } = require('../../_middleware/validate-request');
const lotteryTicketService = require('./buyticket.service');
module.exports = router;

// routes
router.get('/', getAllSchema, getAll);
router.post('/store', storeSchema, store);
router.get('/:id', getById);
module.exports = router;
// currency section
function getAllSchema(req, res, next) {
    const schema = Joi.object({
        offset: Joi.number().integer().min(0).empty(''),
        limit: Joi.number().integer().min(1).empty(''),
        orderBy: Joi.string().valid('id', 'createdAt', 'ticket_number').empty(''),
        orderType: Joi.string().valid('DESC', 'ASC').empty(''),
        search: Joi.string().empty(''),
    });
    validateRequest(req, next, schema, 'query');
}
function getAll(req, res, next) {
    lotteryTicketService.getAll(req.query)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}


function store(req, res, next) {
    lotteryTicketService.create(req.body)
        .then(data => { res.json({ message: 'Success', data }) })
        .catch(next);
}


function storeSchema(req, res, next) {
    const schema = Joi.object({
        lotteryId: Joi.number().integer().required(),
        userId: Joi.number().integer().required(),
        gamePhaseId: Joi.number().integer().required(),
        gameCurrencyId: Joi.number().integer().required(),
        timeZoneId: Joi.number().integer().required(),
        ticketPrice: Joi.string().required(),
        tickets: Joi.array().items(Joi.object({ ticketNumber: Joi.string().required() })).min(1).required(),
        totalPrice: Joi.string().required(),
        transactionId: Joi.string().empty(''),
        paymentStatus: Joi.string().empty(''),
    });
    validateRequest(req, next, schema);
}

function getById(req, res, next) {
    lotteryTicketService.getById(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}


//Helper Code Tushar_🙂🙂🙂🙂
