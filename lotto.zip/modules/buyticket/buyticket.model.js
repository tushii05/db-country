const { DataTypes, literal } = require('sequelize');

module.exports = model;

function model(sequelize) {
    const attributes = { 
        lotteryId: { type: DataTypes.INTEGER, allowNull: false },
        gamePhaseId:{ type: DataTypes.INTEGER, allowNull: false },
        ticketPrice: { type: DataTypes.DECIMAL, allowNull: false },
        gameCurrencyId:{ type: DataTypes.INTEGER, allowNull: false },
        timeZoneId:{ type: DataTypes.INTEGER, allowNull: false },
        tickets: { type: DataTypes.TEXT, allowNull: false },
        totalPrice: { type: DataTypes.DECIMAL, allowNull: false },
        transactionId: { type: DataTypes.STRING, allowNull: true },
        paymentStatus: { type: DataTypes.STRING, allowNull: true }
    };

    const options = {
        defaultScope: {
            // exclude hash by default
            attributes: { exclude: [''] }
        },
        scopes: {
            // include hash with this scope
            withHash: { attributes: {}, }
        }
    };

    return sequelize.define('BuyTicket', attributes, options);
}