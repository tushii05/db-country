﻿const db = require('../../_helpers/db');

module.exports = {
    getAll,
    getById,
    create,
    update,
    _delete
};
async function getAll({ offset = 0,  orderBy = 'id', orderType = 'DESC', search = null }) {
    let where = {};
    if (search !== null) {
        where = { '$attachment$': { [Op.like]: `%${search}%` } }
    }
    return await db.SupportTicketAttachment.findAndCountAll({
        where,
        include: [{ model: db.supportTicketMessage }],
        offset: parseInt(offset),
        // limit: parseInt(limit),
        order: [[orderBy, orderType]]
    });
}
async function getById(id) {
    return await getSupportTicketAttachment(id);
}
async function create(params) {
    return await db.SupportTicketAttachment.create(params);
}
async function update(id, params) {
    const supportTicketAttachment = await db.SupportTicketAttachment.findOne({ where: { id: id } });
    if (!supportTicketAttachment) throw 'supportTicketAttachment not found'
    Object.assign(supportTicketAttachment, params);
    return await supportTicketAttachment.save();
}
// helper functions 
async function getSupportTicketAttachment(id) {
    const supportTicketAttachment = await db.SupportTicketAttachment.findByPk(id);
    if (!supportTicketAttachment) throw 'supportTicketAttachment not found';
    return await db.SupportTicketAttachment.findOne({
        where: { id: id },
        include: [{
            model: db.supportTicketMessage,
        }]
    });
}
async function _delete(id) {
    const supportTicketAttachment = await db.SupportTicketAttachment.findOne({ where: { id: id } });
    if (supportTicketAttachment) {
        await supportTicketAttachment.destroy();
        return true;
    }
}