﻿const express = require('express');
const router = express.Router();
const Joi = require('joi');
const { validateRequest } = require('../../_middleware/validate-request');
const supportTicketAttachmentService = require('./supportticketattachment.service');
const multer = require('multer');
const fs = require('fs');
module.exports = router;



const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, "uploads/supportTicketAttachment");
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + "-" + file.originalname.toLowerCase().split(' ').join('-'));
    }
});

const upload = multer({
    storage: storage,
    fileFilter: (req, file, cb) => {
        if (file.mimetype == "application/pdf" || file.mimetype == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" || file.mimetype == "application/vnd.openxmlformats-officedocument.wordprocessingml.document" || file.mimetype == "image/png" || file.mimetype == "image/jpeg") {
            cb(null, true);
        } else {
            return cb('Only .pdf, .xlsx, .docx, .png, .jpg and .jpeg formats allowed!', false);
        }
    }
});


const cpUpload = upload.array('file');
function uploadImage(req, res, next) {
    cpUpload(req, res, function (err) {
        if (!fs.existsSync("supportTicketAttachment")) {
            fs.mkdirSync("supportTicketAttachment");
        }
        if (err instanceof multer.MulterError) {
            return res.status(400).json({ message: JSON.stringify(err) });
        } else if (err) {
            return res.status(400).json({ message: err });
        }
        next();
    });
}

// routes
router.get('/', getAllSchema, getAll);
router.post('/store', uploadImage, store, storeSchema);
router.get('/:id', getById);
router.put('/:id', update);
router.delete('/:id', _delete);


function getAllSchema(req, res, next) {
    const schema = Joi.object({
        offset: Joi.number().integer().min(0).empty(''),
        limit: Joi.number().integer().min(1).empty(''),
        orderBy: Joi.string().valid('id', 'createdAt').empty(''),
        orderType: Joi.string().valid('DESC', 'ASC').empty(''),
        search: Joi.string().empty(''),
    });
    validateRequest(req, next, schema, 'query');
}
function getAll(req, res, next) {
    supportTicketAttachmentService.getAll(req.query)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function store(req, res, next) {
    const attachment = [];
    if (req.files) {
        req.files.forEach(file => {
            attachment.push({
                filename: file.filename,
                url: `${process.env.ASSET_URL}/supportTicketAttachment/${file.filename}`
            });
        });
    }
    req.body.attachment = attachment;
    supportTicketAttachmentService.create(req.body)
        .then(data => { res.json({ message: 'Success', data }) })
        .catch(next);
}

function storeSchema(req, res, next) {
    const schema = Joi.object({
        SupportTicketMessageId: Joi.number().required(),
        attachment: Joi.array().items(Joi.object({
            filename: Joi.string(),
            url: Joi.string(),

        }))
    });
    validateRequest(req, next, schema);
}


function getById(req, res, next) {
    supportTicketAttachmentService.getById(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}
function update(req, res, next) {
    if (req.file) {
        req.body.image = `${process.env.ASSET_URL}/supportTicketAttachment/${req.file.filename}`;
    }
    supportTicketAttachmentService.update(req.params.id, req.body)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function _delete(req, res, next) {
    supportTicketAttachmentService._delete(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

