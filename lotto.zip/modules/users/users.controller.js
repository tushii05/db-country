﻿const express = require('express');
const router = express.Router();
const Joi = require('joi');
const { validateRequest, validateQuery } = require('./../../_middleware/validate-request');
const authorize = require('./../../_middleware/user');
const userService = require('./users.service');
const multer = require('multer');
const fs = require('fs');
const jwt = require('jsonwebtoken');
// routes
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, "uploads/user");
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + "-" + file.originalname.toLowerCase().split(' ').join('-'));
    }
});
const upload = multer({
    storage: storage,
    fileFilter: (req, file, cb) => {
        if (file.mimetype == "image/png" || file.mimetype == "image/jpg" || file.mimetype == "image/jpeg") {
            cb(null, true);
        } else {
            return cb('Only .png, .jpg and .jpeg format allowed!', false);
        }
    }
});

const cpUpload = upload.single('image');
function uploadImage(req, res, next) {
    cpUpload(req, res, function (err) {
        if (!fs.existsSync("user")) {
            fs.mkdirSync("user");
        }
        if (err instanceof multer.MulterError) {
            return res.status(400).json({ message: JSON.stringify(err) });
        } else if (err) {
            return res.status(400).json({ message: err });
        }
        next();
    });
}

router.post('/authenticate', authenticateSchema, authenticate); // No user
router.post('/register', uploadImage, registerSchema, register); // No User
router.get('/', getAllSchema, getAll); // By Super Admin Only
router.get('/count-all', getCountAll); // By Super Admin Only
router.get('/current', authorize.user(), getCurrent); // User level
router.post('/change-password', authorize.user(), changePassword); // By Super Admin Only
router.get('/:id', getById); // By Super Admin Only
router.put('/:id', uploadImage, updateSchema, update);
router.get('/verify-email/:verificationToken', verifyEmailSchema, verifyEmailHandler);
router.post("/forget-password", forgetPassword);
router.post("/reset-password", resetPassword);
router.get("/support/:id", getByIdSupportTicket);
// router.get("/transaction/:id", getByIdTransaction);
router.get("/card-transaction/:id", getByIdCardTransaction);
router.get('/buyticket/:id', getByIdBuyTicket);
router.get('/winners/:id', getByIdWinners);
router.get('/withdrawals/:id', getByIdWithdrawals);
router.get('/admin/transaction/:id', getByIdAdminTransaction);
router.get('/scratchcard/:id', getByIdScratchCard);
router.get('/scratchcard-win/:id', getByIdScratchCardWin);
router.get('/scratchcard-loss/:id', getByIdScratchCardLoss);
router.get('/deposit/:id', getByIdDepositTransaction)

router.get('/refer/:id', getReferById);

router.post("/send-otp", sendOTP);
router.post("/verify-otp", verifyOtp);

//Google Logins

module.exports = router;


function authenticateSchema(req, res, next) {
    const schema = Joi.object({
        username: Joi.string().email().required(),
        password: Joi.string().required(),
        firebaseToken: Joi.string().empty('')
    });
    validateRequest(req, next, schema);
}

function authenticate(req, res, next) {
    userService.authenticate(req)
        .then(data => res.json({ message: "Success", data }))
        .catch(next);
}


function changePassword(req, res, next) {
    userService.changePassword(req.user, req.body.password, req.body.currentPassword)
        .then(data => {
            res.json({ message: "Success", data })
        }).catch(next);
}

function registerSchema(req, res, next) {
    const schema = Joi.object({
        fname: Joi.string().required(),
        lname: Joi.string().required(),
        country: Joi.string().required(),
        mobileNo: Joi.string().pattern(/^[0-9]+$/).required(),
        userName: Joi.string().required(),
        email: Joi.string().email().required(),
        password: Joi.string().required(),
        status: Joi.string().empty(''),
        refer_code: Joi.string().empty(''),
        refer_by: Joi.string().empty(''),
    });
    validateRequest(req, next, schema);
}

function updateSchema(req, res, next) {
    const schema = Joi.object({
        fname: Joi.string().empty(),
        lname: Joi.string().empty(),
        mobileNo: Joi.string().empty(),
        userName: Joi.string().empty(''),
        email: Joi.string().email().required(),
        password: Joi.string().empty(''),
        address: Joi.string().empty(''),
        city: Joi.string().empty(''),
        state: Joi.string().empty(''),
        zip: Joi.string().empty(''),
        country: Joi.string().empty(''),
        email_verify: Joi.string().empty(''),
        sms_verify: Joi.string().empty(''),
        twofa_status: Joi.string().empty(''),
        twofa_verification: Joi.string().empty(''),
        balance: Joi.number().integer().empty(''),
        type: Joi.string().empty(''),
        remark: Joi.string().empty(''),
        status: Joi.string().empty(''),
    });
    validateRequest(req, next, schema);
}

function register(req, res, next) {
    if (req.file) { req.body.image = `${process.env.ASSET_URL}/user/${req.file.filename}`; }
    userService.create(req.body).then(() => {
        res.json({ message: 'Registration successful. Please check your email to verify your account.' })
    }).catch(next);
}

function verifyEmailSchema(req, res, next) {
    const schema = Joi.object({
        verificationToken: Joi.string().empty('')
    });
    if (req.query) {
        validateQuery(req, next, schema)
    } else {
        validateRequest(req, next, schema);
    }
}

async function verifyEmailHandler(req, res, next) {
    try {
        const user = await userService.verifyEmail(req.params.verificationToken);
        const htmlContent = `
                            <!DOCTYPE html>
                            <html>
                            <head>
                                <meta charset="UTF-8">
                                <title>Email Verification Success</title>
                            <style>
                            body {
                                display: flex;
                                flex-direction: column;
                                justify-content: center;
                                align-items: center;
                                height: 100vh;
                                }
                            h1 {
                                color: #333;
                                font-size: 24px;
                                font-weight: bold;
                                display: flex;
                                justify-content: center;
                                align-items: center;
                                }
                            span {
                                color:green;
                                font-size: 48px;
                                margin-left: 12px;
                            }
                            p {
                                color: #666;
                                font-size: 18px;
                                text-align: center;
                            }
                            a {
                                color: blue;
                                text-decoration: none;
                            }
                            </style>
                            </head>
                            <body>
                                <h1>Email Verified <span>&#10004;</span></h1>
                                <p>You can now log in <a href="${process.env.ASSET_URL}/login">click here</a>.</p>
                            </body>
                            </html> `;
        res.send(htmlContent);
        // res.json({ message: 'Your email has been successfully verified. You can now log in.' });
    } catch (error) {
        // console.error(`Error verifying email: ${error}`);
        if (error.name === 'TokenExpiredError') {
            res.status(400).json({ error: 'Verification link has expired. Please request a new verification email.' });
        } else if (error.message === 'Invalid verification token') {
            res.status(400).json({ error: 'Invalid verification token' });
        } else {
            res.status(400).json({ error: 'Email verification failed' });
        }
    }
}

function getAllSchema(req, res, next) {
    const schema = Joi.object({
        offset: Joi.number().integer().min(0).empty(''),
        limit: Joi.number().integer().min(1).empty(''),
        orderBy: Joi.string().valid('id', 'createdAt', 'fname', 'email').empty(''),
        orderType: Joi.string().valid('DESC', 'ASC').empty(''),
        search: Joi.string().empty(''),
        type: Joi.string().empty('')
    });
    validateRequest(req, next, schema, 'query');
}

function getAll(req, res, next) {
    userService.getAll(req.query)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}


function getCountAll(req, res, next) {
    userService.getCountAll(req.query)
        .then(data => {
            res.json({ data })
        })
        .catch(next);
}


function getCurrent(req, res, next) {
    userService.getCurrent(req.user)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function getById(req, res, next) {
    userService.getById(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function getReferById(req, res, next) {
    userService.getReferById(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}


//=============================

function getByIdAdminTransaction(req, res, next) {
    userService.getByIdAdminTransaction(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next)
}


function getByIdSupportTicket(req, res, next) {
    userService.getByIdSupportTicket(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next)
}

// function getByIdTransaction(req, res, next) {
//     userService.getByIdTransaction(req.params.id)
//         .then(data => res.json({ message: 'Success', data }))
//         .catch(next)
// }

function getByIdCardTransaction(req, res, next) {
    userService.getByIdCardTransaction(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next)
}

function getByIdBuyTicket(req, res, next) {
    userService.getByIdBuyTicket(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next)
}

function getByIdWinners(req, res, next) {
    userService.getByIdWinners(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next)
}

function getByIdWithdrawals(req, res, next) {
    userService.getByIdWithdrawals(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next)
}


function getByIdScratchCard(req, res, next) {
    userService.getByIdScratchCard(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next)
}


function getByIdScratchCardWin(req, res, next) {
    userService.getByIdScratchCardWin(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next)
}

function getByIdScratchCardLoss(req, res, next) {
    userService.getByIdScratchCardLoss(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next)
}

function getByIdDepositTransaction(req, res, next) {
    userService.getDepositTransaction(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next)
}


function update(req, res, next) {
    if (req.file) {
        req.body.image = `${process.env.ASSET_URL}/user/${req.file.filename}`;
    }
    userService.update(req.params.id, req.body)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}


// Helper functions Tushar_🙂🙂🙂🙂

async function forgetPassword(req, res, next) {
    try {
        const { username } = req.body;
        const result = await userService.forgetPassword({ username });
        res.status(200).json(result);
    } catch (error) {
        res.status(400).json({ message: error.toString() });
    }
}



async function resetPassword(req, res, next) {
    try {
        const { email, newPassword, OTP } = req.body;
        const result = await userService.resetPassword({ email, newPassword, OTP });
        res.status(200).json(result);
    } catch (error) {
        res.status(400).json({ message: error.toString() });
    }
}


// User mobile -----------------

async function sendOTP(req, res) {
    const { mobileNumber, userId } = req.body;

    try {
        const otp = await userService.sendMobileOTP(mobileNumber, userId);
        res.json({ message: 'OTP sent successfully!', otp });
    } catch (error) {
        res.json({ error: error.message });
    }
};

async function verifyOtp(req, res) {
    const { mobileNumber, otp } = req.body;

    try {
        const user = await userService.verifyAndUpdate(mobileNumber, otp);
        if (user) {
            res.json({ message: 'Mobile number verified updated!' });
        } else {
            res.json({ error: 'Invalid OTP or Mobile not found!' });
        }
    } catch (error) {
        res.json({ error: error.message });
    }
};
