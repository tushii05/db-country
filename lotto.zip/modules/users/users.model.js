const { DataTypes, literal } = require('sequelize');

module.exports = model;

function model(sequelize) {
    const attributes = {
        image: { type: DataTypes.STRING, allowNull: true },
        fname: { type: DataTypes.STRING, allowNull: false },
        lname: { type: DataTypes.STRING, allowNull: false },
        userName: { type: DataTypes.STRING, allowNull: false },
        email: { type: DataTypes.STRING, allowNull: false },
        mobileNo: { type: DataTypes.STRING, allowNull: false },
        address: { type: DataTypes.STRING, allowNull: true },
        city: { type: DataTypes.STRING, allowNull: true },
        state: { type: DataTypes.STRING, allowNull: true },
        zip: { type: DataTypes.STRING, allowNull: true },
        country: { type: DataTypes.STRING, allowNull: false },
        hash: { type: DataTypes.STRING, allowNull: false },
        status: { type: DataTypes.TINYINT, allowNull: false, defaultValue: 1 },
        email_verify: { type: DataTypes.TINYINT, allowNull: false, defaultValue: 0, Comment: "1=> verify, 0 => unverify" },
        sms_verify: { type: DataTypes.TINYINT, allowNull: false, defaultValue: 0, Comment: "1=> verify, 0 => unverify" },
        twofa_status: { type: DataTypes.TINYINT, allowNull: false, defaultValue: 0, Comment: "1=> Active, 0 => Inactive" },
        twofa_verification: { type: DataTypes.TINYINT, allowNull: false, defaultValue: 0, Comment: "1=> Active, 0 => Inactive" },
        balance: { type: DataTypes.DOUBLE, allowNull: false, defaultValue: 0 },
        commission_balance: { type: DataTypes.DOUBLE, allowNull: false, defaultValue: 0 },
        remark: { type: DataTypes.TEXT, allowNull: true },
        totalTicketAmount: { type: DataTypes.DOUBLE, allowNull: false, defaultValue: 0 },
        totalScratchCardWon: { type: DataTypes.DOUBLE, allowNull: false, defaultValue: 0 },
        totalCardAmount: { type: DataTypes.DOUBLE, allowNull: false, defaultValue: 0 },
        verificationToken: { type: DataTypes.STRING },
        emailVerified: { type: DataTypes.BOOLEAN, defaultValue: false },
        otp: { type: DataTypes.STRING, allowNull: true, },
        refer_code: { type: DataTypes.STRING, allowNull: true, },
        refer_by: { type: DataTypes.INTEGER, allowNull: true, defaultValue: 0 },
        mobileOtp: { type: DataTypes.STRING, allowNull: true, defaultValue: 0 },
        otpExpiration: { type: DataTypes.DATE, allowNull: true, defaultValue: 0 }
    };

    const options = {
        defaultScope: {
            // exclude hash by default
            attributes: { exclude: ['hash'] }
        },
        scopes: {
            // include hash with this scope
            withHash: { attributes: {}, }
        }
    };

    return sequelize.define('User', attributes, options);
}