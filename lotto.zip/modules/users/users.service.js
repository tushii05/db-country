﻿const jwt = require('jsonwebtoken');
const { sendEmail } = require('../../_middleware/email');
const bcrypt = require('bcryptjs');
const db = require('./../../_helpers/db');
const { QueryTypes } = require('sequelize');
const { Op } = require("sequelize");
const { logHistory } = require('../../util/location');
const { generateOTP } = require('../../_middleware/random-number')
const client = require('twilio')(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);


module.exports = {
    authenticate,
    getAll,
    getById,
    create,
    verifyEmail,
    changePassword,
    getJWT,
    forgetPassword,
    update,
    getCurrent,
    getCountAll,
    forgetPassword,
    resetPassword,
    //===========================
    getByIdSupportTicket,
    getByIdTransaction,
    getByIdCardTransaction,
    getByIdBuyTicket,
    getByIdWinners,
    getByIdWithdrawals,
    getByIdAdminTransaction,
    getReferById,
    getByIdScratchCard,
    getByIdScratchCardWin,
    getByIdScratchCardLoss,
    sendMobileOTP,
    verifyAndUpdate,
    getDepositTransaction

};

// async function authenticate({ username, password, firebaseToken }) {
//     const user = await db.User.scope('withHash').findOne({ where: { email: username } });

//     if (!user || !(await bcrypt.compare(password, user.hash)))
//         throw 'Username or password is incorrect';

//     if (!user.emailVerified) {
//         throw 'Please verify your email before logging in';
//     }

//     db.User.update({ firebaseToken }, { where: { id: user.id } });
//     // const token = jwt.sign({ sub: user.id }, process.env.SECRETSTRING, { expiresIn: '7d' });
//     // return { ...omitHash(user.get()), token };
//     const expirationTime = new Date();
//     expirationTime.setDate(expirationTime.getDate() + 7); // Set token expiration to 7 days from now

//     const token = jwt.sign({ sub: user.id, exp: expirationTime.getTime() / 1000 }, process.env.SECRETSTRING);
//     // const log = { ...omitHash(user.get()) }
//     const logIn = await logHistory({ user: user.id });
//     console.log(logIn, "logIn")
//     return { ...omitHash(user.get()), token, expiresAt: expirationTime.toISOString() };
// }

async function authenticate(req) {
    const { username, password, firebaseToken } = req.body;
    const user = await db.User.scope("withHash").findOne({ where: { email: username } });

    if (!user || !(await bcrypt.compare(password, user.hash)))
        throw "Username or password is incorrect";

    if (!user.emailVerified) {
        throw "Please verify your email before logging in";
    }

    await db.User.update({ firebaseToken }, { where: { id: user.id } });

    const expirationTime = new Date();
    expirationTime.setDate(expirationTime.getDate() + 1); // Set token expiration to 1 days from now
    const token = jwt.sign({ sub: user.id, exp: expirationTime.getTime() / 1000 }, process.env.SECRETSTRING);


    const userDetail = user.get();
    const userId = userDetail.id;

    try {
        logHistory(req, userId);
        return { ...omitHash(userDetail), token, expiresAt: expirationTime.toISOString() };
    } catch (error) {
        console.log("Error recording log:", error);
        throw error;
    }
}

async function getCountAll() {
    return await db.sequelize.query(`SELECT
	(select COUNT(id) from Users where status = 1) as activeaccount,
    (select COUNT(id) from Users where status = 0) as inactiveaccount,
    (select COUNT(id) from Users where emailVerified = 1) as emailverifycount,
    (select COUNT(id) from Users where emailVerified = 0) as email_unverified,
    (select COUNT(id) from Users where balance > 0) as with_balance,
    (select COUNT(id) from Users where balance = 0) as with_out_balance,
    (select COUNT(id) from Users where commission_balance > 0) as with_commission_balance,
    (select COUNT(id) from Users where commission_balance = 0) as with__out_commission_balance,
    (select COUNT(id) from Users where sms_verify = 1) as user_sms_verify,
    (select COUNT(id) from Users where sms_verify = 0) as sms_unverified,
    COUNT(*) AS Total_Users
    FROM Users limit 1`, { type: QueryTypes.SELECT });
}

//(select COUNT(id) from Users where sms_verify = 1) as smscount,
//(select COUNT(id) from Users where twofa_verification = 1) as kycunverifycount


async function getAll({ offset = 0, limit = 100, orderBy = 'fname', orderType = 'DESC', search = null, type = null }) {
    let where = {
        [Op.or]: [{ status: 0 }, { status: 1 }]

    };
    if (search !== null) {
        where = { fname: { [Op.like]: `%${search}%` } }
    }
    if (type !== null && type == "unverified_email" && search !== null) {

        where = {
            email_verify: {
                [Op.eq]: 0
            },
            fname: {
                [Op.like]: `%${search}%`
            }
        }

    }
    if (type !== null && type == "unverified_email" && search == null) {

        where = {
            email_verify: {
                [Op.eq]: 0
            }
        }

    }

    if (type !== null && type == "mobile-unverified" && search !== null) {

        where = {
            sms_verify: {
                [Op.eq]: 0
            },
            fname: {
                [Op.like]: `%${search}%`
            }
        }

    }
    if (type !== null && type == "mobile-unverified" && search == null) {

        where = {
            sms_verify: {
                [Op.eq]: 0
            }
        }

    }

    if (type !== null && type == "kyc-unverified" && search !== null) {

        where = {
            twofa_verification: {
                [Op.eq]: 0
            },
            fname: {
                [Op.like]: `%${search}%`
            }
        }

    }
    if (type !== null && type == "kyc-unverified" && search == null) {

        where = {
            twofa_verification: {
                [Op.eq]: 0
            }
        }

    }

    // if(type !== null && type == "kyc-pending" && search !== null) {

    //     where = {
    //         twofa_verification: {
    //           [Op.eq]: 0
    //         },
    //         fname: {
    //             [Op.like]: `%${search}%`
    //           }
    //       }

    // }
    // if(type !== null && type == "kyc-pending" && search == null) {

    //     where = {
    //         twofa_verification: {
    //           [Op.eq]: 0
    //         }
    //       }

    // }
    if (type !== null && type == "with-balance" && search !== null) {

        where = {
            balance: {
                [Op.gt]: 0
            },
            fname: {
                [Op.like]: `%${search}%`
            }
        }

    }
    if (type !== null && type == "with-balance" && search == null) {

        where = {
            balance: {
                [Op.gt]: 0
            }
        }

    }
    if (type !== null && type == "active-user" && search !== null) {

        where = {
            status: {
                [Op.eq]: 1
            },
            fname: {
                [Op.like]: `%${search}%`
            }
        }

    }
    if (type !== null && type == "active-user" && search == null) {
        where = {
            status: {
                [Op.eq]: 1
            }
        }

    }
    if (type !== null && type == "inactive-user" && search !== null) {

        where = {
            status: {
                [Op.eq]: 0
            },
            fname: {
                [Op.like]: `%${search}%`
            }
        }

    }
    if (type !== null && type == "inactive-user" && search == null) {
        where = {
            status: {
                [Op.eq]: 0
            }
        }

    }

    return await db.User.findAndCountAll({
        where,
        distinct: true,
        attributes: {
            include: [
                [
                    db.sequelize.literal(`(SELECT SUM(gameInformations.ticketPrice) FROM gameInformations  GROUP BY gameInformations.userId )`), 'totalWinAmount'
                ]
            ]
        },
        include: [
        ],
        offset: parseInt(offset),
        limit: parseInt(limit),

        order: [[orderBy, orderType]]
    });
}


async function getReferById(id) {
    return await getUserRefer(id);
}


async function getById(id) {
    return await getUser(id);
}

async function getByIdSupportTicket(id) {
    return await getSupportTicket(id);
}

async function getByIdTransaction(id) {
    return await getTransaction(id);
}

async function getByIdCardTransaction(id) {
    return await getCardTransaction(id);
}

async function getByIdAdminTransaction(id) {
    return await getAdminTransaction(id);
}


async function getByIdBuyTicket(id) {
    return await getBuyTicket(id);
}

async function getByIdWinners(id) {
    return await getWinners(id);
}

async function getByIdWithdrawals(id) {
    return await getWithdrawals(id);
}


async function getByIdScratchCard(id) {
    return await getScratchCard(id);
}

async function getByIdScratchCardWin(id) {
    return await getScratchCardWin(id);
}

async function getByIdScratchCardLoss(id) {
    return await getScratchCardLoss(id);
}


async function sendVerificationEmail(email, verificationToken, fname) {
    const html = `<body style="font-family: Arial, Helvetica, sans-serif;font-size: 15px;
                    color: #1a1a1a;
                    line-height: 1.4;">
                    <div>
                        <div>
                            <img src="http://159.223.51.198:3000/assets/images/Lifetime-Lotto-LOGO.png" style="width: 250px;height: 50px;">
                        </div>
                    <div>
                    <p>Hii ${fname} <br>
                    We're happy you signed up for Lifetime Lotto. To start exploring with your account, <br> please confirm your email address.
                    <a href="${verificationToken}" >Click Here</a> to verify now.<br>
                    </p>
                        Welcome to Lifetime lotto, <br>
                        The team Lifetime Lotto.
                    </div>
                    </div>
                </body>`;
    const subject = "Verify your email";
    await sendEmail(email, subject, html);
}

async function create(params) {
    const emailParts = params.email.split('@');
    const referCode = emailParts[0];
    if (await db.User.findOne({ where: { email: params.email } })) {
        throw 'Email "' + params.email + '" is already taken';
    }
    if (await db.User.findOne({ where: { userName: params.userName } })) {
        throw 'userName "' + params.userName + '" is already taken';
    }
    const verificationToken = jwt.sign({ type: "emailVerification", email: params.email }, process.env.SECRETSTRING, { expiresIn: '24h' });
    const verificationLink = `${process.env.ASET_URL}/verify-email/${verificationToken}`;

    await sendVerificationEmail(params.email, verificationLink, params.fname);

    if (params.password) {
        params.hash = await bcrypt.hash(params.password, 10);
    }
    let referredUser = null;
    if (params.refer_by) {
        referredUser = await db.User.findOne({ where: { refer_code: params.refer_by } });
        if (!referredUser) {
            throw 'Invalid referral code';
        }
    }
    const newUserParams = { ...params, refer_code: referCode };
    if (referredUser) {
        newUserParams.refer_by = referredUser.id;
    }
    const d = await db.User.create(newUserParams);
    // save verification token to user record in the database
    await d.update({ verificationToken: verificationToken });
    const user = await db.User.scope('withHash').findOne({ where: { id: d.id } });
    return omitHash(user.get());
}

async function verifyEmail(verificationToken) {
    try {
        const decodedToken = jwt.verify(verificationToken, process.env.SECRETSTRING);
        if (decodedToken.type !== 'emailVerification') {
            throw new Error('Invalid verification token');
        }
        const user = await db.User.findOne({ where: { email: decodedToken.email } });
        if (!user) {
            throw new Error('User not found for the given verification token');
        }
        user.emailVerified = true;
        await user.save();

        // Get user's first name
        const fname = user.fname;

        // Send a welcome email to the user

        const html = `<p> Hii ${fname}  <br>
        Your registration was successfull! <br>
        Thankyou for signing up on Lifetime Lotto. <br> 
        We will keep you posted here on the latest update and news about Lifetime lotto.<br><br>
        <a href="${process.env.ASSET_URL}/login" >Click Here</a> to Sign in.<br>
        <br>
        <br>
        Welcome to Lifetime lotto,<br>
        The team Lifetime Lotto.</p>`;
        const subject = 'Welcome to Lifetime Lotto';
        await sendEmail(user.email, subject, html);

        return omitHash(user.get());
    } catch (err) {
        throw new Error('Email verification failed');
    }
}


async function getJWT(params) {
    const token = jwt.sign({ sub: params.id, type: "user" }, process.env.SECRETSTRING, { expiresIn: '7d' });
    return { ...params, token }
}

async function changePassword(user, oldPassword, currentPassword) {
    const users = await db.User.scope('withHash').findOne({ where: { id: user.id } });
    const verifyPassword = await bcrypt.compare(oldPassword, users.hash)
    if (!verifyPassword) {
        return { message: "Incorrect old password." }
    }
    const params = { hash: await bcrypt.hash(currentPassword, 10) };
    Object.assign(users, params);
    await users.save();
    return { message: "Password changed successfully.", data: omitHash(users.get()) }

}

async function forgetPassword({ username }) {
    const user = await db.User.findOne({ where: { email: username } });
    if (!user) {
        throw "Email not registered with us."
    }
    const x = getJWT(user);
    return x;
}


// Helper functions Tushar_🙂🙂🙂🙂

async function getUser(id) {
    const user = await db.User.findOne({
        where: { id: id }
    });
    if (!user) throw 'User not found';
    return user;
}


// async function getUserRefer(id) {
//     const user = await db.User.findOne({
//         where: { id: id }
//     });
//     if (!user) throw 'User not found';

//     const referredUsers = await db.User.findAll({
//         where: { refer_by: user.id }
//     });

//     const referredUsersCount = referredUsers.length;

//     return { user, referredUsersCount, referredUsers };
// }



async function getUserRefer(id) {
    const user = await db.User.findOne({
        where: { id: id }
    });
    if (!user) throw 'User not found';

    const referredUsers = await db.User.findAll({
        where: { refer_by: user.id }
    });

    const commission = await db.Commission.findAll({
        where: { from_id: user.id }
    });

    return { user, commission, referredUsers };
}



async function getSupportTicket(id) {
    const user = await db.User.findOne({
        where: { id: id },
        include: [
            {
                model: db.supportTicket,
                required: false,
                order: [['id', 'DESC']]
            },
        ]
    });
    if (!user) throw 'User not found';
    return user;
}

// async function getTransaction(id) {
//     const user = await db.User.findOne({
//         where: { id: id },
//         include: [
//             {
//                 attributes: ['id', 'tansactionId', 'type', 'amount', 'currency', 'sender', 'receiver', 'description', 'balance', 'transactionType', 'lotteryId', 'tickets', 'status', 'createdAt'],
//                 model: db.UserTransaction,
//                 as: "deposit",
//                 required: false,
//                 where: {
//                     transactionType: {
//                         [Op.eq]: "Deposit"
//                     }
//                 },
//                 order: [['createdAt', 'DESC']]
//             },
//             {
//                 attributes: ['id', 'tansactionId', 'type', 'amount', 'currency', 'sender', 'receiver', 'description', 'balance', 'transactionType', 'lotteryId', 'tickets', 'status', 'createdAt'],
//                 model: db.UserTransaction,
//                 as: "withdraw",
//                 required: false,
//                 where: {
//                     transactionType: {
//                         [Op.eq]: "Withdraw"
//                     }
//                 }

//             },
//             {
//                 attributes: ['id', 'tansactionId', 'type', 'amount', 'currency', 'sender', 'receiver', 'description', 'balance', 'transactionType', 'lotteryId', 'tickets', 'status', 'createdAt'],
//                 model: db.UserTransaction,
//                 as: "winning",
//                 required: false,
//                 where: {
//                     transactionType: {
//                         [Op.eq]: "Winning"
//                     }
//                 }
//             },
//             {
//                 attributes: ['id', 'tansactionId', 'type', 'amount', 'currency', 'sender', 'receiver', 'description', 'balance', 'transactionType', 'lotteryId', 'tickets', 'status', 'createdAt'],
//                 model: db.UserTransaction,
//                 as: "purchase",
//                 required: false,
//                 where: {
//                     transactionType: {
//                         [Op.eq]: "Purchase"
//                     }
//                 }
//             },

//         ]
//     });
//     if (!user) throw 'User not found';
//     return user;
// }

async function getDepositTransaction(id) {
    const user = await db.User.findOne({
        where: { id: id },
        include: [
            {
                attributes: ['id', 'tansactionId', 'type', 'amount', 'currency', 'sender', 'receiver', 'description', 'balance', 'transactionType', 'lotteryId', 'tickets', 'status', 'createdAt'],
                model: db.UserTransaction,
                as: "deposit",
                required: false,
                where: {
                    transactionType: {
                        [Op.eq]: "Deposit"
                    }
                },
                order: [['createdAt', 'DESC']]
            }
        ]
    });
    if (!user) throw 'User not found';
    return user;
}

// async function getTransaction(id) {
//     const user = await db.User.findOne({
//         where: { id: id },
//         include: [
//             {
//                 model: db.UserTransaction,
//                 as: "deposit",
//                 required: false,
//                 where: {
//                     transactionType: {
//                         [Op.eq]: "Deposit"
//                     },
//                 }
//             },
//             {
//                 model: db.UserTransaction,
//                 as: "withdraw",
//                 required: false,
//                 where: {
//                     transactionType: {
//                         [Op.eq]: "Withdraw"
//                     }
//                 }
//             },
//             {
//                 model: db.UserTransaction,
//                 as: "winning",
//                 required: false,
//                 where: {
//                     transactionType: {
//                         [Op.eq]: "Winning"
//                     }
//                 }
//             },
//             {
//                 model: db.UserTransaction,
//                 as: "purchase",
//                 required: false,
//                 where: {
//                     transactionType: {
//                         [Op.eq]: "Purchase"
//                     }
//                 }
//             },
//             {
//                 model: db.UserTransaction,
//                 as: "commission",
//                 required: false,
//                 where: {
//                     transactionType: {
//                         [Op.eq]: "Commission"
//                     }
//                 }
//             }
//         ]
//     });

//     if (!user) {
//         throw 'User not found';
//     }

//     return user;
// }


async function getCardTransaction(id) {
    const user = await db.User.findOne({
        where: { id: id },
        include: [
            {
                attributes: ['id', 'tansactionId', 'type', 'amount', 'balance', 'transactionType', 'tickets', 'status', 'createdAt'],
                model: db.UserTransaction,
                as: "card_Purchase",
                required: false,
                where: {
                    transactionType: {
                        [Op.eq]: "Card_Purchase"
                    }
                }

            },
            {
                attributes: ['id', 'tansactionId', 'balance', 'transactionType', 'status', 'amount', 'scratchCardId', 'createdAt'],
                model: db.UserTransaction,
                as: "card_Won",
                required: false,
                where: {
                    transactionType: {
                        [Op.eq]: "Card_Won"
                    }
                }
            },
        ]
    });
    if (!user) throw 'User not found';
    return user;
}




async function getAdminTransaction(id) {
    const user = await db.User.findOne({
        where: { id: id },
        include: [
            {
                attributes: ['id', 'tansactionId', 'amount', 'sender', 'receiver', 'description', 'balance', 'transactionType', 'status', 'createdAt'],
                model: db.UserTransaction,
                as: "adminWithdraw",
                required: false,
                where: {
                    transactionType: {
                        [Op.eq]: "AdminWithdraw"
                    }
                }
            },
            {
                attributes: ['id', 'tansactionId', 'amount', 'sender', 'receiver', 'description', 'balance', 'transactionType', 'status', 'createdAt'],
                model: db.UserTransaction,
                as: "adminDeposit",
                required: false,
                where: {
                    transactionType: {
                        [Op.eq]: "AdminDeposit"
                    }
                }
            }
        ]
    });
    if (!user) throw 'User not found';
    return user;
}



async function getBuyTicket(id) {
    const user = await db.User.findOne({
        where: { id: id },
        include: [
            {
                attributes: ['id', 'ticketPrice', 'tickets', 'totalPrice', 'transactionId', 'paymentStatus'],
                model: db.buyTicket,
                required: false,
                include: [{
                    model: db.GameInfo,
                },
                { model: db.User }, { model: db.GamePhase }, { model: db.Currency },
                ]
            },
        ]
    });
    if (!user) throw 'User not found';
    return user;
}


async function getWinners(id) {
    const user = await db.User.findOne({
        where: { id: id },
        include: [
            {
                model: db.Winners,
                include: [
                    { model: db.GameInfo },
                    { model: db.GamePhase }
                ],
                required: false
            }
        ]
    });
    if (!user) throw 'User not found';
    // const winnersCount = await db.Winners.count({
    //     where: { userId: id }
    // });

    // user.dataValues.winnersCount = winnersCount;
    const winners = user.Winners || []; // Ensure winners array exists or set it to an empty array
    const sortedWinners = winners.sort((a, b) => b.id - a.id); // Sort winners by id in descending order

    const winnersCount = sortedWinners.length; // Use sorted winners count instead

    user.dataValues.winnersCount = winnersCount;
    return user;
}


async function getWithdrawals(id) {
    const user = await db.User.findOne({
        where: { id: id },
        include: [
            {
                model: db.Withdrawals,
                required: false,
            },
        ]
    });
    if (!user) throw 'User not found';
    return user;
}



async function getScratchCard(id) {
    const user = await db.User.findOne({
        where: { id: id },
        include: [
            {
                attributes: ['scratchCardId', 'scratchCardPrice', 'scratchDraw', 'totalPrice', 'transactionId', "scratchCards", 'won', 'rescheduleTime', 'scratchDrawCount', 'UserId'],
                model: db.scratchCardPlay,
                required: false,
                include: [
                    {
                        model: db.scratchCard,
                    }
                ]
            },
        ]
    });
    if (!user) throw 'User not found';
    return user;
}

async function getScratchCardWin(id) {
    const user = await db.User.findOne({
        where: { id: id },
        include: [
            {
                model: db.scratchCardPlay,
                required: false,
                include: [{
                    model: db.scratchCard,
                    attributes: ["card_name", "frequency"]
                }]
            },
            {
                model: db.scratchCardWin,
                required: false,
            },
        ]
    });
    if (!user) throw 'User not found';
    return user;
}

async function getScratchCardLoss(id) {
    const user = await db.User.findOne({
        where: { id: id },
        include: [
            {
                model: db.scratchCardPlay,
                required: false,
            },
            {
                model: db.scratchCardLoss,
                required: false,
            },
        ]
    });
    if (!user) throw 'User not found';
    return user;
}


function omitHash(user) {
    const { hash, ...userWithoutHash } = user;
    return userWithoutHash;
}
async function update(id, params) {
    const User = await db.User.scope('withHash').findOne({ where: { id: id } });
    if (params.type == "add") {
        params.balance = (User.balance + params.balance);
    } else {
        if (params.balance != undefined) {
            if (User.balance >= params.balance) {
                params.balance = (User.balance - params.balance);
            } else {
                throw 'Insufficient balance';
            }
        }
    }
    if (!User) throw 'user not found'
    const token = jwt.sign({ sub: id }, process.env.SECRETSTRING, { expiresIn: '7d' });
    // console.warn('update parms:-', params)
    await db.User.update(params, { where: { id: id } })
    const updateUser = await db.User.scope('withHash').findOne({ where: { id: id } });
    return { ...omitHash(updateUser.get()), token };
}
async function getCurrent(user) {
    if (!user) throw 'unauthorize'
    const User = await db.User.scope('withHash').findOne({ where: { id: user.id } });
    if (!User) throw 'user not found'
    const token = jwt.sign({ sub: user.id }, process.env.SECRETSTRING, { expiresIn: '7d' });
    return { ...omitHash(User.get()), token };
}



// Helper functions Tushar_🙂🙂🙂🙂


async function sendOTP(email, OTP, fname) {

    const html = `<p>Hello ${fname},</p>
    <p>Your OTP for password reset is <b>${OTP}</b>.</p>
    <p>OTP is expire in 15 Min.</p>
    <p>Use this one time password to set your new password. </p>`;
    const subject = 'Otp for forgot password';
    await sendEmail(email, subject, html);

}

async function forgetPassword({ username }) {
    const user = await db.User.findOne({ where: { email: username } });
    if (!user) {
        throw "Email not registered with us."
    }
    const OTP = generateOTP();
    await sendOTP(user.email, OTP, user.fname);
    const token = jwt.sign({ email: user.email, OTP }, process.env.SECRETSTRING, { expiresIn: '15m' });
    await user.update({ otp: OTP }); // save the OTP in the user's record
    return { message: "An OTP has been sent to your registered email.", token };
}

async function resetPassword({ email, newPassword, OTP }) {
    const user = await db.User.findOne({ where: { email } });
    if (!user) {
        throw "User not found."
    }
    if (OTP !== user.OTP) {
        throw "Invalid OTP."
    }
    const hashedPassword = await bcrypt.hash(newPassword, 10); // Hash the new password
    user.hash = hashedPassword; // Update the user's password
    user.OTP = null;
    await user.save();

    const html = `<p>Hi ${user.fname},</p>
    <p>Your password was changed successfully. You can now login with your new password: <a href="${process.env.ASSET_URL}/login">click here</a></p>
    <p>If this password change was not initiated by you, please <a href="${process.env.ASSET_URL}/forgot-password">click here</a> to change your password now and secure your account.</p>`;
    const subject = 'Password Reset Successful';
    await sendEmail(email, subject, html);

    return { message: "Password reset successfully." };
}


//Mobile-Otp Verification 

// async function sendMobileOTP(mobileNumber, userId) {
//     try {
//         const user = await db.User.findOne({ where: { id: userId, mobileNo: mobileNumber } });

//         if (!user) {
//             throw new Error('Invalid user ID or mobile number.');
//         }
//         const otp = generateOTP();
//         await client.messages.create({
//             body: `${otp} is your OTP for to verify your mobile number on LifeTime Lotto. OTP valid for 15 minutes. `,
//             from: process.env.TWILIO_PHONE_NUMBER,
//             to: mobileNumber
//         }).then((message))

//         user.mobileOtp = otp;
//         await user.save();

//         // return otp;
//     } catch (error) {
//         console.error('Failed to send OTP:', error);
//         throw error;
//     }
// }


async function sendMobileOTP(mobileNumber, userId) {
    try {
        const user = await db.User.findOne({ where: { id: userId, mobileNo: mobileNumber } });
        if (!user) {
            throw new Error('Invalid user ID or mobile number.');
        }

        const otp = generateOTP();
        const otpExpirations = new Date(Date.now() + 15 * 60 * 1000);

        await client.messages.create({
            body: `${otp} is your OTP for verifying your mobile number on LifeTime Lotto. OTP valid for 15 minutes.`,
            from: process.env.TWILIO_PHONE_NUMBER,
            to: mobileNumber
        });

        user.mobileOtp = otp;
        user.otpExpiration = otpExpirations;
        await user.save();
    } catch (error) {
        console.error('Failed to send OTP:', error);
        throw error;
    }
}

// async function verifyAndUpdate(mobileNumber, otp) {
//     const user = await db.User.findOne({ where: { mobileNo: mobileNumber } });
//     if (user && user.mobileOtp === otp) {
//         user.sms_verify = 1;
//         await user.save();
//         return user;
//     }
//     return null;
// }


async function verifyAndUpdate(mobileNumber, otp) {
    const user = await db.User.findOne({ where: { mobileNo: mobileNumber } });
    if (user && user.mobileOtp === otp) {

        if (user.otpExpiration > new Date()) {
            user.sms_verify = 1;
            await user.save();
            return user;
        } else {
            throw new Error('OTP has expired. Please request for a new OTP.');
        }
    }
    return null;
}