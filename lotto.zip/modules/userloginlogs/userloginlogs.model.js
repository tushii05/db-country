const { DataTypes, literal } = require('sequelize');

module.exports = model;

function model(sequelize) {
    const attributes = {
        userIp: { type: DataTypes.STRING, allowNull: true },
        city: { type: DataTypes.STRING, allowNull: false },
        country: { type: DataTypes.STRING, allowNull: false },
        // countryCode: { type: DataTypes.STRING, allowNull: false },
        region: { type: DataTypes.STRING, allowNull: false },
        longitude: { type: DataTypes.STRING, allowNull: false },
        latitude: { type: DataTypes.STRING, allowNull: false },
        browser: { type: DataTypes.STRING, allowNull: true },
        os: { type: DataTypes.STRING, allowNull: true }
    };

    const options = {
        defaultScope: {
            // exclude hash by default
            attributes: { exclude: ['hash'] }
        },
        scopes: {
            // include hash with this scope
            withHash: { attributes: {}, }
        }
    };

    return sequelize.define('UserLogin', attributes, options);
}