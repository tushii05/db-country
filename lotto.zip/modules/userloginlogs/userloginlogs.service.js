﻿const db = require('../../_helpers/db');
const { Op } = require("sequelize");


module.exports = {
    getAll,
    store,
    getAllUser
};
async function getAll(id, { offset = 0, limit = 100, orderBy = 'id', orderType = 'DESC', search = null }) {
    let where = { UserId: id };
    if (search !== null) {
        where = {
            [Op.or]: [
                { userIp: { [Op.like]: `%${search}%` } },
                { city: { [Op.like]: `%${search}%` } },
                { country: { [Op.like]: `%${search}%` } },
                { '$User.fname$': { [Op.like]: `%${search}%` } }
            ]
        }
    }
    return await db.UserLoginLogs.findAndCountAll({
        where,
        include: [{
            model: db.User,
            required: false
        }],
        offset: parseInt(offset),
        limit: parseInt(limit),
        order: [[orderBy, orderType]]
    });
}


async function getAllUser({ offset = 0, limit = 100, orderBy = 'id', orderType = 'DESC' }) {
    return await db.UserLoginLogs.findAll({
        include: [{
            model: db.User,
            required: false,
            attributes: ["id", "fname", "lname", "email"]
        }],
        offset: parseInt(offset),
        limit: parseInt(limit),
        order: [[orderBy, orderType]]
    });
}



async function store(params, id) {
    const User = await db.User.scope('withHash').findOne({ where: { id: id } });
    if (!User) throw 'Username or password is incorrect';
    params.UserId = id;
    return await db.UserLoginLogs.create(params);
}