﻿const express = require('express');
const router = express.Router();
const Joi = require('joi');
const { validateRequest } = require('../../_middleware/validate-request');
const userLoginService = require('./userloginlogs.service');

// routes

router.get('/:id', getAllSchema, getAll);
router.post('/store/:id', storeSchema, store);
router.get('/', getAllSchemaUser, getAllUser);


//Google Logins

module.exports = router;
function getAllSchema(req, res, next) {
    const schema = Joi.object({
        offset: Joi.number().integer().min(0).empty(''),
        limit: Joi.number().integer().min(1).empty(''),
        orderBy: Joi.string().valid('id', 'createdAt', 'fname', 'email').empty(''),
        orderType: Joi.string().valid('DESC', 'ASC').empty(''),
        search: Joi.string().empty('')
    });
    validateRequest(req, next, schema, 'query');
}

function getAll(req, res, next) {
    userLoginService.getAll(req.params.id, req.query)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function storeSchema(req, res, next) {
    const schema = Joi.object({
        userIp: Joi.string().empty(''),
        city: Joi.string().empty(''),
        country: Joi.string().empty(''),
        // countryCode: Joi.string().empty(''),
        region: Joi.string().empty(''),
        longitude: Joi.string().empty(''),
        latitude: Joi.string().empty(''),
        browser: Joi.string().empty(''),
        os: Joi.string().empty('')
    });
    validateRequest(req, next, schema);
}

function store(req, res, next) {
    userLoginService.store(req.body, req.params.id)
        .then(data => res.json({ message: "Success", data }))
        .catch(next);
}


function getAllSchemaUser(req, res, next) {
    const schema = Joi.object({
        offset: Joi.number().integer().min(0).empty(''),
        limit: Joi.number().integer().min(1).empty(''),
        orderBy: Joi.string().valid('id', 'createdAt').empty(''),
        orderType: Joi.string().valid('DESC', 'ASC').empty(''),
        search: Joi.string().empty('')
    });
    validateRequest(req, next, schema,);
}

function getAllUser(req, res, next) {
    userLoginService.getAllUser(req.query)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}
