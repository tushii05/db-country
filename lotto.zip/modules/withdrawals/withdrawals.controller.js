const express = require('express');
const router = express.Router();
const Joi = require('joi');
const authorize = require('../../_middleware/user');
const { validateRequest } = require('../../_middleware/validate-request');
const withdrawalsService = require('./withdrawals.service');

// routes
router.get('/', getAllSchema, getAll);
router.post('/store', storeSchema, store);
router.get('/:id', getById);
router.put('/:id', update);
router.delete('/:id', _delete);
module.exports = router;
// currency section
function getAllSchema(req, res, next) {
    const schema = Joi.object({
        offset: Joi.number().integer().min(0).empty(''),
        limit: Joi.number().integer().min(1).empty(''),
        orderBy: Joi.string().valid('id', 'createdAt', 'name', 'code').empty(''),
        orderType: Joi.string().valid('DESC', 'ASC').empty(''),
        search: Joi.string().empty(''),
    });
    validateRequest(req, next, schema, 'query');
}

function getAll(req, res, next) {
    withdrawalsService.getAll(req.query)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function store(req, res, next) {
    withdrawalsService.create(req.body)
        .then(data => { res.json({ message: 'Success', data }) })
        .catch(next);
}

function storeSchema(req, res, next) {
    const schema = Joi.object({
        UserId: Joi.number().integer().required(),
        Account_Holder_Name: Joi.string().required(),
        Account_Number: Joi.number().required(),
        Type_of_account: Joi.string().required(),
        IFSC_Number: Joi.string().required(),
        Email: Joi.string().email().required(),
        PanCard_No: Joi.string().required(''),
        Amount: Joi.number().required(''),
        tansactionId: Joi.string().empty(''),
    });
    validateRequest(req, next, schema);
}

function getById(req, res, next) {
    withdrawalsService.getById(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function update(req, res, next) {
    withdrawalsService.update(req.params.id, req.body)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function _delete(req, res, next) {
    withdrawalsService._delete(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}