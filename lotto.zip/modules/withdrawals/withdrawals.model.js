const { DataTypes, literal } = require('sequelize');

module.exports = model;

function model(sequelize) {
    const attributes = {
        Account_Holder_Name: { type: DataTypes.STRING, allowNull: false },
        Account_Number: { type: DataTypes.STRING, allowNull: false },
        Type_of_account: { type: DataTypes.STRING, allowNull: false },
        IFSC_Number: { type: DataTypes.STRING, allowNull: false },
        Email: { type: DataTypes.STRING, allowNull: false },
        PanCard_No: { type: DataTypes.TEXT, allowNull: false },
        Amount: { type: DataTypes.STRING, allowNull: false },
        tansactionId: { type: DataTypes.STRING, allowNull: true },
        status: { type: DataTypes.TINYINT, allowNull: false, defaultValue: 0, comment: "0: pending, 1: Approved, 2: Rejected" },
    };

    const options = {
        defaultScope: {
            // exclude hash by default
            attributes: { exclude: [''] }
        },
        scopes: {
            // include hash with this scope
            withHash: { attributes: {}, }
        }
    };

    return sequelize.define('Withdrawals', attributes, options);
}