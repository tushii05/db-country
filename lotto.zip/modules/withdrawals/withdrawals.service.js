const db = require('../../_helpers/db');
const { Sequelize, literal } = require('sequelize');
const { Op } = require("sequelize");
module.exports = {
    getAll,
    getById,
    create,
    update,
    _delete
};
async function getAll({ offset = 0, orderBy = 'id', orderType = 'DESC', search = null }) {
    let where = {};
    if (search !== null) {
        where = {
            [Op.or]: [
                { Account_Number: { [Op.like]: `%${search}%` } }
            ]
        }
    }

    const gameInfoCount = await db.Withdrawals.count({
        where
    });

    return await db.Withdrawals.findAll({
        where,
        include: [{
            model: db.User,
            include: [
                {
                    attributes: ['id', 'tansactionId', 'type', 'amount', 'currency', 'sender', 'receiver', 'description', 'balance', 'transactionType', 'lotteryId', 'tickets', 'status'],
                    model: db.UserTransaction,
                    as: "withdraw",
                    required: false,
                    where: {
                        transactionType: {
                            [Op.eq]: "Withdraw"
                        }
                    }
                }
            ]
        }],
        offset: parseInt(offset),
        // limit: parseInt(limit),
        order: [[orderBy, orderType]],
    }).then((rows) => {
        return {
            count: gameInfoCount,
            rows
        };
    });
}

async function getById(id) {
    return await getWithdrawals(id);
}

async function create(params) {
    const d = await db.Withdrawals.create(params);
    return d;
}

async function update(id, params) {
    const Withdrawals = await db.Withdrawals.findOne({ where: { id: id } });
    if (!Withdrawals) throw 'Withdrawals not found'
    Object.assign(Withdrawals, params);
    return await Withdrawals.save();
}

// helper functions
async function getWithdrawals(id) {
    const Withdrawals = await db.Withdrawals.findByPk(id);
    if (!Withdrawals) throw 'Withdrawals not found';
    return await db.Withdrawals.findOne({
        where: { id: id },
        include: [{
            model: db.User,
            include: [
                { model: db.UserTransaction }
            ]
        }]
    });
}

async function _delete(id) {
    const Withdrawals = await db.Withdrawals.findOne({ where: { id: id } });
    if (Withdrawals) {
        await Withdrawals.destroy();
        return true;
    }
}