const express = require('express');
const router = express.Router();
const Joi = require('joi');
const { validateRequest } = require('../../_middleware/validate-request');
const subscribeService = require('./subscribe.service');

// routes
router.get('/', getAllSchema, getAll);
router.post('/store', store);
router.get('/:id', getById);
router.put('/:id', update);
router.delete('/:id', _delete);
module.exports = router;
// currency section
function getAllSchema(req, res, next) {
    const schema = Joi.object({
        offset: Joi.number().integer().min(0).empty(''),
        limit: Joi.number().integer().min(1).empty(''),
        orderBy: Joi.string().valid('id', 'createdAt', 'name', 'code').empty(''),
        orderType: Joi.string().valid('DESC', 'ASC').empty(''),
        search: Joi.string().empty(''),
    });
    validateRequest(req, next, schema, 'query');
}
function getAll(req, res, next) {
    subscribeService.getAll(req.query)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function store(req, res, next) {
    const { mail } = req.body;
    db.Subscribe.findOne({ where: { mail } })
        .then(existingSubscription => {
            if (existingSubscription) {
                res.status(400).json({ message: 'Mail already subscribed' });
            } else {
                subscribeService.create(req.body, mail) // pass the mail parameter
                    .then(data => { res.json({ message: 'Success', data }) })
                    .catch(next);
            }
        })
        .catch(next);
}


function getById(req, res, next) {
    subscribeService.getById(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}
function update(req, res, next) {
    subscribeService.update(req.params.id, req.body)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function _delete(req, res, next) {
    subscribeService._delete(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}