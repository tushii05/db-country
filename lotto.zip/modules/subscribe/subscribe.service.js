const db = require('../../_helpers/db');
const { Op } = require("sequelize");
const { sendEmail } = require('../../_middleware/email');
module.exports = {
    getAll,
    getById,
    create,
    update,
    _delete
};
async function getAll({ offset = 0, orderBy = 'id', orderType = 'ASC', search = null }) {
    let where = { status: 1 };
    if (search !== null) {
        where = {
            [Op.or]: [
                { email: { [Op.like]: `%${search}%` } }
            ]
        }
    }
    return await db.Subscribe.findAndCountAll({
        where,
        offset: parseInt(offset),
        // limit: parseInt(limit),
        order: [[orderBy, orderType]]
    });
}

async function getById(id) {
    return await getSubscribe(id);
}

async function create(params, mail) {
    if (!mail) {
        throw new Error("Email address is required.");
    }
    let mailPrefix = mail.split("@")[0];
    mailPrefix = mailPrefix.charAt(0).toUpperCase() + mailPrefix.slice(1);
    const html = `Hi ${mailPrefix} <br>
    Thankyou for subscribing Lifetime Lotto newsletter!! You are now member of our community. <br>
    You will be notified of latest updates here.<br><br>
    
    Thankyou for being our valued member. <br>
    The team Lifetime Lotto.`;
    const subject = "Thankyou for subscribing";
    await sendEmail(mail, subject, html);
    const d = await db.Subscribe.create({ ...params, mail });
    return d;
}

async function update(id, params) {
    const Subscribe = await db.Subscribe.findOne({ where: { id: id } });
    if (!Subscribe) throw 'Subscribe not found'
    Object.assign(Subscribe, params);
    return await Subscribe.save();
}

// helper functions Tushar Deshmukh  😊😊😊
async function getSubscribe(id) {
    const Subscribe = await db.Subscribe.findByPk(id);
    if (!Subscribe) throw 'Subscribe not found';
    return Subscribe;
}

async function _delete(id) {
    const Subscribe = await db.Subscribe.findOne({ where: { id: id } });
    if (Subscribe) {
        await Subscribe.destroy();
        return true;
    }
}