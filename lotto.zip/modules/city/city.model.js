const { DataTypes, literal } = require('sequelize');

module.exports = model;

function model(sequelize) {
    const attributes = {
        cityName: { type: DataTypes.STRING, allowNull: false },
        StateId: { type: DataTypes.INTEGER, allowNull: false }
    };
    const options = {
        defaultScope: {
            // exclude hash by default
            attributes: { exclude: [''] }
        },
        scopes: {
            // include hash with this scope
            withHash: { attributes: {}, }
        }
    };
    return sequelize.define('Cities', attributes, options);
}