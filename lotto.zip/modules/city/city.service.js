const db = require('../../_helpers/db');

module.exports = {
    getAll,
    getAllWithStates,
    getById,
    create
};


async function getAll({ offset = 0, orderBy = 'id', orderType = 'DESC', search = null }) {
    const [cities, count] = await Promise.all([
        db.Cities.findAll({
            offset: parseInt(offset),
            order: [[orderBy, orderType]],
        }),
        db.Cities.count()
    ]);
    return { count, cities };
}


async function getAllWithStates({ offset = 0, orderBy = 'id', orderType = 'DESC', search = null }) {
    const [cities, count] = await Promise.all([
        db.Cities.findAll({
            include: [
                { model: db.States }
            ],
            offset: parseInt(offset),
            order: [[orderBy, orderType]],
        }),
        db.Cities.count()
    ]);
    return { count, cities };
}


async function getById(id) {
    return await getCities(id);
}
async function create(params) {
    const d = await db.Cities.create(params);
    return d;
}

// Helper Functions

async function getCities(id) {
    const Cities = await db.Cities.findOne({
        where: { id: id },
        include: [{ model: db.States }],
    });
    if (!Cities) throw 'Cities not found';
    return Cities;
}
