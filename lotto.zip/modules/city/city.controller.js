const express = require('express');
const router = express.Router();
const Joi = require('joi');
const { validateRequest } = require('../../_middleware/validate-request');
const citiesService = require('./city.service');
module.exports = router;


router.get('/', getAllSchema, getAll);
router.get('/states', getAllSchema, getAllWithStates);
router.post('/store', storeSchema, store);
router.get('/:id', getById);
module.exports = router;

function getAllSchema(req, res, next) {
    const schema = Joi.object({
        offset: Joi.number().integer().min(0).empty(''),
        limit: Joi.number().integer().min(1).empty(''),
        orderBy: Joi.string().valid('id', 'createdAt').empty(''),
        orderType: Joi.string().valid('DESC', 'ASC').empty(''),
        search: Joi.string().empty(''),
    });
    validateRequest(req, next, schema, 'query');
}

function getAll(req, res, next) {
    citiesService.getAll(req.query)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function getAllWithStates(req, res, next) {
    citiesService.getAllWithStates(req.query)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function store(req, res, next) {
    citiesService.create(req.body)
        .then(data => { res.json({ message: 'Success', data }) })
        .catch(next);
}

function storeSchema(req, res, next) {
    const schema = Joi.object({
        name: Joi.string().required(),
        StateId: Joi.number().required()
    });
    validateRequest(req, next, schema);
}

function getById(req, res, next) {
    citiesService.getById(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}