const express = require('express');
const router = express.Router();
const Joi = require('joi');
const { validateRequest } = require('../../_middleware/validate-request');
const statesService = require('./states.service');
module.exports = router;

// routes
router.get('/', getAllSchema, getAll);
router.get('/city', getAllSchema, getAllWithCity);
router.post('/store', storeSchema, store);
router.get('/:id', getById);
module.exports = router;

// currency section

function getAllSchema(req, res, next) {
    const schema = Joi.object({
        offset: Joi.number().integer().min(0).empty(''),
        limit: Joi.number().integer().min(1).empty(''),
        orderBy: Joi.string().valid('id', 'createdAt').empty(''),
        orderType: Joi.string().valid('DESC', 'ASC').empty(''),
        search: Joi.string().empty(''),
    });
    validateRequest(req, next, schema, 'query');
}
function getAll(req, res, next) {
    statesService.getAll(req.query)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}
function getAllWithCity(req, res, next) {
    statesService.getAllWithCity(req.query)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function store(req, res, next) {
    statesService.create(req.body)
        .then(data => { res.json({ message: 'Success', data }) })
        .catch(next);
}
function storeSchema(req, res, next) {
    const schema = Joi.object({
        name: Joi.string().required(),
        CountryId: Joi.number().required()
    });
    validateRequest(req, next, schema);
}

function getById(req, res, next) {
    statesService.getById(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

