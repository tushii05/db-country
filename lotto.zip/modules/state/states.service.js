const db = require('../../_helpers/db');
const { Sequelize, literal } = require('sequelize');

module.exports = {
    getAll,
    getAllWithCity,
    getById,
    create
};

async function getAllWithCity({ offset = 0, limit = 100, orderBy = 'id', orderType = 'DESC', search = null }) {
    return await db.States.findAndCountAll({
        include: [
            { model: db.Cities }
        ],
        offset: parseInt(offset),
        limit: parseInt(limit),
        order: [[orderBy, orderType]]
    });
}

async function getAll({ offset = 0, orderBy = 'id', orderType = 'DESC', search = null }) {
    const [states, count] = await Promise.all([
        db.States.findAll({
            offset: parseInt(offset),
            order: [[orderBy, orderType]],
        }),
        db.States.count()
    ]);
    return { count, states };
}

async function getById(id) {
    return await getStates(id);
}
async function create(params) {
    const d = await db.States.create(params);
    return d;
}

// helper functions
async function getStates(id) {
    const States = await db.States.findOne({
        where: { id: id },
        include: [{ model: db.Cities }],
    });
    if (!States) throw 'States not found';
    return States;
}
