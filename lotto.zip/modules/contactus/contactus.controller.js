const nodemailer = require('nodemailer');
const db = require('../../_helpers/db')
const express = require('express');
const router = express.Router();


router.post('/contact-us', sendEmail);

module.exports = router;

async function sendEmail(req, res) {
    const { fname, lname, mail, number, message } = req.body;

    try {
        const transporter = nodemailer.createTransport({
            host: process.env.SMTP_HOST,
            port: 465,
            secure: true,
            auth: {
                user: process.env.SMTP_USER,
                pass: process.env.SMTP_PASS,
            },
        });
        const mailOptions = {
            from: process.env.SMTP_USER,
            to: 'agnito14@gmail.com',
            subject: 'New Contact Form Submission',
            html: `
                <div style="background-color: #f0f0f0; padding: 20px;">
                    <h2 style="color: #007bff;">New Contact Form Submission</h2>
                    <p style="font-size: 16px;">Dear Admin,</p>
                    <p style="font-size: 16px;">A new contact form has been submitted on your website. Here are the details:</p>
        
                    <p style="font-size: 16px;"><strong>Name:</strong> ${fname} ${lname}</p>
                    <p style="font-size: 16px;"><strong>Email:</strong> ${mail}</p>
                    <p style="font-size: 16px;"><strong>Phone Number:</strong> ${number}</p>
                    <p style="font-size: 16px;"><strong>Message:</strong> ${message}</p>
        
                    <p style="font-size: 16px;">Please take appropriate action to respond to this inquiry as soon as possible.</p>
        
                    <p style="font-size: 16px;">Thank you,<br>The Website Team</p>
                </div>
            `,
        };

        const info = await transporter.sendMail(mailOptions);

        const email = await db.ContactUs.create({
            fname: fname,
            lname: lname,
            mail: mail,
            number: number,
            message: message,
        });

        res.status(200).json({ message: 'Contact  successfully!', email });
    } catch (err) {
        console.log(err);
        res.status(500).json({ message: 'Error Contact ' });
    }
};


