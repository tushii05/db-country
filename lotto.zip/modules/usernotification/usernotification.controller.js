const db = require('../../_helpers/db')
const express = require('express');
const router = express.Router();
const { sendEmail } = require('../../_middleware/email');


router.post('/send/all', sendEmailToAllUsers)

module.exports = router;

async function sendEmailToAllUsers(req, res) {
    const { subject, text } = req.body;
    try {
      
        const users = await db.User.findAll({ attributes: ['email'] });
        const emails = users.map(user => user.email);

 
        const promises = emails.map(email => {
            return sendEmail(email, subject, text).then(() => {
     
                return db.UserNotification.create({
                    to: email,
                    subject: subject,
                    text: text,
                    status: 'sent',
                });
            });
        });
        await Promise.race(promises);

        res.status(200).json({ message: 'Emails sent successfully!' });
    } catch (err) {
        console.log(err);
        res.status(500).json({ message: 'Error sending emails' });
    }
}