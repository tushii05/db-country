﻿const express = require('express');
const router = express.Router();
const Joi = require('joi');
const { validateRequest } = require('../../_middleware/validate-request');
const authorize = require('../../_middleware/user');
const userService = require('./usertransaction.service');


router.post('/store', authorize.user(), registerSchema, register);
router.post('/store/win', registerSchema, winRegister);
router.get('/', getAllSchema, getAll);
router.post('/api', createTransaction);

router.post('/admin/Withdraw', authorize.admin(), adminWithdraw);
router.post('/admin/deposit', authorize.admin(), adminDeposit);

router.get('/count/:scratchCardId', getCount);

router.post('/commission/store', userCommission);

module.exports = router;

function registerSchema(req, res, next) {
    const schema = Joi.object({
        type: Joi.string().empty(''),
        tansactionId: Joi.string().empty(''),
        amount: Joi.number().empty(''),
        currency: Joi.string().empty(''),
        sender: Joi.string().empty(''),
        receiver: Joi.string().empty(''),
        description: Joi.string().empty(''),
        status: Joi.string().empty(''),
        transactionType: Joi.string().empty(''),
        lotteryId: Joi.number().integer().empty(''),
        scratchCardId: Joi.number().integer().empty(''),
        userId: Joi.number().integer().empty(''),
        tickets: Joi.string().empty('')

    });
    validateRequest(req, next, schema);
}
function register(req, res, next) {
    userService.create(req.user, req.body).then(data => {
        res.json({ message: 'Success', data })
    }).catch(next);
}

// function winRegister(req, res, next) {
//     const { userId } = req.body;

//     if (!userId) {
//         return res.status(400).json({ message: 'Invalid userId' });
//     }

//     userService.winCreate(userId, req.body)
//         .then(data => {
//             res.json({ message: 'Success', data });
//         })
//         .catch(next);
// }

function winRegister(req, res, next) {
    const { userId, tickets } = req.body;

    if (!userId || !tickets) {
        return res.status(400).json({ message: 'Invalid userId or tickets' });
    }

    userService.winCreate({ id: userId }, req.body)
        .then(data => {
            res.json({ message: 'Success', data });
        })
        .catch(next);
}


async function createTransaction(req, res, next) {
    try {
        const userId = req.body.userId;
        const user = await db.User.findByPk(userId);
        if (!user) {
            throw new Error('User not found');
        }

        req.body.WithdrawalId = req.body.withdrawalId;

        const transaction = await userService.createTransaction(user, req.body);
        res.status(201).json(transaction);
    } catch (error) {
        next(error);
    }
}



function getAllSchema(req, res, next) {
    const schema = Joi.object({
        offset: Joi.number().integer().min(0).empty(''),
        limit: Joi.number().integer().min(1).empty(''),
        orderBy: Joi.string().valid('id', 'createdAt', 'fname', 'email').empty(''),
        orderType: Joi.string().valid('DESC', 'ASC').empty('')
    });
    validateRequest(req, next, schema, 'query');
}

function getAll(req, res, next) {
    userService.getAll(req.query)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

async function getCount(req, res, next) {
    const { scratchCardId } = req.params;
    try {
        const count = await userService.getCount(scratchCardId);
        res.json({ message: 'Success', count });
    } catch (error) {
        next(error);
    }
}

// Helper functions Tushar_🙂🙂🙂🙂

async function adminWithdraw(req, res, next) {
    try {
        const userId = req.body.userId;
        const user = await db.User.findByPk(userId);
        if (!user) {
            throw new Error('User not found');
        }
        const transaction = await userService.adminWithdraw(user, req.body);
        res.status(201).json(transaction);
    } catch (error) {
        next(error);
    }
}


async function adminDeposit(req, res, next) {
    try {
        const userId = req.body.userId;
        const user = await db.User.findByPk(userId);
        if (!user) {
            throw new Error('User not found');
        }
        const transaction = await userService.adminDeposit(user, req.body);
        res.status(201).json(transaction);
    } catch (error) {
        next(error);
    }
}


async function userCommission(req, res, next) {
    try {
        const userId = req.body.userId;
        const user = await db.User.findByPk(userId);
        if (!user) {
            throw new Error('User not found');
        }
        const transaction = await userService.winCommission(user, req.body);
        res.json({ message: 'Success', transaction });
    } catch (error) {
        next(error);
    }
}