﻿const db = require('../../_helpers/db');
const { Sequelize, literal } = require('sequelize');
const { sendEmail } = require('../../_middleware/email');
const { generateTransactionId } = require('../../_middleware/random-number')
module.exports = {
    getAll,
    create,
    winCreate,
    createTransaction,
    adminWithdraw,
    adminDeposit,
    getCount,
    winCommission
};

// async function getAll({ offset = 0, orderBy = 'id', orderType = 'DESC', search = null }) {
//     let where = {};
//     if (search !== null) {
//         where = {
//             [Op.or]: [
//                 { tansactionId: { [Op.like]: `%${search}%` } },
//                 { type: { [Op.like]: `%${search}%` } }
//             ]
//         }
//     }
//     const depositCount = await db.UserTransaction.count({
//         where: {
//             transactionType: 'Deposit',
//             ...where
//         }
//     });
//     const winningCount = await db.UserTransaction.count({
//         where: {
//             transactionType: 'Winning',
//             ...where
//         }
//     });
//     const withdrawCount = await db.UserTransaction.count({
//         where: {
//             transactionType: 'Withdraw',
//             ...where
//         }
//     });
//     const purchaseCount = await db.UserTransaction.count({
//         where: {
//             transactionType: 'Purchase',
//             ...where
//         }
//     });
//     const Card_PurchaseCount = await db.UserTransaction.count({
//         where: {
//             transactionType: 'Card_Purchase',
//             ...where
//         }
//     });
//     const Card_WonCount = await db.UserTransaction.count({
//         where: {
//             transactionType: 'Card_Won',
//             ...where
//         }
//     });
//     const adminWithdrawCount = await db.UserTransaction.count({
//         where: {
//             transactionType: 'AdminWithdraw',
//             ...where
//         }
//     });
//     const adminDepositCount = await db.UserTransaction.count({
//         where: {
//             transactionType: 'AdminDeposit',
//             ...where
//         }
//     });
//     const result = await db.UserTransaction.findAndCountAll({
//         where,
//         offset: parseInt(offset),
//         // limit: parseInt(limit),
//         order: [[orderBy, orderType]]
//     });
//     const Card_WonRows = result.rows.filter(row => row.transactionType === 'Card_Won');

//     return {
//         depositCount,
//         winningCount,
//         withdrawCount,
//         purchaseCount,
//         adminDepositCount,
//         adminWithdrawCount,
//         Card_PurchaseCount,
//         Card_WonCount,
//         count: result.count,
//         rows: result.rows,
//         Card_WonRows: Card_WonRows
//     };
// }
async function getAll({ offset = 0, orderBy = 'id', orderType = 'DESC', search = null }) {
    let where = {};
    if (search !== null) {
        where = {
            [Op.or]: [
                { tansactionId: { [Op.like]: `%${search}%` } },
                { type: { [Op.like]: `%${search}%` } }
            ]
        }
    }

    const [depositCount, winningCount, withdrawCount, purchaseCount, Card_PurchaseCount, Card_WonCount, adminWithdrawCount, adminDepositCount, result] = await Promise.all([
        db.UserTransaction.count({ where: { transactionType: 'Deposit', ...where } }),
        db.UserTransaction.count({ where: { transactionType: 'Winning', ...where } }),
        db.UserTransaction.count({ where: { transactionType: 'Withdraw', ...where } }),
        db.UserTransaction.count({ where: { transactionType: 'Purchase', ...where } }),
        db.UserTransaction.count({ where: { transactionType: 'Card_Purchase', ...where } }),
        db.UserTransaction.count({ where: { transactionType: 'Card_Won', ...where } }),
        db.UserTransaction.count({ where: { transactionType: 'AdminWithdraw', ...where } }),
        db.UserTransaction.count({ where: { transactionType: 'AdminDeposit', ...where } }),
        db.UserTransaction.count({ where: { transactionType: 'Commission', ...where } }),
        db.UserTransaction.findAndCountAll({ where, offset: parseInt(offset), order: [[orderBy, orderType]] })
    ]);

    const Card_WonRows = result.rows.filter(row => row.transactionType === 'Card_Won');

    return {
        depositCount,
        winningCount,
        withdrawCount,
        purchaseCount,
        adminDepositCount,
        adminWithdrawCount,
        Card_PurchaseCount,
        Card_WonCount,
        count: result.count,
        rows: result.rows,
        Card_WonRows
    };
}


async function create(user, params) {
    const UserTrasaction = await db.UserTransaction.findOne({ where: { UserId: user.id } });
    params.tansactionId = params.tansactionId;
    params.UserId = user.id;
    const Trasactions = await db.UserTransaction.findOne({
        where: { UserId: user.id },
        order: [['id', 'DESC']],
    });
    if (params.transactionType == "Withdraw") {
        if (!UserTrasaction) {
            params.transactionType = params.transactionType;
            params.balance = user.balance - params.amount;
        } else {
            if (Trasactions.dataValues.balance >= params.amount) {
                params.transactionType = params.transactionType;
                params.balance = Trasactions.dataValues.balance - params.amount;
            } else {
                throw 'Insufficient Balance'
            }
            if (Trasactions.dataValues.balance < 1) {
                throw 'Insufficient Balance'
            }
        }

        const transporter = nodemailer.createTransport({
            host: process.env.SMTP_HOST,
            port: 465,
            secure: true,
            auth: {
                user: process.env.SMTP_USER,
                pass: process.env.SMTP_PASS,
            },
        });
        const mailOptions = {
            from: process.env.SMTP_USER,
            to: user.email,
            subject: "Withdrawal Successful",
            html: `Dear <b>${user.fname} ${user.lname}</b>,<br> <br>
            Your Withdraw of amount is ₹ <b> ${params.amount}</b> INR was Successful, See your transactions <a href="${process.env.ASSET_URL}/withdrawal-history" >Here</a>. <br>
            <a href="${process.env.ASSET_URL}/withdrawal" >Click Here</a> to add more amount into your wallet.
            <br>
            <br>
            The team Lifetime lotto.`
        };

        await transporter.sendMail(mailOptions);

    } else if (params.transactionType == "Winning") {
        params.tickets = params.tickets.toString();
        params.balance = Trasactions ? parseInt(Trasactions.dataValues.balance) + parseInt(params.amount) : parseInt(user.balance) + parseInt(params.amount);

        const html = `Dear <b>${user.fname} ${user.lname}</b>,<br> <br>
        Your Winning of amount is ₹ <b> ${params.amount}</b> INR was Successful, See your transactions <a href="${process.env.ASSET_URL}/withdrawal" >Here</a>. <br>
        <a href="${process.env.ASSET_URL}/login" >Click Here</a> to add more amount into your wallet.
        <br>
        <br>
        The team Lifetime lotto.`;
        const subject = "Winning Amount  Successful";
        await sendEmail(user.email, subject, html);



    } else if (params.transactionType == "Purchase") {
        params.transactionType = params.transactionType;
        params.balance = Trasactions ? parseInt(Trasactions.dataValues.balance) - parseInt(params.amount) : parseInt(user.balance) - parseInt(params.amount);

        const html = `Dear <b>${user.fname} ${user.lname}</b>,<br> <br>
        Your Purchase of amount is ₹ <b> ${params.amount}</b> INR was Successful, See your transactions <a href="${process.env.ASSET_URL}/transactions" >Here</a>. <br>
        <a href="${process.env.ASSET_URL}/login" >Click Here</a> to add more amount into your wallet.
        <br>
        <br>
        The team Lifetime lotto.`;
        const subject = "Wallet Ticket Purchase Successful";
        await sendEmail(user.email, subject, html);


    }
    else if (params.transactionType == "Card_Purchase") {
        params.transactionType = params.transactionType;
        params.balance = Trasactions ? parseInt(Trasactions.dataValues.balance) - parseInt(params.amount) : parseInt(user.balance) - parseInt(params.amount);

        const html = `Dear <b>${user.fname} ${user.lname}</b>,<br><br>
        Your Purchase of amount is ₹ <b> ${params.amount}</b> INR was Successful, See your transactions <a href="${process.env.ASSET_URL}/transactions" >Here</a>. <br>
        <a href="${process.env.ASSET_URL}/login" >Click Here</a> to add more amount into your wallet.
        <br>
        <br>
        The team Lifetime lotto.`;
        const subject = "Scratch_Card_Purchase Successful";
        await sendEmail(user.email, subject, html);
    }
    // else if (params.transactionType == "Card_Won") {
    //     params.transactionType = params.transactionType;
    //     params.balance = Trasactions ? parseInt(Trasactions.dataValues.balance) + parseInt(params.amount) : parseInt(user.balance) + parseInt(params.amount);

    //     const currentTotalScratchCardWon = await db.User.findOne({
    //         where: { id: params.UserId },
    //         attributes: ['totalScratchCardWon']
    //     });

    //     const currentWonValue = await db.scratchCardPlay.findOne({
    //         where: { UserId: params.UserId, scratchCardId: params.scratchCardId },
    //         attributes: ['won']
    //     });
    //     const newWonValue = currentWonValue.won + parseInt(params.amount);
    //     const newTotalScratchCardWon = currentTotalScratchCardWon.totalScratchCardWon + parseInt(params.amount);

    //     const html = `Dear <b>${user.fname} ${user.lname}</b>,<br><br>
    //     Your Won of amount is ₹ <b> ${params.amount}</b> INR was Successful, See your transactions <a href="${process.env.ASSET_URL}/transactions" >Here</a>. <br>
    //     <a href="${process.env.ASSET_URL}/login" >Click Here</a> to add more amount into your wallet.
    //     <br>
    //     <br>
    //     The team Lifetime lotto.`;

    //     const subject = "Scratch_Card_Won Successful";

    //     await sendEmail(user.email, subject, html);

    //     await db.scratchCardPlay.update(
    //         { won: newWonValue },
    //         { where: { UserId: params.UserId, scratchCardId: params.scratchCardId } }
    //     );
    //     await db.User.update(
    //         { totalScratchCardWon: newTotalScratchCardWon },
    //         { where: { id: params.UserId } }
    //     );
    // }

    else if (params.transactionType === "Card_Won") {
        const { amount, UserId, scratchCardId } = params;
        // const { balance, fname, lname, email } = user;
        const { balance } = user;

        params.balance = Trasactions
            ? parseInt(Trasactions.dataValues.balance) + parseInt(amount)
            : parseInt(balance) + parseInt(amount);

        await db.scratchCardPlay.increment('won', { by: parseInt(amount), where: { UserId, scratchCardId } });
        await db.scratchCard.increment(
            { winning_card: db.sequelize.literal('winning_card + 1') },
            { where: { scratchCardId } }
        );
        await db.User.increment('totalScratchCardWon', { by: parseInt(amount), where: { id: UserId } });
    }


    else {
        // Deposit 
        params.transactionType = params.transactionType;
        params.balance = Trasactions ? parseInt(Trasactions.dataValues.balance) + parseInt(params.amount) : parseInt(user.balance) + parseInt(params.amount);

        const html = `Dear <b>${user.fname} ${user.lname}</b>,<br> <br>
        Your Deposit of amount is ₹ <b> ${params.amount}</b> INR was Successful, See your transactions <a href="${process.env.ASSET_URL}/deposites" >Here</a>. <br>
        <a href="${process.env.ASSET_URL}/login" >Click Here</a> to add more amount into your wallet.
        <br>
        <br>
        The team Lifetime lotto.`;
        const subject = "Wallet Deposit Successful";
        await sendEmail(user.email, subject, html);

    }
    const buyTicket = await db.UserTransaction.create(params)
    await db.buyTicket.update({ BuyTicketId: buyTicket.id }, { where: { id: buyTicket.id } })
    await db.User.update({ balance: params.balance }, { where: { id: user.id } });
}


// Helper functions Tushar_🙂🙂🙂🙂

async function createTransaction(user, params) {
    if (!user) {
        throw new Error('User not found');
    }
    const UserTransaction = await db.UserTransaction.findOne({ where: { UserId: user.id } });
    params.tansactionId = params.tansactionId;
    params.UserId = user.id;
    params.WithdrawalId = params.withdrawalId;
    const Trasactions = await db.UserTransaction.findOne({
        where: { UserId: user.id },
        order: [['id', 'DESC']],
    });
    if (params.transactionType == 'Withdraw') {
        if (!UserTransaction) {
            params.transactionType = params.transactionType;
            params.balance = user.balance - params.amount;
        } else {
            if (Trasactions.dataValues.balance >= params.amount) {
                params.transactionType = params.transactionType;
                params.balance = Trasactions.dataValues.balance - params.amount;
            } else {
                throw new Error('Insufficient Balance');
            }
            if (Trasactions.dataValues.balance < 1) {
                throw new Error('Insufficient Balance');
            }
        }
        const html = `Dear <b>${user.fname} ${user.lname}</b>,<br> <br>
            Your Withdraw of amount is ₹ <b> ${params.amount}</b> INR was Successful, See your transactions <a href="${process.env.ASSET_URL}/withdrawal-history" >Here</a>. <br>
            <a href="${process.env.ASSET_URL}/withdrawal" >Click Here</a> to add more amount into your wallet.
            <br>
            <br>
            The team Lifetime lotto.`;
        const subject = 'Withdrawal Successful';
        await sendEmail(user.email, subject, html);
    }
    const transaction = await db.UserTransaction.create(params);
    await db.Withdrawals.update({ tansactionId: params.tansactionId }, { where: { id: params.WithdrawalId } });
    await db.User.update({ balance: params.balance }, { where: { id: user.id } });
    return transaction;
}


async function adminWithdraw(user, params) {
    if (!user) {
        throw new Error('User not found');
    }
    const UserTransaction = await db.UserTransaction.findOne({ where: { UserId: user.id } });
    params.tansactionId = generateTransactionId();
    params.UserId = user.id;
    params.sender = params.sender;
    params.receiver = params.receiver;
    params.description = params.description;
    const Trasactions = await db.UserTransaction.findOne({
        where: { UserId: user.id },
        order: [['id', 'DESC']],
    });

    if (params.transactionType == 'AdminWithdraw') {
        if (!UserTransaction) {
            params.transactionType = params.transactionType;
            params.balance = user.balance - params.amount;
        } else {
            if (Trasactions.dataValues.balance >= params.amount) {
                params.transactionType = params.transactionType;
                params.balance = Trasactions.dataValues.balance - params.amount;
            } else {
                throw new Error('Insufficient  Balance');
            }
            if (params.balance < 1) {
                throw new Error('Insufficient Balance');
            }
        }
    }
    const transaction = await db.UserTransaction.create(params);
    await db.User.update({ balance: params.balance }, { where: { id: user.id } });
    return transaction;
}


async function adminDeposit(user, params) {
    if (!user) {
        throw new Error('User not found');
    }
    const UserTransaction = await db.UserTransaction.findOne({ where: { UserId: user.id } });
    params.tansactionId = generateTransactionId();
    params.UserId = user.id;
    params.sender = params.sender;
    params.receiver = params.receiver;
    params.description = params.description;
    const Trasactions = await db.UserTransaction.findOne({
        where: { UserId: user.id },
        order: [['id', 'DESC']],
    });
    if (params.transactionType == 'AdminDeposit') {
        params.transactionType = params.transactionType;
        params.balance = Trasactions ? parseInt(Trasactions.dataValues.balance) + parseInt(params.amount) : parseInt(user.balance) + parseInt(params.amount);
    }
    const transaction = await db.UserTransaction.create(params);
    await db.User.update({ balance: params.balance }, { where: { id: user.id } });
    return transaction;
}


async function getCount(scratchCardId) {
    const where = {};
    if (scratchCardId) {
        where.scratchCardId = scratchCardId;
    }
    const Card_WonCount = await db.UserTransaction.sum('amount', {
        where: {
            transactionType: 'Card_Won',
            scratchCardId: scratchCardId,
            ...where
        }
    });
    return {
        Card_WonCount,
    };
}




async function winCreate(user, params) {
    const UserTransaction = await db.UserTransaction.findOne({ where: { UserId: user.id } });
    params.tansactionId = generateTransactionId();
    params.UserId = user.id;
    const Transactions = await db.UserTransaction.findOne({
        where: { UserId: user.id },
        order: [['id', 'DESC']],
    });

    if (params.transactionType === "Winning") {
        if (params.tickets !== undefined) {
            params.tickets = params.tickets.toString();
        }
        params.balance = Transactions ? parseInt(Transactions.dataValues.balance) + parseInt(params.amount) : parseInt(user.balance) + parseInt(params.amount);
    }
    const buyTicket = await db.UserTransaction.create(params)
    await db.User.update({ balance: params.balance }, { where: { id: user.id } });
}

async function winCommission(user, params) {
    // const UserTransaction = await db.UserTransaction.findOne({ where: { UserId: user.id } });
    params.tansactionId = generateTransactionId();
    params.UserId = user.id;
    const Transactions = await db.UserTransaction.findOne({
        where: { UserId: user.id },
        order: [['id', 'DESC']],
    });

    if (params.transactionType === "Commission") {
        if (params.tickets !== undefined) {
            params.tickets = params.tickets.toString();
        }
        params.balance = Transactions ? parseInt(Transactions.dataValues.balance) + parseInt(params.amount) : parseInt(user.balance) + parseInt(params.amount);
    }
    const Commission = await db.UserTransaction.create(params)
    await db.User.update({ balance: params.balance }, { where: { id: user.id } });
}