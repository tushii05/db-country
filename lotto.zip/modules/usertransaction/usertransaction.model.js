const { DataTypes, literal } = require('sequelize');

module.exports = model;

function model(sequelize) {
    const attributes = {
        tansactionId: { type: DataTypes.STRING, allowNull: false },
        type: { type: DataTypes.STRING, allowNull: true, defaultValue: true },
        amount: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
        currency: { type: DataTypes.STRING, allowNull: true, defaultValue: true },
        sender: { type: DataTypes.STRING, allowNull: true, defaultValue: true },
        receiver: { type: DataTypes.STRING, allowNull: true, defaultValue: true },
        description: { type: DataTypes.STRING, allowNull: true, defaultValue: true },
        balance: { type: DataTypes.DOUBLE, allowNull: false, defaultValue: 0 },
        transactionType: { type: DataTypes.STRING, allowNull: true, defaultValue: true, comment: "0: Deposit, 1: Winning, 2: Withdraw, 3:Purchase, 4:AdminWithdraw, 5:AdminDeposit" },
        lotteryId: { type: DataTypes.INTEGER, allowNull: true, defaultValue: true },
        scratchCardId: { type: DataTypes.INTEGER, allowNull: true },
        tickets: { type: DataTypes.STRING, allowNull: true, defaultValue: true },
        status: { type: DataTypes.TINYINT, allowNull: false, defaultValue: 1 }
    };

    const options = {
        defaultScope: {
            // exclude hash by default
            attributes: { exclude: ['hash'] }
        },
        scopes: {
            // include hash with this scope
            withHash: { attributes: {}, }
        }
    };

    return sequelize.define('UserTransaction', attributes, options);
}