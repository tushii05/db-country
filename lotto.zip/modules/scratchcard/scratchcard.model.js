const { DataTypes, literal } = require('sequelize');

module.exports = model;

function model(sequelize) {
    const attributes = {
        card_name: { type: DataTypes.STRING, allowNull: false },
        ticketPrize: { type: DataTypes.INTEGER, allowNull: false },
        game_slogan: { type: DataTypes.STRING, allowNull: false },
        endDate: { type: DataTypes.STRING, allowNull: true, defaultValue: 0 },
        image: { type: DataTypes.STRING, allowNull: true },
        game_Features: { type: DataTypes.TEXT, allowNull: true },
        selectDraw: { type: DataTypes.TEXT, allowNull: true, defaultValue: 0, comment: "0: Single, 1: MultiDraw" },
        multiDraw: { type: DataTypes.TEXT, allowNull: true },
        frequency: { type: DataTypes.STRING, allowNull: false, comment: "0: Daily, 1: Weekly, 2: Monthly" },
        startTime: { type: DataTypes.STRING, allowNull: false },
        topPrize: { type: DataTypes.INTEGER, allowNull: false },
        unmatchedMessage: { type: DataTypes.TEXT, allowNull: true },
        matchMessage: { type: DataTypes.TEXT, allowNull: true },
        maxNumberTickets: { type: DataTypes.DECIMAL, allowNull: true },
        buyTicketLimit: { type: DataTypes.STRING, allowNull: false },
        timeZone: { type: DataTypes.STRING, allowNull: false },
        discountTicket: { type: DataTypes.STRING, allowNull: true },
        discountPercent: { type: DataTypes.STRING, allowNull: true },
        odds_of_win: { type: DataTypes.INTEGER, allowNull: true },
        odds_of_loss: { type: DataTypes.INTEGER, allowNull: true },
        sold: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0, comment: "0:unsold, 1:sold" },
        status: { type: DataTypes.TINYINT, allowNull: false, defaultValue: 0, comment: "0:Enable, 1:Disable" },
        scratchDrawCount: { type: DataTypes.INTEGER, allowNull: true, defaultValue: 0 },

    };

    const options = {
        defaultScope: {
            // exclude hash by default
            attributes: { exclude: [''] }
        },
        scopes: {
            // include hash with this scope
            withHash: { attributes: {}, }
        }
    };

    return sequelize.define('scratchCard', attributes, options);
}