﻿const express = require('express');
const router = express.Router();
const Joi = require('joi');
const { validateRequest } = require('../../_middleware/validate-request');
const scratchCardService = require('./scratchcard.service');
let multer = require('multer');
const fs = require('fs');

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, "uploads/scratchcard");
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + "-" + file.originalname.toLowerCase().split(' ').join('-'));
    }
});

const upload = multer({
    storage: storage,
    fileFilter: (req, file, cb) => {
        if (file.mimetype == "image/png" || file.mimetype == "image/jpg" || file.mimetype == "image/jpeg") {
            cb(null, true);
        } else {
            return cb('Only .png, .jpg and .jpeg format allowed!', false);
        }
    }
});

const cpUpload = upload.single('image');
function uploadImage(req, res, next) {
    cpUpload(req, res, function (err) {
        if (!fs.existsSync("scratchcard")) {
            fs.mkdirSync("scratchcard");
        }
        if (err instanceof multer.MulterError) {
            return res.status(400).json({ message: JSON.stringify(err) });
        } else if (err) {
            return res.status(400).json({ message: err });
        }
        next();
    });
}


router.post('/store', uploadImage, storeSchema, store);
router.get('/', getAllHandler);
router.get('/:id', getById);
router.put('/:id', uploadImage, update);
router.delete('/:id', _delete);
router.get('/', getBySearchHandler);

module.exports = router;


// function getAllSchema(req, res, next) {
//     const schema = Joi.object({
//         offset: Joi.number().integer().min(0).empty(''),
//         limit: Joi.number().integer().min(1).empty(''),
//         orderBy: Joi.string().valid('id', 'createdAt', 'name').empty(''),
//         orderType: Joi.string().valid('DESC', 'ASC').empty(''),
//         search: Joi.string().empty(''),
//     });
//     validateRequest(req, next, schema, 'query');
// }

function getAllHandler(req, res, next) {
    scratchCardService.getAll(req.query)
        .then(data => res.json({ message: 'All Data Success', data }))
        .catch(next);
}

function store(req, res, next) {
    if (req.file) {
        req.body.image = `${process.env.ASSET_URL}/scratchcard/${req.file.filename}`;
    }
    scratchCardService.create(req.body)
        .then(data => res.json({ message: 'Card Create Successfully', data }))
        .catch(next);
}

function storeSchema(req, res, next) {
    const schema = Joi.object({
        card_name: Joi.string().required(),
        ticketPrize: Joi.number().integer().required(),
        game_slogan: Joi.string().required(),
        endDate: Joi.string().empty(),
        game_Features: Joi.string().required(),
        selectDraw: Joi.string().empty(''),
        multiDraw: Joi.string().empty(''),
        frequency: Joi.string().required(),
        startTime: Joi.string().required(),
        topPrize: Joi.number().integer().required(),
        unmatchedMessage: Joi.string().empty(''),
        matchMessage: Joi.string().empty(''),
        maxNumberTickets: Joi.number().integer().required(),
        buyTicketLimit: Joi.string().empty(''),
        timeZone: Joi.string().empty(''),
        discountTicket: Joi.string().empty(''),
        discountPercent: Joi.string().empty(''),
        odds_of_win: Joi.number().integer().required(),
        odds_of_loss: Joi.number().integer().empty(),
        sold: Joi.string().empty(''),
        status: Joi.number().integer().empty('')
    });
    validateRequest(req, next, schema);
}

function getById(req, res, next) {
    scratchCardService.getById(req.params.id)
        .then(data => res.json({ message: 'Get Successfully', data }))
        .catch(next);
}

function update(req, res, next) {
    if (req.file) {
        req.body.image = `${process.env.ASSET_URL}/scratchcard/${req.file.filename}`;
    }
    scratchCardService.update(req.params.id, req.body)
        .then(data => res.json({ message: 'Card Update Successfully', data }))
        .catch(next);
}

function _delete(req, res, next) {
    scratchCardService._delete(req.params.id)
        .then(data => res.json({ message: 'Deleted Successful', data }))
        .catch(next);
}

function getBySearchHandler(req, res, next) {
    const search = req.query;
    scratchCardService.getBySearchScratchCard(search)
        .then(data => res.json({ message: 'Success Hii', data }))
        .catch(next);
}