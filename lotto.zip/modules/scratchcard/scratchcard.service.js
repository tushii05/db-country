﻿const db = require('../../_helpers/db');
const { Op } = require("sequelize");
const moment = require('moment');
const { generateRandomNumberScratch } = require('../../_middleware/random-number')

module.exports = {
    getAll,
    getById,
    create,
    update,
    _delete,
    getBySearchScratchCard
};

// async function getAll({ offset = 0, orderBy = 'id', orderType = 'DESC', search = null }) {
//     const scratchCardCount = await db.scratchCard.count();
//     return await db.scratchCard.findAll({
//         include: [
//             { model: db.generateRandomNoScratch },
//             { model: db.ScratchTable }],
//         offset: parseInt(offset),
//         order: [[orderBy, orderType]]
//     }).then((rows) => {
//         return {
//             count: scratchCardCount,
//             rows
//         }
//     })
// }

async function getAll({ offset = 0, orderBy = 'id', orderType = 'DESC', search = null }) {
    let whereClause = {};
    if (search) {
        whereClause = {
            [Op.or]: Object.keys(db.scratchCard.rawAttributes).reduce((acc, column) => {
                acc[column] = {
                    [Op.substring]: `${search}`
                };
                return acc;
            }, {})
        };
    }

    const scratchCardCount = await db.scratchCard.count({ where: whereClause });

    return db.scratchCard.findAll({
        include: [
            { model: db.generateRandomNoScratch },
            { model: db.ScratchTable }
        ],
        where: whereClause,
        offset: parseInt(offset),
        order: [[orderBy, orderType]]
    }).then((rows) => {
        return {
            count: scratchCardCount,
            rows
        };
    });
}

async function getById(id) {
    return await getScratchCard(id);
}




// let currentNumber = 0;
// async function generateRandomLoop(length, id, type) {
//     let numbers = [];
//     while (numbers.length < length) {
//         currentNumber++;
//         if (currentNumber > 100) {
//             currentNumber = 1; // Reset to 1 if currentNumber exceeds 100
//         }
//         numbers.push(currentNumber);
//         try {
//             await db.generateRandomNoScratch.create({ number: currentNumber, scratchCardId: id, win_loss: type });
//         } catch (error) { }
//     }
// }


let currentNumber = 0;


async function generateRandomLoop(length, id, type) {
    let numbers = [];
    while (numbers.length < length) {
        currentNumber++;
        if (currentNumber > 100) {
            currentNumber = 1;
        }
        numbers.push(currentNumber);
        try {
            await db.generateRandomNoScratch.create({ number: currentNumber, scratchCardId: id, win_loss: type });
        } catch (error) { }
    }
}

async function generateRandomSeriesLoop(length, id, type) {
    let numbers = Array.from({ length: 100 }, (_, index) => index + 1);
    for (let i = 0; i < length; i++) {
        const randomIndex = generateRandomNumberScratch() - 1;
        const number = numbers[randomIndex];
        numbers[randomIndex] = numbers[i];
        numbers[i] = number;
    }
    await generateRandomLoop(length, id, type);
}

function convertLocalTimeToUTC(localTime, timeZone) {
    const localDateTime = moment.tz(localTime, 'HH:mm', timeZone);
    const utcDateTime = localDateTime.utc().format('HH:mm');
    return utcDateTime;
}

async function create(params) {
    params.userId = 1;
    const odds_of_win = params.odds_of_win;
    const odds_of_loss = 100 - odds_of_win;
    params.odds_of_loss = odds_of_loss;

    const localTime = params.startTime;
    const timeZone = params.timeZone;
    const startTimeUtc = convertLocalTimeToUTC(localTime, timeZone);
    params.startTime = startTimeUtc;

    const d = await db.scratchCard.create(params);
    const maxNumberTickets = 100;
    const numWins = Math.floor((maxNumberTickets * odds_of_win) / 100);
    await generateRandomSeriesLoop(numWins, d.id, 'win');
    await generateRandomSeriesLoop(maxNumberTickets - numWins, d.id, 'loss');
    return { message: 'Scratch Card created successfully', data: d };
}


async function update(id, params) {
    const scratchcard = await db.scratchCard.findOne({ where: { id: id } });
    const odds_of_win = params.odds_of_win;
    const odds_of_loss = 100 - odds_of_win;
    params.odds_of_loss = odds_of_loss;
    
    const localTime = params.startTime;
    const timeZone = params.timeZone;
    const startTimeUtc = convertLocalTimeToUTC(localTime, timeZone);
    params.startTime = startTimeUtc;

    if (!scratchcard) throw 'Scratchcard not found'
    const ticketDifference = params.maxNumberTickets - scratchcard.maxNumberTickets;
    Object.assign(scratchcard, params);
    const updatedScratch = await scratchcard.save();
    if (ticketDifference > 0) {
        await generateRandomLoop(ticketDifference, updatedScratch.id);
    }
    return updatedScratch;
}



// Helper Functions

async function getScratchCard(id) {
    const scratchCard = await db.scratchCard.findOne({
        where: { id: id },
        include: [{ model: db.generateRandomNoScratch },
        { model: db.ScratchTable }]
    });
    if (!scratchCard) throw 'Scratchcard not found';
    return scratchCard;
}

async function _delete(id) {
    const scratchCard = await db.scratchCard.findOne({ where: { id: id } });
    if (scratchCard) {
        await scratchCard.destroy();
        return true;
    }
}

async function getBySearchScratchCard(search) {
    const whereClause = {};
    for (const key in search) {
        if (search.hasOwnProperty(key)) {
            whereClause[key] = {
                [Op.like]: `%${search[key]}%`
            };
        }
    }

    const scratchCards = await db.scratchCard.findAll({
        where: whereClause
    });

    if (!scratchCards || scratchCards.length === 0) {
        throw new Error("Not Found");
    }

    return scratchCards;
}
