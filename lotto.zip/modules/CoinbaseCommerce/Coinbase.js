// const express = require('express');
// const coinbase = require('coinbase-commerce-node');
// const bodyParser = require('body-parser');
// const axios = require('axios');

// const Client = coinbase.Client;
// const resources = coinbase.resources;
// const Webhook = coinbase.Webhook;
// const router = express.Router();
// const cors = require('cors');

// router.use(cors());
// // router.use(bodyParser.json())
// router.use(bodyParser.json({
//     verify: (req, res, buf) => {
//         const url = req.originalUrl;
//         if (url.startWith("/webhook")) {
//             req.rawBody = buf.toString();
//         }
//     }
// }))

// Client.init(process.env.COINBASE_API_KEY);

// // router.post("/checkout", async (req, res) => {
// //     const { amount, currency } = req.body;

// //     try {
// //         const chargeData = await resources.Charge.create({
// //             name: 'Lifetime Lotto',
// //             description: `payment for ${currency}${amount} Lottery Ticket`,
// //             pricing_type: 'fixed_price',
// //             local_price: {
// //                 amount: amount,
// //                 currency: currency,
// //             },
// //             // metadata: {
// //             //     userId: "22"
// //             // },
// //             redirect_url: 'http://159.223.51.198:5000/',
// //             cancel_url: 'http://159.223.51.198:5000/#/dashboard',
// //         })
// //         const response = await axios.post('https://api.commerce.coinbase.com/charges', chargeData, {
// //             headers: {
// //                 'Content-Type': 'application/json',
// //                 'Accept': 'application/json',
// //                 'X-CC-Api-Key': process.env.COINBASE_API_KEY
// //             }
// //         });
// //         const charge = response.data.data;
// //         res.redirect(charge.hosted_url);
// //         console.log('Payment_Url :', charge.hosted_url)
// //     } catch (error) {
// //         res.status(500).json({
// //             error: error.message,
// //         })
// //     }
// // })


// // router.post("/checkout", async (req, res) => {
// //     const { amount, currency } = req.body;

// //     try {
// //         const checkoutData = {
// //             name: 'Lifetime Lotto',
// //             description: `Payment for ${currency}${amount} Lottery Ticket`,
// //             pricing_type: 'fixed_price',
// //             local_price: {
// //                 amount: amount,
// //                 currency: currency,
// //             },
// //             requested_info: ['email'],
// //             redirect_url: 'http://159.223.51.198:5000/',
// //             cancel_url: 'http://159.223.51.198:5000/#/dashboard',
// //         };

// //         const response = await axios.post('https://api.commerce.coinbase.com/checkouts', checkoutData, {
// //             headers: {
// //                 'Content-Type': 'application/json',
// //                 'Accept': 'application/json',
// //                 'X-CC-Api-Key': process.env.COINBASE_API_KEY
// //             }
// //         });

// //         const checkout = response.data.data;
// //         res.redirect(checkout.hosted_url);
// //         console.log(response.data.data)
// //         console.log('Checkout URL:', checkout.hosted_url);
// //     } catch (error) {
// //         res.status(500).json({
// //             error: error.message,
// //         });
// //     }
// // });

// router.post("/checkout", async (req, res) => {
//     const { amount, currency } = req.body;

//     try {
//         const checkoutData = {
//             name: 'Lifetime Lotto',
//             description: `Payment for ${currency}${amount} Lottery Ticket`,
//             pricing_type: 'fixed_price',
//             local_price: {
//                 amount: amount,
//                 currency: currency,
//             },
//             requested_info: ['email'],
//             metadata: {
//                 customer_id: '123',
//             },
//             redirect_url: `${process.env.ASSET_URL}/#/dashboard`,
//             cancel_url: `${process.env.ASSET_URL}`,
//         };

//         const response = await axios.post('https://api.commerce.coinbase.com/checkouts', checkoutData, {
//             headers: {
//                 'Content-Type': 'application/json',
//                 'X-CC-Api-Key': process.env.COINBASE_API_KEY,
//                 'X-CC-Version': '2018-03-22'

//             }
//         });

//         const checkout = response.data.data;
//         console.log('Response:', response.data.data);

//         console.log('Checkout URL:', checkout.id);
//         console.log('Checkout URL:', `https://commerce.coinbase.com/checkout/${checkout.id}`);
//         res.redirect(`https://commerce.coinbase.com/checkout/${checkout.id}`);
//     } catch (error) {
//         res.status(500).json({
//             error: error.message,
//         });
//     }
// });



// router.get('/success', (req, res) => {
//     console.log('Payment successful');
//     res.send('Payment successful');
// });

// router.get('/cancel', (req, res) => {
//     console.log('Payment canceled');
//     res.send('Payment cancelled');
// });

// router.post("/webhook", async (req, res) => {

//     try {
//         const event = Webhook.verifyEventBody(
//             req.rawBody,
//             req.headers["x-cc-webhook-signature"],
//             process.env.COINBASE_WEBHOOK_SECRET
//         );

//         if (event.type === "charge:confirmed") {
//             let amount = event.data.pricing.local.amount;
//             let currency = event.data.pricing.local.currency;
//             let userId = event.data.metadata.userId;

//             console.log(amount, currency, userId)
//         } else if (event.type === "charge:failed") {

//             const amount = event.data.pricing.local.amount;
//             const currency = event.data.pricing.local.currency;
//             const userId = event.data.metadata.userId;

//             console.log("Payment failed:", amount, currency, userId);
//         }
//         res.sendStatus(200)
//     } catch (error) {
//         res.status(500).json({
//             error: error,
//         })
//     }
// })


// module.exports = router;


//------------------------------------------------

require('dotenv').config()
const express = require('express');
const coinbase = require('coinbase-commerce-node');
const axios = require('axios');
const cors = require('cors');
const Client = coinbase.Client;
const resources = coinbase.resources;
const Webhook = coinbase.Webhook;
const bodyParser = require('body-parser');
const router = express.Router()
Client.init(process.env.COINBASE_API_KEY);

// router.use(cors());
// app.use(bodyParser.json())
router.use(bodyParser.json({
    verify: (req, res, buf) => {
        const url = req.originalUrl;
        if (url.startsWith("/webhook")) {
            req.rawBody = buf.toString();
        }
    }
}));


router.post("/checkout", async (req, res) => {
    const { amount, currency } = req.body;
    try {
        const charge = await resources.Charge.create({
            name: 'The Sovereign Individual',
            description: 'Mastering the Transition to the Information Age',
            pricing_type: 'fixed_price',
            local_price: {
                amount: amount,
                currency: currency,
            },
            metadata: {
                userId: "22"
            },
            redirect_url: `http://159.223.51.198:5000/`,
            cancel_url: `http://159.223.51.198:5000/#/dashboard`
        })
        console.log('Payment_Url :', charge.hosted_url)
        res.status(200).json({
            Payment_Url: charge.hosted_url,
        })
    } catch (error) {
        res.status(500).json({
            error: error.message,
        })
    }
})


router.post("/webhook", async (req, res) => {
    try {
        const event = Webhook.verifyEventBody(
            req.rawBody || JSON.stringify(req.body),
            req.headers["x-cc-webhook-signature"],
            process.env.COINBASE_WEBHOOK_SECRET
        );

        if (event.type === "charge:confirmed") {
            const amount = event.data.pricing.local.amount;
            const currency = event.data.pricing.local.currency;
            const userId = event.data.metadata.userId;

            console.log("charge:confirmed", amount, currency, userId, new Date())
        } else if (event.type === "charge:failed") {

            const amount = event.data.pricing.local.amount;
            const currency = event.data.pricing.local.currency;
            const userId = event.data.metadata.userId;

            console.log("Payment failed:", amount, currency, userId);
        } else if (event.type === "charge:delayed") {

            const amount = event.data.pricing.local.amount;
            const currency = event.data.pricing.local.currency;
            const userId = event.data.metadata.userId;

            console.log("Payment charge:delayed:", amount, currency, userId);
        } else if (event.type === "charge:failed") {

            const amount = event.data.pricing.local.amount;
            const currency = event.data.pricing.local.currency;
            const userId = event.data.metadata.userId;

            console.log("Payment failed:", amount, currency, userId);
        } else if (event.type === "charge:pending") {

            const amount = event.data.pricing.local.amount;
            const currency = event.data.pricing.local.currency;
            const userId = event.data.metadata.userId;

            console.log("Payment pending:", amount, currency, userId);
        } else if (event.type === "charge:resolved") {

            const amount = event.data.pricing.local.amount;
            const currency = event.data.pricing.local.currency;
            const userId = event.data.metadata.userId;

            console.log("Payment resolved:", amount, currency, userId);
        }
        res.sendStatus(200)
    } catch (error) {
        res.status(500).json({
            error: error,
        })
    }
})

module.exports = router;