﻿const db = require('../../_helpers/db');
const { Op } = require("sequelize");

module.exports = {
    getAll,
    getById,
    create,
    getWinnerByTicketNumber
};

async function getAll({ offset = 0, orderBy = 'id', orderType = 'DESC', search = null }) {
    let where = {};
    if (search !== null) {
        where = {
            [Op.or]: [
                {
                    ticketNumber: { [Op.like]: `%${search}%` }
                }
            ]
        }
    }
    const winnersCount = await db.Winners.count({
        where
    });
    return await db.Winners.findAll({
        where,
        include: [
            {
                model: db.GameInfo,
                attributes: ['gameName', "gameNumber", "ticketPrice", "gameDuration", "startTime"]
            },
            {
                model: db.GamePhase,
                attributes: ["game", "gameData"]
            },
            {
                model: db.User,
                attributes: ["fname", "lname", "userName", "email", "email"]
            }
        ],
        offset: parseInt(offset),
        // limit: parseInt(limit),
        order: [[orderBy, orderType]]
    }).then((data) => {
        return {
            count: winnersCount,
            data
        };
    });
}


async function getById(id) {
    return await getTicket(id);
}
async function create(params) {
    await db.Winners.create(params);
}


async function getTicket(id) {
    const TicketNumber = await db.Winners.findOne({
        where: { id: id },
        include: [
            { model: db.GameInfo },
            { model: db.GamePhase },
            { model: db.User }
        ],
    });
    if (!TicketNumber) throw 'Winners not found';
    return TicketNumber;
}


async function getWinnerByTicketNumber(ticketNumber) {
    const TicketNumber = await db.Winners.findOne({
        where: { ticketNumber: ticketNumber },
        include: [
            { model: db.GameInfo },
            { model: db.GamePhase },
            { model: db.User }
        ],
    });
    if (!TicketNumber) throw 'TicketNumber not found';
    return TicketNumber;
}