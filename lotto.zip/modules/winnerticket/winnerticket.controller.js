﻿const express = require('express');
const router = express.Router();
const Joi = require('joi');
const { validateRequest } = require('../../_middleware/validate-request');
const ticketService = require('./winnerticket.service');
module.exports = router;


router.get('/', getAllSchema, getAll);
router.post('/store', storeSchema, store);
router.get('/:id', getById);
module.exports = router;

function getAllSchema(req, res, next) {
    const schema = Joi.object({
        offset: Joi.number().integer().min(0).empty(''),
        limit: Joi.number().integer().min(1).empty(''),
        orderBy: Joi.string().valid('id', 'createdAt', 'ticket_number').empty(''),
        orderType: Joi.string().valid('DESC', 'ASC').empty(''),
        search: Joi.string().empty(''),
    });
    validateRequest(req, next, schema, 'query');
}

function getAll(req, res, next) {
    ticketService.getAll(req.query)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function store(req, res, next) {
    ticketService.create(req.body)
        .then(data => { res.json({ message: 'Success', data }) })
        .catch(next);
}

function storeSchema(req, res, next) {
    const schema = Joi.object({
        gameInformationId: Joi.number().integer().required(),
        gamePhaseId: Joi.number().integer().required(),
        UserId: Joi.number().integer(),
        ticketNumber: Joi.string().required(),
        frequency: Joi.number().integer().required(),

    });
    validateRequest(req, next, schema);
}

function getById(req, res, next) {
    ticketService.getById(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}



// Helper Code 

router.get('/ticket/:ticketNumber', async (req, res, next) => {
    try {
        const winner = await ticketService.getWinnerByTicketNumber(req.params.ticketNumber);
        if (winner) {
            res.json({ message: 'Success', data: winner });
        } else {
            res.status(404).json({ message: 'Ticket Number not found' });
        }
    } catch (err) {
        next(err);
    }
});