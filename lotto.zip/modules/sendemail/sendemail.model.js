const { DataTypes, literal } = require('sequelize');

module.exports = model;

function model(sequelize) {
    const attributes = {
        to: { type: DataTypes.STRING, allowNull: false },
        subject: { type: DataTypes.TEXT('long'), allowNull: false },
        html: { type: DataTypes.TEXT('long'), allowNull: false },
        status: { type: DataTypes.STRING, allowNull: false }
    };
    const options = {
        defaultScope: {
            // exclude hash by default
            attributes: { exclude: [] }
        },
        scopes: {
            // include hash with this scope
            withHash: { attributes: {}, }
        }
    };

    return sequelize.define('Email', attributes, options);
}