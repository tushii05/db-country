const db = require('../../_helpers/db');
const { Op } = require("sequelize");

module.exports = {
    getAll
};
async function getAll({ offset = 0, orderBy = 'id', orderType = 'ASC', search = null }) {
    let where = {};
    if (search !== null) {
        where = {
            [Op.or]: [
                { email: { [Op.like]: `%${search}%` } }
            ]
        }
    }
    return await db.Email.findAndCountAll({
        where,
        offset: parseInt(offset),
        order: [[orderBy, orderType]]
    });
}