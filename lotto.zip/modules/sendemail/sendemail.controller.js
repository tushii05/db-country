const db = require('../../_helpers/db')
const express = require('express');
const router = express.Router();
const { sendEmail } = require('../../_middleware/email');
const sendmailService = require('./sendemail.service');

router.post('/send', sendEmailHandler);
router.post('/send/users', sendEmailToAllUsers);
router.get("/", getAll, getAllSchema);

module.exports = router;


async function sendEmailHandler(req, res) {
    const { to, subject, html } = req.body;
    try {
        
        const user = await db.User.findOne({ where: { email: to } });
        const { fname, lname } = user;

        const message = `Dear <b> ${fname} ${lname} </b>,<br><br>${html}`;

        await sendEmail(`${fname} ${lname} <${to}>`, subject, message);

        const email = await db.Email.create({
            to: to,
            subject: subject,
            html: html,
            status: 'sent',
        });

        res.status(200).json({ message: 'Email sent successfully!', email });
    } catch (err) {
        res.status(500).json({ message: 'Error sending email' });
    }
};



async function sendEmailToAllUsers(req, res) {
    try {
        const { subject, html } = req.body;
        const users = await db.User.findAll({ attributes: ['email', 'fname', 'lname'] });
        const emailPromises = users.map(async (user) => {
            try {
                await sendEmail(user.email, subject, `Dear <b>${user.fname} ${user.lname}</b> <br><br> ${html}`);
                return { email: user.email, status: 'sent' };
            } catch (err) {
                return { email: user.email, status: 'error' };
            }
        });
        const results = await Promise.all(emailPromises);
        const successes = results.filter(result => result.status === 'sent');
        const errors = results.filter(result => result.status === 'error');
        res.status(200).json({
            message: 'Emails sent successfully!',
            successes,
            errors
        });
    } catch (err) {
        res.status(500).json({ message: 'Error sending email' });
    }
};


function getAll(req, res, next) {
    sendmailService.getAll(req.query)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}


function getAllSchema(req, res, next) {
    const schema = Joi.object({
        offset: Joi.number().integer().min(0).empty(''),
        limit: Joi.number().integer().min(1).empty(''),
        orderBy: Joi.string().valid('id', 'createdAt').empty(''),
        orderType: Joi.string().valid('DESC', 'ASC').empty(''),
        search: Joi.string().empty(''),
    });
    validateRequest(req, next, schema);
}


// const express = require('express');
// const router = express.Router();
// const Joi = require('joi');
// const { validateRequest } = require('../../_middleware/validate-request');
// const { sendmailService } = require('./sendmail.service');
// const dotenv = require('dotenv');
// const nodemailer = require("nodemailer");
// dotenv.config();
// // routes
// let transporter = nodemailer.createTransport({
//     host: 'smtp.hostinger.com',
//     port: 587,
//     auth: {
//         user: "mailto:support@creativewebsoft.in",
//         pass: "Creative@s430"
//     }
// })
// router.post('/send', store);
// module.exports = router;
// function store(req, res, next) {

//     for (const email of req.body.email) {
//         let html = "Hello <strong>" + email.fname + ' ' + email.lname + "</strong>, <br/>";
//         html += req.body.message;
//         transporter.sendMail({
//             from: "mailto:support@creativewebsoft.in",
//             to: email.email, // recipient email
//             bcc: "mailto:sachinduklan08@gmail.com,sachin",
//             subject: req.body.subject, // Subject line
//             html: html,
//         }, function (error, info) {
//             if (error) {
//                 console.log(error);
//             } else {
//                 console.log('Email sent: ' + info.response);
//             }
//         });
//     }
//     res.json({ message: 'Send successfully', data: true })
// }