const db = require("../../_helpers/db");

module.exports = {
    getAllWithStates,
    getAll,
    getById,
    create,
    getAllTimezones,
};

async function getAllWithStates({ offset = 0, orderBy = "id", orderType = "DESC", search = null }) {
    const [countries, count] = await Promise.all([
        db.Countries.findAll({
            include: [
                {
                    model: db.States,
                    include: [{ model: db.Cities }],
                },
            ],
            offset: parseInt(offset),
            order: [[orderBy, orderType]],
            limit: 100,
        }),
        db.Countries.count(),
    ]);
    return { count, countries };
}

async function getAll({ offset = 0, orderBy = "id", orderType = "DESC", search = null }) {
    const [countries, count] = await Promise.all([
        db.Countries.findAll({
            offset: parseInt(offset),
            order: [[orderBy, orderType]],
        }),
        db.Countries.count(),
    ]);
    return { count, countries };
}

async function getById(id) {
    return await getCountries(id);
}

async function create(params) {
    const d = await db.Countries.create(params);
    return d;
}

// Helper Functions

async function getCountries(id) {
    const Countries = await db.Countries.findOne({
        where: { id: id },
        include: [
            {
                model: db.States,
                include: [{ model: db.Cities }],
            },
        ],
    });
    if (!Countries) throw "Countries not found";
    return Countries;
}

async function getAllTimezones() {
    try {
        const countries = await db.Countries.findAll({
            attributes: ['timezone'],
        });

        if (countries.length === 0) {
            return [];
        }

        return countries.map((country) => ({
            timezone: country.timezone,
        }));
    } catch (error) {
        throw new Error('Error fetching timezones from the database');
    }
}
