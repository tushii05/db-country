const express = require('express');
const router = express.Router();
const Joi = require('joi');
const { validateRequest } = require('../../_middleware/validate-request');
const countriesService = require('./countries.service');
module.exports = router;


router.get('/', getAllSchema, getAll);
router.get('/states', getAllSchema, getAllWithStates);
router.post('/store', storeSchema, store);
router.get('/:id', getById);
router.get('/timezone/time', getAllTimezones)

module.exports = router;

function getAllSchema(req, res, next) {
    const schema = Joi.object({
        offset: Joi.number().integer().min(0).empty(''),
        limit: Joi.number().integer().min(1).empty(''),
        orderBy: Joi.string().valid('id', 'createdAt', 'name').empty(''),
        orderType: Joi.string().valid('DESC', 'ASC').empty(''),
        search: Joi.string().empty(''),
    });
    validateRequest(req, next, schema, 'query');
}


function getAll(req, res, next) {
    countriesService.getAll(req.query)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

async function getAllTimezones(req, res) {
    try {
        const timezones = await countriesService.getAllTimezones();
        return res.json({ timezones });
    } catch (error) {
        return res.status(500).json({ error: error.message });
    }
}

function getAllWithStates(req, res, next) {
    countriesService.getAllWithStates(req.query)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function store(req, res, next) {
    countriesService.create(req.body)
        .then(data => { res.json({ message: 'Success', data }) })
        .catch(next);
}

function storeSchema(req, res, next) {
    const schema = Joi.object({
        name: Joi.string().required(),
        capital: Joi.string().required()
    });
    validateRequest(req, next, schema);
}

function getById(req, res, next) {
    countriesService.getById(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}
