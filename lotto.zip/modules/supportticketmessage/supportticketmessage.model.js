const { DataTypes, literal } = require('sequelize');

module.exports = model;

function model(sequelize) {
    const attributes = {
        AdminId: { type: DataTypes.INTEGER, allowNull: false },
        SupportTicketId: { type: DataTypes.INTEGER, allowNull: false },
        message: { type: DataTypes.TEXT('long'), allowNull: true }
    };

    const options = {
        defaultScope: {
            // exclude hash by default
            attributes: { exclude: [''] }
        },
        scopes: {
            // include hash with this scope
            withHash: { attributes: {}, }
        }
    };

    return sequelize.define('SupportTicketMessage', attributes, options);
}