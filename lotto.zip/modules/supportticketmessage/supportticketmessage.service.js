﻿const db = require('../../_helpers/db');
const { Op } = require("sequelize");
module.exports = {
    getAll,
    getById,
    create,
    update,
    _delete
};
async function getAll({ offset = 0, orderBy = 'id', orderType = 'DESC', search = null }) {
    let where = {};
    if (search !== null) {
        where = { '$message$': { [Op.like]: `%${search}%` } }
    }
    return await db.supportTicketMessage.findAndCountAll({
        where,
        include: [{ model: db.supportTicket }],
        offset: parseInt(offset),
        // limit: parseInt(limit),
        order: [[orderBy, orderType]]
    });
}
async function getById(id) {
    return await getSupportTicketMessage(id);
}
async function create(params) {
    const d = await db.supportTicketMessage.create(params);
    return d;
}
async function update(id, params) {
    const supportTicketMessage = await db.supportTicketMessage.findOne({ where: { id: id } });
    if (!supportTicketMessage) throw 'Support Ticket Message not found'
    Object.assign(supportTicketMessage, params);
    return await supportTicketMessage.save();
}
// helper functions
async function getSupportTicketMessage(id) {
    const supportTicketMessage = await db.supportTicketMessage.findByPk(id);
    if (!supportTicketMessage) throw 'Support Ticket Message not found';
    return await db.supportTicketMessage.findOne({
        where: { id: id },
        include: [{
            model: db.supportTicket,
        }]
    });
}
async function _delete(id) {
    const supportTicketMessage = await db.supportTicketMessage.findOne({ where: { id: id } });
    if (supportTicketMessage) {
        await supportTicketMessage.destroy();
        return true;
    }
}
