const { DataTypes, literal } = require('sequelize');

module.exports = model;

function model(sequelize) {
    const attributes = {
        number: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
        status: { type: DataTypes.TINYINT, allowNull: false, defaultValue: 0 },
        win_loss: { type: DataTypes.STRING, allowNull: false, defaultValue: 0 }
    };
    const options = {
        timestamps: false,

        defaultScope: {
            attributes: { exclude: [''] }
        },
        scopes: {
            withHash: { attributes: {} }
        }
    };

    return sequelize.define('scratchcardNo', attributes, options);
}