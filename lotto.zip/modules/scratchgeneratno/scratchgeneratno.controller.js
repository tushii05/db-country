const express = require('express');
const router = express.Router();


// Helper Functions 


router.put('/:number/:scratchCardId', (req, res) => {
    db.generateRandomNoScratch.update({
        status: 1
    }, {
        where: {
            number: req.params.number,
            scratchCardId: req.params.scratchCardId,
            status: 0
        }
    })
        .then(result => {
            if (result[0] === 0) {
                return res.status(404).send({
                    message: 'Scratch Card Number or Scratch Card id not found'
                });
            }
            res.send({
                message: 'Status updated successfully'
            });
        })
        .catch(err => {
            res.status(500).send({
                error: err
            });
        });
});

router.delete('/:scratchCardId', (req, res) => {
    db.generateRandomNoScratch.destroy({
        where: {
            scratchCardId: req.params.scratchCardId
        }
    })
        .then(result => {
            if (result === 0) {
                return res.status(404).send({
                    message: 'Scratch Card id not found'
                });
            }
            res.send({
                message: 'Row deleted successfully'
            });
        })
        .catch(err => {
            res.status(500).send({
                error: err
            });
        });
});



module.exports = router;