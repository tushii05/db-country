﻿const express = require('express');
const router = express.Router();
const Joi = require('joi');
const { validateRequest } = require('./../../_middleware/validate-request');
const adminService = require('../admin/admin.service');


router.post('/authenticate', authenticateSchema, authenticate);
router.post('/register', registerSchema, registerAdmin);

module.exports = router;

function authenticateSchema(req, res, next) {
    const schema = Joi.object({
        username: Joi.string().email().required(),
        password: Joi.string().required()
    });
    validateRequest(req, next, schema);
}

function authenticate(req, res, next) {
    adminService.authenticate(req.body)
        .then(data => res.json({ message: "Success", data }))
        .catch(next);
}

function registerSchema(req, res, next) {
    const schema = Joi.object({
        username: Joi.string().email().required(),
        password: Joi.string().required(),
        firstName: Joi.string().empty(''),
        lastName: Joi.string().empty(''),
    });
    validateRequest(req, next, schema);
}

async function registerAdmin(req, res, next) {
    adminService.register(req.body)
        .then(data => res.json({ message: "Success", data }))
        .catch(next);
}
