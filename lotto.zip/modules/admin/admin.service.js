﻿const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const db = require('./../../_helpers/db');


module.exports = {
    authenticate,
    register
};

async function authenticate({ username, password }) {
    const admin = await db.Admin.scope('withHash').findOne({ where: { email: username } });
    if (!admin || !(await bcrypt.compare(password, admin.hash)))
        throw 'Username or password is incorrect';
    const token = jwt.sign({ sub: admin.id }, process.env.SECRETSTRING, { expiresIn: '1d' });
    return { ...omitHash(admin.get()), token };
}


async function register(params) {
    const existingAdmin = await db.Admin.findOne({ where: { email: params.username } });
    if (existingAdmin) {
        throw 'Email is already registered';
    }
    const hash = await bcrypt.hash(params.password, 10);
    const newAdmin = await db.Admin.create({ email: params.username, hash });
    return omitHash(newAdmin.get());
}

function omitHash(admin) {
    const { hash, ...adminWithoutHash } = admin;
    return adminWithoutHash;
}