// const db = require('../../_helpers/db');
// const dotenv = require('dotenv');
// const Op = require('sequelize');
// dotenv.config();

// const ScratchCardService = {
//     async updatePrize(scratchCardId) {
//         const scratchPlayData = await db.scratchCardPlay.findOne({
//             where: { scratchCardId },
//             include: { model: db.ScratchTable },
//         });

//         if (scratchPlayData) {
//             const { randomNumber, UserId } = scratchPlayData;

//             const scratchTableData = await db.ScratchTable.findOne({
//                 where: { rng: randomNumber },
//             });

//             if (scratchTableData) {
//                 const { price } = scratchTableData;

//                 await db.scratchCardWin.update(
//                     { price },
//                     { where: { scratchCardId } }
//                 );

//                 return price;
//             }
//         }

//         return { success: false, message: 'No match found.' };
//     },
// };


// const { Op } = require('sequelize');

// const ScratchCardService = {
//     async updatePrize(scratchCardId) {
//         const scratchPlayData = await db.scratchCardPlay.findOne({
//             where: { scratchCardId },
//             include: { model: db.ScratchTable },
//         });

//         if (scratchPlayData) {
//             const { randomNumber, UserId } = scratchPlayData;

//             const scratchTableData = await db.ScratchTable.findOne({
//                 where: {
//                     [Op.and]: [
//                         { rng: { [Op.lte]: randomNumber } },
//                         { rng: { [Op.gte]: randomNumber } },
//                     ],
//                 },
//             });

//             if (scratchTableData) {
//                 const { price } = scratchTableData;

//                 await db.scratchCardWin.update(
//                     { price },
//                     { where: { scratchCardId, UserId } }
//                 );

//                 return price;
//             }
//         }

//         return { success: false, message: 'No match found.' };
//     },
// };


// const ScratchCardService = {
//     async updatePrize(scratchCardId) {
//         const scratchPlayData = await db.scratchCardPlay.findAll({
//             where: { scratchCardId },
//             include: { model: db.ScratchTable },
//         });

//         if (scratchPlayData.length > 0) {
//             const userIds = scratchPlayData.map((row) => row.UserId);
//             const randomNumber = scratchPlayData[0].randomNumber;

//             const scratchTableData = await db.ScratchTable.findOne({
//                 where: {

//                     rng: randomNumber
//                 },
//             });

//             if (scratchTableData) {
//                 const { price } = scratchTableData;

//                 await db.scratchCardWin.update(
//                     { price },
//                     { where: { UserId: userIds, scratchCardId } }
//                 );

//                 return price;
//             }
//         }

//         return { success: false, message: 'No match found.' };
//     },
// };


// const ScratchCardService = {
//     async updatePrize(scratchCardId) {
//         const scratchPlayData = await db.scratchCardPlay.findAll({
//             where: { scratchCardId },
//         });

//         if (scratchPlayData.length > 0) {
//             const userIds = scratchPlayData.map((row) => row.UserId);
//             const randomNumber = scratchPlayData[0].randomNumber;

//             // Make a request to the external API and compare the randomNumber
//             try {
//                 const apiResponse = await axios.get('http://localhost:5000/api/scratchtable/scratchcard/2');
//                 const apiRandomNumber = apiResponse.data.data.calculatedData;
//                 const apiRandom = apiRandomNumber.filter(item => item.rng == randomNumber)
//                 const pricess = apiRandom.map(item => item.price);
//                 const prices = pricess.toString()

//                 console.log(prices)

//                 if (randomNumber === apiRandomNumber) {
//                     const price = apiResponse.data.price;
//                     await db.scratchCardWin.update(
//                         { price },
//                         { where: { UserId: userIds, scratchCardId } }
//                     );
//                     return price;
//                 }
//             } catch (error) {
//                 console.error('Error while fetching data from the API:', error);
//             }
//         }

//         return { success: false, message: 'No match found.' };
//     },
// };


//-----------------------Work ----------------------------------
// const db = require('../../_helpers/db');
// // const dotenv = require('dotenv');
// const Op = require('sequelize');
// // dotenv.config();
// const axios = require('axios');
// const { Sequelize } = require('sequelize');


// const ScratchCardService = {
//     async updatePrize(scratchCardId) {
//         const scratchPlayData = await db.scratchCardPlay.findAll({
//             where: { scratchCardId },
//         });

//         if (scratchPlayData.length > 0) {
//             const userIds = scratchPlayData.map((row) => row.UserId);
//             const randomNumber = scratchPlayData[0].randomNumber;
//             // const userIds = scratchPlayData.map((row) => row.UserId);
//             // const randomNumber = scratchPlayData.map((row) => row.randomNumber);
//             // const randomNumber = scratchPlayData.map((row) => Number(row.randomNumber).toLocaleString());



//             console.log(randomNumber)
//             try {
//                 const apiResponse = await axios.get(`http://localhost:5000/api/scratchtable/scratchcard/${scratchCardId}`);
//                 const apiRandomNumber = apiResponse.data.data.calculatedData;
//                 const apiRandom = apiRandomNumber.filter(item => item.rng == randomNumber);
//                 const prices = apiRandom.map(item => item.price);
//                 // console.log(apiRandom)

//                 if (apiRandom.length > 0) {
//                     const price = prices.toString();
//                     // console.log(price)
//                     await db.scratchCardWin.update(
//                         { prize: price },
//                         { where: { UserId: userIds, scratchCardId } },
//                     );

//                     return { success: true, price };
//                 }
//             } catch (error) {
//                 console.error('Error while fetching data from the API:', error);
//             }
//         }

//         return { success: false, message: 'No match found.' };
//     },
// };



// module.exports = ScratchCardService;



//-----------------------Work ----------------------------------

// const ScratchCardService = {
//     async updatePrize(scratchCardId) {
//         const scratchPlayData = await db.scratchCardPlay.findAll({
//             where: { scratchCardId },
//         });

//         if (scratchPlayData.length > 0) {
//             const userIds = scratchPlayData.map((row) => row.UserId);
//             const randomNumberList = scratchPlayData.map((row) => row.randomNumber);

//             console.log(randomNumberList)

//             try {
//                 const apiResponse = await axios.get(`http://localhost:5000/api/scratchtable/scratchcard/${scratchCardId}`);
//                 const apiRandomNumber = apiResponse.data.data.calculatedData;
//                 // console.log(apiRandomNumber)
//                 const matchedRandomNumbers = apiRandomNumber.filter(item => randomNumberList.includes(item.rng));
//                 const prices = matchedRandomNumbers.map(item => item.price);

//                 // console.log('Matched Random Numbers:', matchedRandomNumbers);
//                 // console.log('Prizes:', prices);

//                 // if (matchedRandomNumbers.length > 0) {
//                 //     const price = prices;
//                 //     await db.scratchCardWin.update(
//                 //         { prize: price },
//                 //         { where: { UserId: userIds, scratchCardId } },
//                 //     );

//                 //     return { success: true, price };
//                 // }
//                 if (matchedRandomNumbers.length > 0) {
//                     // Shuffle the user IDs randomly
//                     const shuffledUserIds = userIds.sort(() => Math.random() - 0.5);

//                     const totalPrizes = prices.length;
//                     const totalUsers = shuffledUserIds.length;

//                     // Calculate the number of prizes each user will receive
//                     const prizesPerUser = Math.floor(totalPrizes / totalUsers);
//                     const remainingPrizes = totalPrizes % totalUsers;

//                     // Assign the prizes to the users
//                     const prizeAssignments = {};
//                     let prizeIndex = 0;

//                     for (let i = 0; i < totalUsers; i++) {
//                         const userId = shuffledUserIds[i];
//                         const numPrizes = i < remainingPrizes ? prizesPerUser + 1 : prizesPerUser;

//                         prizeAssignments[userId] = prices.slice(prizeIndex, prizeIndex + numPrizes);
//                         prizeIndex += numPrizes;
//                     }

//                     console.log('Prize Assignments:', prizeAssignments);

//                     // Update the scratchCardWin table with the assigned prizes
//                     const updatePromises = [];

//                     for (const userId of userIds) {
//                         const assignedPrizes = prizeAssignments[userId];

//                         for (const assignedPrize of assignedPrizes) {
//                             updatePromises.push(
//                                 db.scratchCardWin.update(
//                                     { prize: assignedPrize },
//                                     { where: { UserId: userId, scratchCardId } },
//                                 )
//                             );
//                         }
//                     }

//                     await Promise.all(updatePromises);

//                     return { success: true, prices };
//                 }

//             } catch (error) {
//                 console.error('Error while fetching data from the API:', error);
//             }
//         }

//         return { success: false, message: 'No match found.' };
//     },
// };

// module.exports = ScratchCardService;

//****************** Perfect ******************** */

// const ScratchCardService = {
//     async updatePrize(scratchCardId) {
//         const scratchPlayData = await db.scratchCardPlay.findAll({
//             where: { scratchCardId },
//         });

//         if (scratchPlayData.length > 0) {
//             const userIds = scratchPlayData.map((row) => row.UserId);
//             const randomNumberList = scratchPlayData.map((row) => row.randomNumber);

//             try {
//                 const apiResponse = await axios.get(`http://localhost:5000/api/scratchtable/scratchcard/${scratchCardId}`);
//                 const apiRandomNumber = apiResponse.data.data.calculatedData;
//                 const matchedRandomNumbers = apiRandomNumber.filter(item => randomNumberList.includes(item.rng));
//                 const prizes = matchedRandomNumbers.map(item => item.price);

//                 console.log('Matched Random Numbers:', matchedRandomNumbers);
//                 console.log('Prizes:', prizes);

//                 if (matchedRandomNumbers.length > 0) {
//                     // Shuffle the user IDs randomly
//                     const shuffledUserIds = userIds.sort(() => Math.random() - 0.5);

//                     const totalPrizes = prizes.length;
//                     const totalUsers = shuffledUserIds.length;

//                     // Calculate the number of prizes each user will receive
//                     const prizesPerUser = Math.floor(totalPrizes / totalUsers);
//                     const remainingPrizes = totalPrizes % totalUsers;

//                     // Assign the prizes to the users
//                     const prizeAssignments = {};
//                     let prizeIndex = 0;

//                     for (let i = 0; i < totalUsers; i++) {
//                         const userId = shuffledUserIds[i];
//                         const numPrizes = i < remainingPrizes ? prizesPerUser + 1 : prizesPerUser;

//                         prizeAssignments[userId] = prizes.slice(prizeIndex, prizeIndex + numPrizes);
//                         prizeIndex += numPrizes;
//                     }

//                     console.log('Prize Assignments:', prizeAssignments);

//                     // Log the count of scratchCardId index in scratchCardWin table
//                     const scratchCardWinCount = await db.scratchCardWin.count({ where: { scratchCardId } });
//                     console.log('scratchCardWin Count:', scratchCardWinCount);

//                     // Update the scratchCardWin table with the assigned prizes
//                     const updatePromises = [];

//                     for (const userId of userIds) {
//                         const assignedPrizes = prizeAssignments[userId];

//                         for (const assignedPrize of assignedPrizes) {
//                             updatePromises.push(
//                                 db.scratchCardWin.update(
//                                     { prize: assignedPrize },
//                                     { where: { UserId: userId, scratchCardId } },
//                                 )
//                             );
//                         }
//                     }

//                     await Promise.all(updatePromises);

//                     return { success: true, message: 'Prizes distributed successfully.' };
//                 }
//             } catch (error) {
//                 console.error('Error while fetching data from the API:', error);
//             }
//         }

//         return { success: false, message: 'No match found.' };
//     },
// };


// module.exports = ScratchCardService;




// secound logic use 



// const ScratchCardService = {
//     async updatePrize(scratchCardId) {
//         const scratchPlayData = await db.scratchCardPlay.findAll({
//             where: { scratchCardId },
//         });

//         if (scratchPlayData.length > 0) {
//             const userIds = scratchPlayData.map((row) => row.UserId);
//             const randomNumberList = scratchPlayData.map((row) => row.randomNumber);

//             try {
//                 const apiResponse = await axios.get(`http://localhost:5000/api/scratchtable/scratch/${scratchCardId}`);
//                 const apiRandomNumber = apiResponse.data.data;

//                 const matchedRandomNumbers = apiRandomNumber.map(item => ({
//                     odds_of_price: item.odds_of_price,
//                     price: item.price
//                 }));

//                 // console.log('Matched Random Numbers:', matchedRandomNumbers);

//                 if (matchedRandomNumbers.length > 0) {
//                     // Shuffle the user IDs randomly
//                     const shuffledUserIds = userIds.sort(() => Math.random() - 0.5);

//                     // Log the count of scratchCardId index in scratchCardWin table
//                     const scratchCardWinCount = await db.scratchCardWin.count({ where: { scratchCardId } });
//                     console.log('scratchCardWin Count:', scratchCardWinCount);

//                     // Assign the prizes to the users based on odds_of_price and scratchCardWinCount
//                     const prizeAssignments = {};
//                     let prizeIndex = 0;

//                     for (const userId of shuffledUserIds) {
//                         const assignedPrizes = [];
//                         const assignedPrizesCount = scratchCardWinCount % matchedRandomNumbers.length === 0 ? scratchCardWinCount / matchedRandomNumbers.length : Math.floor(scratchCardWinCount / matchedRandomNumbers.length) + 1;

//                         for (let i = 0; i < assignedPrizesCount; i++) {
//                             const prize = matchedRandomNumbers[prizeIndex % matchedRandomNumbers.length].price;
//                             assignedPrizes.push(prize);
//                             prizeIndex++;
//                         }

//                         prizeAssignments[userId] = assignedPrizes;
//                     }

//                     console.log('Prize Assignments:', prizeAssignments);

//                     // Update the scratchCardWin table with the assigned prizes
//                     const updatePromises = [];

//                     for (const userId of userIds) {
//                         const assignedPrizes = prizeAssignments[userId];

//                         for (const assignedPrize of assignedPrizes) {
//                             updatePromises.push(
//                                 db.scratchCardWin.update(
//                                     { prize: assignedPrize },
//                                     { where: { UserId: userId, scratchCardId } },
//                                 )
//                             );
//                         }
//                     }

//                     await Promise.all(updatePromises);

//                     return { success: true, message: 'Prizes distributed successfully.' };
//                 }
//             } catch (error) {
//                 console.error('Error while fetching data from the API:', error);
//             }
//         }

//         return { success: false, message: 'No match found.' };
//     },
// };

//***************************************** */

// const ScratchCardService = {
//     async updatePrize(scratchCardId) {
//         const scratchPlayData = await db.scratchCardPlay.findAll({
//             where: { scratchCardId },
//         });

//         if (scratchPlayData.length > 0) {
//             const randomNumberList = scratchPlayData.map((row) => row.randomNumber);

//             try {
//                 const apiResponse = await axios.get(
//                     `http://localhost:5000/api/scratchtable/scratchcard/${scratchCardId}`
//                 );
//                 const apiRandomNumber = apiResponse.data.data.calculatedData;
//                 const matchedRandomNumbers = apiRandomNumber.filter((item) =>
//                     randomNumberList.includes(item.rng)
//                 );
//                 let prizes = matchedRandomNumbers.map((item) => item.price);

//                 console.log('Matched Random Numbers:', matchedRandomNumbers);
//                 console.log('Prizes:', prizes);

//                 if (matchedRandomNumbers.length > 0) {
//                     const scratchCardWinCount = await db.scratchCardWin.count({ where: { scratchCardId } });
//                     console.log('scratchCardWin Count:', scratchCardWinCount);

//                     // Fetch all scratchCardWin entries with the same scratchCardId
//                     const scratchCardWins = await db.scratchCardWin.findAll({
//                         where: { scratchCardId },
//                     });

//                     const totalWins = scratchCardWins.length;

//                     // Randomly shuffle the prizes array
//                     prizes = shuffleArray(prizes);

//                     // Assign the prizes to the wins
//                     let prizeIndex = 0;

//                     for (let i = 0; i < totalWins; i++) {
//                         const scratchCardWin = scratchCardWins[i];

//                         const assignedPrize = prizes[prizeIndex];
//                         prizeIndex = (prizeIndex + 1) % prizes.length;

//                         // Update the prize column in the scratchCardWin table
//                         await scratchCardWin.update({ prize: assignedPrize });
//                     }

//                     return { success: true, message: 'Prizes distributed successfully.' };
//                 }
//             } catch (error) {
//                 console.error('Error while fetching data from the API:', error);
//             }
//         }

//         return { success: false, message: 'No match found.' };
//     },
// };

// // Function to shuffle an array in-place using Fisher-Yates algorithm
// function shuffleArray(array) {
//     for (let i = array.length - 1; i > 0; i--) {
//         const j = Math.floor(Math.random() * (i + 1));
//         [array[i], array[j]] = [array[j], array[i]];
//     }
//     return array;
// }

// module.exports = ScratchCardService;


// % Functionality use ------------------- Done ---------------------------------------



// const ScratchCardService = {
//     async updatePrize(scratchCardId) {
//         const scratchPlayData = await db.scratchCardPlay.findAll({
//             where: { scratchCardId },
//         });

//         if (scratchPlayData.length > 0) {
//             const randomNumberList = scratchPlayData.map((row) => row.randomNumber);

//             try {
//                 const apiResponse = await axios.get(
//                     `http://localhost:5000/api/scratchtable/scratch/${scratchCardId}`
//                 );
//                 const apiRandomNumber = apiResponse.data.data;

//                 const matchedRandomNumbers = apiRandomNumber.map((item) => ({
//                     rng: item.rng,
//                     odds_of_price: item.odds_of_price,
//                     price: item.price,
//                 }));

//                 console.log('Matched Random Numbers:', matchedRandomNumbers);

//                 if (matchedRandomNumbers.length > 0) {
//                     const scratchCardWinCount = await db.scratchCardWin.count({
//                         where: { scratchCardId },
//                     });
//                     console.log('scratchCardWin Count:', scratchCardWinCount);

//                     // Fetch all scratchCardWin entries with the same scratchCardId
//                     const scratchCardWins = await db.scratchCardWin.findAll({
//                         where: { scratchCardId },
//                     });

//                     // Calculate the total number of prizes based on odds_of_price
//                     const totalPrizes = matchedRandomNumbers.reduce(
//                         (sum, item) => sum + item.odds_of_price,
//                         0
//                     );
//                     // console.log(totalPrizes)
//                     // Assign the prizes to the wins based on odds_of_price
//                     let prizeIndex = 0;

//                     for (let i = 0; i < scratchCardWins.length; i++) {
//                         const scratchCardWin = scratchCardWins[i];
//                         const oddsOfPrice = matchedRandomNumbers[prizeIndex].odds_of_price;

//                         // Calculate the number of prizes each win will receive
//                         const numPrizes = Math.floor(scratchCardWinCount / oddsOfPrice);

//                         for (let j = 0; j < numPrizes; j++) {
//                             const assignedPrize = matchedRandomNumbers[prizeIndex].price;
//                             await scratchCardWin.update({ prize: assignedPrize });

//                         }

//                         prizeIndex = (prizeIndex + 1) % matchedRandomNumbers.length;
//                     }
//                     // console.log(prizeIndex)

//                     return { success: true, message: 'Prizes distributed successfully.' };
//                 }
//             } catch (error) {
//                 console.error('Error while fetching data from the API:', error);
//             }
//         }
//         return { success: false, message: 'No match found.' };
//     },
// };

//Done ===================================


// const ScratchCardService = {
//     async updatePrize(scratchCardId) {
//         const scratchPlayData = await db.scratchCardPlay.findAll({
//             where: { scratchCardId },
//         });

//         if (scratchPlayData.length > 0) {
//             const randomNumberList = scratchPlayData.map((row) => row.randomNumber);
//             console.log(randomNumberList)
//             try {
//                 const apiResponse = await axios.get(
//                     `http://localhost:5000/api/scratchtable/scratch/${scratchCardId}`
//                 );
//                 const apiRandomNumber = apiResponse.data.data;

//                 const matchedRandomNumbers = apiRandomNumber
//                     .filter((item) => {
//                         const rngValue = item.rng;
//                         const [min, max] = getRangeValues(rngValue); // Extract min and max values from rngValue
//                         return randomNumberList.some((number) => number >= min && number <= max);
//                     }).map((item) => ({
//                         rng: item.rng,
//                         odds_of_price: item.odds_of_price,
//                         price: item.price,
//                     }));

//                 console.log('Matched Random Numbers:', matchedRandomNumbers);

//                 if (matchedRandomNumbers.length > 0) {
//                     const scratchCardWinCount = await db.scratchCardWin.count({
//                         where: { scratchCardId },
//                     });
//                     console.log('scratchCardWin Count:', scratchCardWinCount);

//                     // Fetch all scratchCardWin entries with the same scratchCardId
//                     const scratchCardWins = await db.scratchCardWin.findAll({
//                         where: { scratchCardId },
//                     });

//                     // Calculate the total number of prizes based on odds_of_price
//                     const totalPrizes = matchedRandomNumbers.reduce(
//                         (sum, item) => sum + item.odds_of_price,
//                         0
//                     );

//                     // Assign the prizes to the wins based on odds_of_price
//                     let prizeIndex = 0;

//                     for (let i = 0; i < scratchCardWins.length; i++) {
//                         const scratchCardWin = scratchCardWins[i];
//                         const oddsOfPrice = matchedRandomNumbers[prizeIndex].odds_of_price;

//                         // Calculate the number of prizes each win will receive
//                         const numPrizes = Math.floor(scratchCardWinCount / oddsOfPrice);

//                         for (let j = 0; j < numPrizes; j++) {
//                             const assignedPrize = matchedRandomNumbers[prizeIndex].price;
//                             await scratchCardWin.update({ prize: assignedPrize });
//                         }

//                         prizeIndex = (prizeIndex + 1) % matchedRandomNumbers.length;
//                     }

//                     return { success: true, message: 'Prizes distributed successfully.' };
//                 }
//             } catch (error) {
//                 console.error('Error while fetching data from the API:', error);
//             }
//         }

//         return { success: false, message: 'No match found.' };
//     },
// };

// function getRangeValues(rngValue) {
//     const [min, max] = rngValue.split('-').map(Number);
//     return [min, max];
// }



const db = require('../../_helpers/db');
const axios = require('axios');
const { Sequelize } = require('sequelize');


// const ScratchCardService = {
//     async updatePrize(scratchCardId) {
//         const scratchPlayData = await db.scratchCardPlay.findAll({
//             where: { scratchCardId },
//         });

//         if (scratchPlayData.length > 0) {
//             const randomNumberList = scratchPlayData.map((row) => row.randomNumber);

//             try {
//                 const apiResponse = await axios.get(
//                     `http://localhost:5000/api/scratchtable/scratch/${scratchCardId}`
//                 );
//                 const apiRandomNumber = apiResponse.data.data;

//                 const matchedRandomNumbers = apiRandomNumber.map((item) => ({
//                     rng: item.rng,
//                     odds_of_price: item.odds_of_price,
//                     price: item.price,
//                 }));

//                 // console.log('Matched Random Numbers:', matchedRandomNumbers);

//                 if (matchedRandomNumbers.length > 0) {
//                     const scratchCardWinCount = await db.scratchCardWin.count({
//                         where: { scratchCardId },
//                     });
//                     // console.log('scratchCardWin Count:', scratchCardWinCount);

//                     const scratchCardWins = await db.scratchCardWin.findAll({
//                         where: { scratchCardId },
//                     });

//                     const totalPrizes = matchedRandomNumbers.reduce(
//                         (sum, item) => sum + item.odds_of_price,
//                         0
//                     );

//                     let prizeIndex = 0;

//                     for (let i = 0; i < scratchCardWins.length; i++) {
//                         const scratchCardWin = scratchCardWins[i];
//                         const oddsOfPrice = matchedRandomNumbers[prizeIndex].odds_of_price;

//                         const numPrizes = scratchCardWinCount; // Assign all prizes to each win

//                         for (let j = 0; j < numPrizes; j++) {
//                             const assignedPrize = matchedRandomNumbers[prizeIndex].price;
//                             await scratchCardWin.update({ prize: assignedPrize, status: 0 });
//                         }
//                         prizeIndex = (prizeIndex + 1) % matchedRandomNumbers.length;
//                     }
//                     // Update dailyStatus for all scratchCardWins with the same scratchCardId
//                     await db.scratchCardWin.update({ dailyStatus: Sequelize.literal('dailyStatus + 1') }, {
//                         where: { scratchCardId },
//                     });
//                     return { success: true, message: 'Prizes distributed successfully.' };
//                 }
//             } catch (error) {
//                 console.error('Error while fetching data from the API:', error);
//             }
//         }
//         return { success: false, message: 'No match found.' };
//     }
// };


// some good but rng 0 distribute -------------------------

// const ScratchCardService = {
//     async updatePrize(scratchCardId) {
//         const scratchPlayData = await db.scratchCardPlay.findAll({
//             where: { scratchCardId },
//         });

//         if (scratchPlayData.length > 0) {
//             try {
//                 const apiResponse = await axios.get(
//                     `http://localhost:5000/api/scratchtable/scratch/${scratchCardId}`
//                 );
//                 const apiRandomNumber = apiResponse.data.data;

//                 const matchedRandomNumbers = apiRandomNumber.map((item) => ({
//                     rng: item.rng,
//                     odds_of_price: item.odds_of_price,
//                     price: item.price,
//                 }));

//                 if (matchedRandomNumbers.length > 0) {
//                     const scratchCardWins = await db.scratchCardWin.findAll({
//                         where: { scratchCardId },
//                     });

//                     const shuffledIndices = shuffleArray(Array.from(Array(matchedRandomNumbers.length).keys()));

//                     for (let i = 0; i < scratchCardWins.length; i++) {
//                         const scratchCardWin = scratchCardWins[i];

//                         // Assign prizes only if the rng is not 0
//                         const prizeIndex = shuffledIndices[i];
//                         if (matchedRandomNumbers[prizeIndex].rng !== 0) {
//                             const assignedPrize = matchedRandomNumbers[prizeIndex].price;
//                             await scratchCardWin.update({ prize: assignedPrize, status: 0 });
//                         }
//                     }

//                     // Update dailyStatus for all scratchCardWins with the same scratchCardId
//                     await db.scratchCardWin.update(
//                         { dailyStatus: Sequelize.literal('dailyStatus + 1') },
//                         { where: { scratchCardId } }
//                     );

//                     return { success: true, message: 'Prizes distributed successfully.' };
//                 }
//             } catch (error) {
//                 console.error('Error while fetching data from the API:', error);
//             }
//         }

//         return { success: false, message: 'No match found.' };
//     },
// };

// function shuffleArray(array) {
//     for (let i = array.length - 1; i > 0; i--) {
//         const j = Math.floor(Math.random() * (i + 1));
//         [array[i], array[j]] = [array[j], array[i]];
//     }
//     return array;
// }

//-----------------------Perfect- ----------------------



// const ScratchCardService = {
//     async updatePrize(scratchCardId) {
//         const scratchPlayData = await db.scratchCardPlay.findAll({
//             where: { scratchCardId },
//         });

//         if (scratchPlayData.length > 0) {
//             try {
//                 const apiResponse = await axios.get(
//                     `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
//                 );
//                 const apiRandomNumber = apiResponse.data.data;

//                 const matchedRandomNumbers = apiRandomNumber.filter((item) => parseInt(item.odds_of_price) !== 0 && item.price !== '');

//                 if (matchedRandomNumbers.length > 0) {
//                     const scratchCardWins = await db.scratchCardWin.findAll({
//                         where: { scratchCardId },
//                     });
//                     const scratchCardWinsCount = await db.scratchCardWin.count({
//                         where: { scratchCardId },
//                     });
//                     console.log(scratchCardWinsCount)
//                     for (let i = 0; i < scratchCardWins.length; i++) {
//                         const scratchCardWin = scratchCardWins[i];

//                         if (matchedRandomNumbers.length > 0) {
//                             const randomIndex = Math.floor(Math.random() * matchedRandomNumbers.length);
//                             const assignedPrize = matchedRandomNumbers[randomIndex].price;
//                             await scratchCardWin.update({ prize: assignedPrize, status: 0 });
//                             matchedRandomNumbers.splice(randomIndex, 1);
//                         }
//                     }

//                     await db.scratchCardWin.update(
//                         { dailyStatus: Sequelize.literal('dailyStatus + 1') },
//                         { where: { scratchCardId } }
//                     );

//                     return { success: true, message: 'Prizes distributed successfully.' };
//                 }
//             } catch (error) {
//                 console.error('Error while fetching data from the API:', error);
//             }
//         }

//         return { success: false, message: 'No match found.' };
//     },
// };

//great 09-06-2023--------------------------------------------


// async function allUpdatePrize(scratchCardId) {
//     const scratchPlayData = await db.scratchCardPlay.findAll({
//         where: { scratchCardId },
//     });

//     if (scratchPlayData.length > 0) {
//         try {
//             const apiResponse = await axios.get(
//                 `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
//             );
//             const apiRandomNumber = apiResponse.data.data;

//             const matchedRandomNumbers = apiRandomNumber.filter(
//                 (item) => parseInt(item.odds_of_price) !== 0 && item.price !== ''
//             );

//             if (matchedRandomNumbers.length > 0) {
//                 const scratchCardWins = await db.scratchCardWin.findAll({
//                     where: { scratchCardId },
//                 });

//                 const assignedPrizes = [];

//                 for (let i = 0; i < scratchCardWins.length; i++) {
//                     const scratchCardWin = scratchCardWins[i];

//                     const randomIndex = Math.floor(Math.random() * matchedRandomNumbers.length);
//                     const assignedPrize = matchedRandomNumbers[randomIndex]?.price;

//                     if (assignedPrize) {
//                         await scratchCardWin.update({ prize: assignedPrize, status: 0 });
//                         assignedPrizes.push(assignedPrize);
//                     }
//                 }
//                 await db.scratchCardWin.update(
//                     { dailyStatus: Sequelize.literal('dailyStatus + 1'), rescheduleTime: Sequelize.literal('rescheduleTime + 1') },
//                     { where: { scratchCardId } }
//                 );

//                 return { success: true, message: 'Prizes distributed successfully.' };
//             }
//         } catch (error) {
//             console.error('Error while fetching data from the API:', error);
//         }
//     }

//     return { success: false, message: 'No match found.' };
// };

//great 09-06-2023---------Randomly -----------------------------------

// async function allUpdatePrize(scratchCardId) {
//     const scratchPlayData = await db.scratchCardPlay.findAll({
//         where: { scratchCardId },
//     });

//     if (scratchPlayData.length > 0) {
//         try {
//             const apiResponse = await axios.get(
//                 `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
//             );
//             const apiRandomNumber = apiResponse.data.data;

//             const matchedRandomNumbers = apiRandomNumber.filter(
//                 (item) => parseInt(item.odds_of_price) !== 0 && item.price !== ''
//             );

//             if (matchedRandomNumbers.length > 0) {
//                 const scratchCardWins = await db.scratchCardWin.findAll({
//                     where: { scratchCardId },
//                 });

//                 const assignedPrizes = [];
//                 const scratchCardWinCount = 30;

//                 for (let i = 0; i < scratchCardWins.length; i++) {
//                     const scratchCardWin = scratchCardWins[i];

//                     if (matchedRandomNumbers.length === 0) {
//                         break; // No more prizes to distribute
//                     }

//                     const randomIndex = Math.floor(Math.random() * matchedRandomNumbers.length);
//                     const assignedPrize = matchedRandomNumbers[randomIndex]?.price;
//                     console.log(assignedPrize)
//                     if (assignedPrize) {
//                         await scratchCardWin.update({ prize: assignedPrize, status: 0 });
//                         assignedPrizes.push(assignedPrize);
//                         matchedRandomNumbers.splice(randomIndex, 1); // Remove assigned prize from the list
//                     }
//                 }

//                 await db.scratchCardWin.update(
//                     { dailyStatus: Sequelize.literal('dailyStatus + 1'), rescheduleTime: Sequelize.literal('rescheduleTime + 1') },
//                     { where: { scratchCardId } }
//                 );

//                 return { success: true, message: 'Prizes distributed successfully.' };
//             }
//         } catch (error) {
//             console.error('Error while fetching data from the API:', error);
//         }
//     }

//     return { success: false, message: 'No match found.' };
// };

//-------------------------16-05-2023------- Good----------------------------------

// async function allUpdatePrize(scratchCardId) {
//     const scratchPlayData = await db.scratchCardPlay.findAll({
//         where: { scratchCardId },
//     });

//     if (scratchPlayData.length > 0) {
//         try {
//             const apiResponse = await axios.get(
//                 `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
//             );
//             const apiRandomNumber = apiResponse.data.data;

//             const matchedRandomNumbers = apiRandomNumber.filter(
//                 (item) => parseInt(item.odds_of_price) !== 0 && item.price !== ''
//             );

//             if (matchedRandomNumbers.length > 0) {
//                 const scratchCardWins = await db.scratchCardWin.findAll({
//                     where: { scratchCardId },
//                 });

//                 const assignedPrizes = [];
//                 let scratchCardWinCount = scratchCardWins.length;
//                 console.log(scratchCardWinCount, 'scratchCardWinCount')
//                 for (let i = 0; i < scratchCardWins.length; i++) {
//                     const scratchCardWin = scratchCardWins[i];
//                     const oddsOfPrice = parseInt(matchedRandomNumbers[i % matchedRandomNumbers.length].odds_of_price);
//                     const price = matchedRandomNumbers[i % matchedRandomNumbers.length].price;

//                     if (scratchCardWinCount > 0 && oddsOfPrice <= scratchCardWinCount) {
//                         await scratchCardWin.update({ prize: price, status: 0 });
//                         assignedPrizes.push(price);
//                         scratchCardWinCount -= oddsOfPrice;
//                     }
//                 }

//                 await db.scratchCardWin.update(
//                     { dailyStatus: Sequelize.literal('dailyStatus + 1'), rescheduleTime: Sequelize.literal('rescheduleTime + 1') },
//                     { where: { scratchCardId } }
//                 );

//                 return { success: true, message: 'Prizes distributed successfully.' };
//             }
//         } catch (error) {
//             console.error('Error while fetching data from the API:', error);
//         }
//     }

//     return { success: false, message: 'No match found.' };
// }

//-------------------------16-05-2023------- Good----------------------------------


// async function allUpdatePrize(scratchCardId) {
//     const assignedPrizes = [];

//     const scratchPlayData = await db.scratchCardPlay.findAll({
//         where: { scratchCardId },
//     });

//     if (scratchPlayData.length > 0) {
//         try {
//             const apiResponse = await axios.get(
//                 `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
//             );
//             const apiRandomNumber = apiResponse.data.data;

//             const matchedRandomNumbers = apiRandomNumber.filter(
//                 (item) => parseInt(item.odds_of_price) !== 0 && item.price !== ''
//             );

//             if (matchedRandomNumbers.length > 0) {
//                 const scratchCardWins = await db.scratchCardWin.findAll({
//                     where: { scratchCardId },
//                 });
//                 let scratchCardWinCount = scratchCardWins.length;

//                 for (let i = 0; i < scratchCardWins.length && scratchCardWinCount > 0; i++) {
//                     const scratchCardWin = scratchCardWins[i];
//                     const oddsOfPrice = parseInt(matchedRandomNumbers[i % matchedRandomNumbers.length].odds_of_price);
//                     const price = matchedRandomNumbers[i % matchedRandomNumbers.length].price;

//                     const remainingPrizes = Math.min(oddsOfPrice, scratchCardWinCount);
//                     for (let j = 0; j < remainingPrizes; j++) {
//                         assignedPrizes.push(price);
//                     }

//                     scratchCardWinCount -= remainingPrizes;
//                 }

//                 shuffleArray(assignedPrizes);
//                 console.log(assignedPrizes, 'assignedPrizes')
//                 for (let i = 0; i < scratchCardWins.length && i < assignedPrizes.length; i++) {
//                     const scratchCardWin = scratchCardWins[i];
//                     const assignedPrize = assignedPrizes[i];
//                     await scratchCardWin.update({ prize: assignedPrize, status: 0 });
//                 }

//                 await db.scratchCardWin.update(
//                     { dailyStatus: Sequelize.literal('dailyStatus + 1'), rescheduleTime: Sequelize.literal('rescheduleTime + 1') },
//                     { where: { scratchCardId } }
//                 );

//                 return { success: true, message: 'Prizes distributed successfully.' };
//             }
//         } catch (error) {
//             console.error('Error while fetching data from the API:', error);
//         }
//     }

//     return { success: false, message: 'No match found.' };
// }

// function shuffleArray(array) {
//     for (let i = array.length - 1; i > 0; i--) {
//         const j = Math.floor(Math.random() * (i + 1));
//         [array[i], array[j]] = [array[j], array[i]];
//     }
// }
//-------------------------16-05-2023------- Good----------------------------------

// async function allUpdatePrize(scratchCardId) {
//     const assignedPrizes = [];

//     const scratchPlayData = await db.scratchCardPlay.findAll({
//         where: { scratchCardId },
//     });

//     if (scratchPlayData.length > 0) {
//         try {
//             const apiResponse = await axios.get(
//                 `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
//             );
//             const apiRandomNumber = apiResponse.data.data;

//             const matchedRandomNumbers = apiRandomNumber.filter(
//                 (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ''
//             );

//             if (matchedRandomNumbers.length > 0) {
//                 const scratchCardWins = await db.scratchCardWin.findAll({
//                     where: { scratchCardId },
//                 });
//                 let scratchCardWinCount = scratchCardWins.length;
//                 // console.log(scratchCardWinCount, 'scratchCardWinCount')
//                 for (let i = 0; i < scratchCardWins.length && scratchCardWinCount > 0; i++) {
//                     const scratchCardWin = scratchCardWins[i];
//                     const oddsOfPrice = parseFloat(matchedRandomNumbers[i % matchedRandomNumbers.length].odds_of_price);
//                     const price = matchedRandomNumbers[i % matchedRandomNumbers.length].price;

//                     const remainingPrizes = Math.min(Math.floor(oddsOfPrice / 100 * scratchCardWinCount), scratchCardWinCount);
//                     for (let j = 0; j < remainingPrizes; j++) {
//                         assignedPrizes.push(price);
//                     }

//                     scratchCardWinCount -= remainingPrizes;
//                 }

//                 shuffleArray(assignedPrizes);
//                 console.log(assignedPrizes, 'assignedPrizes')
//                 for (let i = 0; i < scratchCardWins.length && i < assignedPrizes.length; i++) {
//                     const scratchCardWin = scratchCardWins[i];
//                     const assignedPrize = assignedPrizes[i];
//                     await scratchCardWin.update({ prize: assignedPrize, status: 0 });
//                 }

//                 await db.scratchCardWin.update(
//                     { dailyStatus: Sequelize.literal('dailyStatus + 1'), rescheduleTime: Sequelize.literal('rescheduleTime + 1') },
//                     { where: { scratchCardId } }
//                 );

//                 return { success: true, message: 'Prizes distributed successfully.' };
//             }
//         } catch (error) {
//             console.error('Error while fetching data from the API:', error);
//         }
//     }

//     return { success: false, message: 'No match found.' };
// }
// function shuffleArray(array) {
//     for (let i = array.length - 1; i > 0; i--) {
//         const j = Math.floor(Math.random() * (i + 1));
//         [array[i], array[j]] = [array[j], array[i]];
//     }
// }
//-------------------------16-05-2023------- Good----------------------------------
// async function allUpdatePrize(scratchCardId) {
//     const assignedPrizes = [];

//     const scratchPlayData = await db.scratchCardPlay.findAll({
//         where: { scratchCardId },
//     });

//     if (scratchPlayData.length > 0) {
//         try {
//             const apiResponse = await axios.get(
//                 `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
//             );
//             const apiRandomNumber = apiResponse.data.data;

//             const matchedRandomNumbers = apiRandomNumber.filter(
//                 (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ''
//             );

//             if (matchedRandomNumbers.length > 0) {
//                 const scratchCardWins = await db.scratchCardWin.findAll({
//                     where: { scratchCardId },
//                 });

//                 shuffleArray(scratchCardWins); // Shuffle the scratchCardWins array

//                 let scratchCardWinCount = scratchCardWins.length;

//                 for (let i = 0; i < scratchCardWins.length && scratchCardWinCount > 0; i++) {
//                     const scratchCardWin = scratchCardWins[i];
//                     const oddsOfPrice = parseFloat(matchedRandomNumbers[i % matchedRandomNumbers.length].odds_of_price);
//                     const price = matchedRandomNumbers[i % matchedRandomNumbers.length].price;

//                     const remainingPrizes = Math.min(Math.floor(oddsOfPrice / 100 * scratchCardWinCount), scratchCardWinCount);
//                     for (let j = 0; j < remainingPrizes; j++) {
//                         assignedPrizes.push(price);
//                     }

//                     scratchCardWinCount -= remainingPrizes;
//                 }

//                 shuffleArray(assignedPrizes);
//                 // console.log(assignedPrizes, 'assignedPrizes')
//                 for (let i = 0; i < scratchCardWins.length && i < assignedPrizes.length; i++) {
//                     const scratchCardWin = scratchCardWins[i];
//                     const assignedPrize = assignedPrizes[i];
//                     await scratchCardWin.update({ prize: assignedPrize, status: 0 });
//                 }

//                 await db.scratchCardWin.update(
//                     { dailyStatus: Sequelize.literal('dailyStatus + 1'), rescheduleTime: Sequelize.literal('rescheduleTime + 1') },
//                     { where: { scratchCardId } }
//                 );

//                 return { success: true, message: 'Prizes distributed successfully.' };
//             }
//         } catch (error) {
//             console.error('Error while fetching data from the API:', error);
//         }
//     }
//     return { success: false, message: 'No match found.' };
// }

// function shuffleArray(array) {
//     for (let i = array.length - 1; i > 0; i--) {
//         const j = Math.floor(Math.random() * (i + 1));
//         [array[i], array[j]] = [array[j], array[i]];
//     }
// }
//--------------------19-jun-2023-----------------
// async function userUpdatePrize(scratchCardId, userId) {
//     const scratchPlayData = await db.scratchCardPlay.findAll({
//         where: { scratchCardId },
//     });

//     if (scratchPlayData.length > 0) {
//         try {
//             const apiResponse = await axios.get(
//                 `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
//             );
//             const apiRandomNumber = apiResponse.data.data;

//             const matchedRandomNumbers = apiRandomNumber.filter(
//                 (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ''
//             );

//             if (matchedRandomNumbers.length > 0) {
//                 const scratchCardWins = await db.scratchCardWin.findAll({
//                     where: { scratchCardId, userId },
//                 });

//                 const assignedPrizes = [];

//                 for (let i = 0; i < scratchCardWins.length; i++) {
//                     const scratchCardWin = scratchCardWins[i];

//                     const randomIndex = Math.floor(Math.random() * matchedRandomNumbers.length);
//                     const assignedPrize = matchedRandomNumbers[randomIndex]?.price;

//                     if (assignedPrize) {
//                         // Replace the update logic based on your database model
//                         await scratchCardWin.update({ prize: assignedPrize, status: 0 });
//                         assignedPrizes.push(assignedPrize);
//                     }

//                 }
//                 return { success: true, message: 'Prizes distributed successfully.' };
//             }
//         } catch (error) {
//             console.error('Error while fetching data from the API:', error);
//         }
//     }

//     return { success: false, message: 'No match found.' };
// }


//--------------------19-jun-2023-----------------
//=-----------------Bard--------------

// async function userUpdatePrize(scratchCardId, userId) {
//     const scratchPlayData = await db.scratchCardPlay.findAll({
//         where: { scratchCardId },
//     });
//     if (scratchPlayData.length > 0) {
//         try {
//             const apiResponse = await axios.get(
//                 `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
//             );
//             const apiRandomNumber = apiResponse.data.data;
//             const matchedRandomNumbers = apiRandomNumber.filter(
//                 (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ''
//             );
//             if (matchedRandomNumbers.length > 0) {
//                 const scratchCardWins = await db.scratchCardWin.findAll({
//                     where: { scratchCardId, userId },
//                 });
//                 const assignedPrizes = [];
//                 for (let i = 0; i < scratchCardWins.length; i++) {
//                     const scratchCardWin = scratchCardWins[i];
//                     const randomIndex = Math.floor(
//                         Math.random() * matchedRandomNumbers.length
//                     );
//                     const assignedPrize = matchedRandomNumbers[randomIndex]?.price;
//                     const oddsOfPrice = matchedRandomNumbers[randomIndex]?.odds_of_price;
//                     if (assignedPrize) {
//                         console.log(assignedPrize, 'assignedPrize')
//                         if (i < (oddsOfPrice * scratchCardWins.length)) {
//                             await scratchCardWin.update({ prize: assignedPrize, status: 0 });
//                             assignedPrizes.push(assignedPrize);
//                         }
//                     }
//                 }
//                 return { success: true, message: 'Prizes distributed successfully.' };
//             }
//         } catch (error) {
//             console.error('Error while fetching data from the API:', error);
//         }
//     }
//     return { success: false, message: 'No match found.' };
// }
//-------------Done 20-Jun-2023----------------
// async function userUpdatePrize(scratchCardId, userId) {
//   const scratchPlayData = await db.scratchCardPlay.findAll({
//     where: { scratchCardId },
//   });
//   if (scratchPlayData.length > 0) {
//     try {
//       const apiResponse = await axios.get(`${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`);

//       const apiRandomNumber = apiResponse.data.data;
//       const matchedRandomNumbers = apiRandomNumber.filter(
//         (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== '');

//       if (matchedRandomNumbers.length > 0) {
//         const scratchCardWins = await db.scratchCardWin.findAll({
//           where: { scratchCardId, userId },
//         });

//         const assignedPrizes = [];
//         for (let i = 0; i < scratchCardWins.length; i++) {
//           const scratchCardWin = scratchCardWins[i];
//           const randomIndex = Math.floor(
//             Math.random() * matchedRandomNumbers.length
//           );
//           const assignedPrize = matchedRandomNumbers[randomIndex]?.price;
//           if (assignedPrize) {
//             const oddsOfPrice = matchedRandomNumbers[randomIndex].odds_of_price;
//             const prizeCount = Math.floor(oddsOfPrice * scratchCardWins.length);

//             for (let j = 0; j < prizeCount; j++) {
//               await scratchCardWin.update({ prize: assignedPrize, status: 0 });
//               assignedPrizes.push(assignedPrize);

//             }
//           }
//         }
//         return { success: true, message: 'Prizes distributed successfully.' };
//       }
//     } catch (error) {
//       console.error('Error while fetching data from the API:', error);
//     }
//   }
//   return { success: false, message: 'No match found.' };
// }


//=-----------------Bard-------- Done 20-Jun-2023 ---------

module.exports = { allUpdatePrize, userUpdatePrize };

// async function userUpdatePrize(scratchCardId, userId) {
//   const scratchPlayData = await db.scratchCardPlay.findAll({
//     where: { scratchCardId },
//   });

//   if (scratchPlayData.length > 0) {
//     try {
//       const apiResponse = await axios.get(
//         `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
//       );

//       const apiRandomNumber = apiResponse.data.data;
//       const matchedRandomNumbers = apiRandomNumber.filter(
//         (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ""
//       );

//       if (matchedRandomNumbers.length > 0) {
//         const scratchCardWins = await db.scratchCardWin.findAll({
//           where: { scratchCardId, userId },
//         });

//         const assignedPrizes = [];
//         const totalPrizes = scratchCardWins.length;

//         for (let i = 0; i < scratchCardWins.length; i++) {
//           const scratchCardWin = scratchCardWins[i];
//           const oddsSum = matchedRandomNumbers.reduce((sum, item) => sum + parseFloat(item.odds_of_price), 0);
//           let randomValue = Math.random() * oddsSum;

//           for (let j = 0; j < matchedRandomNumbers.length; j++) {
//             const matchedRandomNumber = matchedRandomNumbers[j];
//             const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);

//             if (randomValue < oddsOfPrice) {
//               const assignedPrize = matchedRandomNumber.price;
//               await scratchCardWin.update({ prize: assignedPrize, status: 0 });
//               assignedPrizes.push(assignedPrize);
//               break;
//             }

//             randomValue -= oddsOfPrice;
//           }
//         }

//         return { success: true, message: "Prizes distributed successfully." };
//       }
//     } catch (error) {
//       console.error("Error while fetching data from the API:", error);
//     }
//   }

//   return { success: false, message: "No match found." };
// }


async function userUpdatePrize(scratchCardId, userId) {
  const scratchPlayData = await db.scratchCardPlay.findAll({
    where: { scratchCardId },
  });

  if (scratchPlayData.length > 0) {
    try {
      const apiResponse = await axios.get(
        `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
      );

      const apiRandomNumber = apiResponse.data.data;
      const matchedRandomNumbers = apiRandomNumber.filter(
        (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ""
      );

      if (matchedRandomNumbers.length > 0) {
        const scratchCardWins = await db.scratchCardWin.findAll({
          where: { scratchCardId, userId },
        });

        const assignedPrizes = [];
        const totalPrizes = scratchCardWins.length;

        const oddsPercentageArray = [];
        let oddsSum = 0;

        for (let i = 0; i < matchedRandomNumbers.length; i++) {
          const matchedRandomNumber = matchedRandomNumbers[i];
          const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
          oddsSum += oddsOfPrice;
        }

        for (let i = 0; i < matchedRandomNumbers.length; i++) {
          const matchedRandomNumber = matchedRandomNumbers[i];
          const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
          const oddsPercentage = (oddsOfPrice / oddsSum) * 100;
          oddsPercentageArray.push(oddsPercentage);
        }

        for (let i = 0; i < totalPrizes; i++) {
          let randomValue = Math.random() * 100;

          for (let j = 0; j < matchedRandomNumbers.length; j++) {
            const matchedRandomNumber = matchedRandomNumbers[j];
            const assignedPrize = matchedRandomNumber.price;
            const oddsPercentage = oddsPercentageArray[j];

            if (randomValue < oddsPercentage) {
              assignedPrizes.push(assignedPrize);
              break;
            }

            randomValue -= oddsPercentage;
          }
        }

        // console.log("Assigned Prizes:", assignedPrizes);
        // console.log("Odds of Price Percentage:", oddsPercentageArray);

        return { success: true, message: "Prizes distributed successfully." };
      }
    } catch (error) {
      console.error("Error while fetching data from the API:", error);
    }
  }

  return { success: false, message: "No match found." };
}



//-----Bard All +++++++++++++++++++++++++++++++++++

// async function allUpdatePrize(scratchCardId) {
//     const assignedPrizes = [];

//     const scratchPlayData = await db.scratchCardPlay.findAll({
//         where: { scratchCardId },
//     });

//     if (scratchPlayData.length > 0) {
//         try {
//             const apiResponse = await axios.get(
//                 `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
//             );
//             const apiRandomNumber = apiResponse.data.data;

//             const matchedRandomNumbers = apiRandomNumber.filter(
//                 (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ''
//             );

//             if (matchedRandomNumbers.length > 0) {
//                 const scratchCardWins = await db.scratchCardWin.findAll({
//                     where: { scratchCardId },
//                 });

//                 shuffleArray(scratchCardWins); // Shuffle the scratchCardWins array

//                 let scratchCardWinCount = scratchCardWins.length;

//                 for (let i = 0; i < scratchCardWins.length && scratchCardWinCount > 0; i++) {
//                     const scratchCardWin = scratchCardWins[i];
//                     const oddsOfPrice = parseFloat(matchedRandomNumbers[i % matchedRandomNumbers.length].odds_of_price);
//                     const price = matchedRandomNumbers[i % matchedRandomNumbers.length].price;

//                     const remainingPrizes = Math.min(
//                         Math.floor(oddsOfPrice / 100 * scratchCardWinCount),
//                         scratchCardWinCount
//                     );
//                     for (let j = 0; j < remainingPrizes; j++) {
//                         assignedPrizes.push(price);
//                     }

//                     scratchCardWinCount -= remainingPrizes;
//                 }

//                 shuffleArray(assignedPrizes);

//                 for (let i = 0; i < scratchCardWins.length && i < assignedPrizes.length; i++) {
//                     const scratchCardWin = scratchCardWins[i];
//                     const assignedPrize = assignedPrizes[i];
//                     const prizeCount = Math.floor(assignedPrize / price);

//                     for (let j = 0; j < prizeCount; j++) {
//                         await scratchCardWin.update({ prize: price, status: 0 });
//                     }
//                 }

//                 await db.scratchCardWin.update(
//                     { dailyStatus: Sequelize.literal('dailyStatus + 1'), rescheduleTime: Sequelize.literal('rescheduleTime + 1') },
//                     { where: { scratchCardId } }
//                 );

//                 return { success: true, message: 'Prizes distributed successfully.' };
//             }
//         } catch (error) {
//             console.error('Error while fetching data from the API:', error);
//         }
//     }
//     return { success: false, message: 'No match found.' };
// }

// function shuffleArray(array) {
//     for (let i = array.length - 1; i > 0; i--) {
//         const j = Math.floor(Math.random() * (i + 1));
//         [array[i], array[j]] = [array[j], array[i]];
//     }
// }

//------------------This is done code ---------------20-jun-2023----------

async function allUpdatePrize(scratchCardId) {
  const assignedPrizes = [];

  const scratchPlayData = await db.scratchCardPlay.findAll({
    where: { scratchCardId },
  });

  if (scratchPlayData.length > 0) {
    try {
      const apiResponse = await axios.get(
        `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
      );
      const apiRandomNumber = apiResponse.data.data;

      const matchedRandomNumbers = apiRandomNumber.filter(
        (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ''
      );

      if (matchedRandomNumbers.length > 0) {
        const scratchCardWins = await db.scratchCardWin.findAll({
          where: { scratchCardId },
        });


        let scratchCardWinCount = scratchCardWins.length;

        for (let i = 0; i < scratchCardWins.length; i++) {
          const scratchCardWin = scratchCardWins[i];
          const oddsOfPrice = parseFloat(matchedRandomNumbers[i % matchedRandomNumbers.length].odds_of_price);
          const price = matchedRandomNumbers[i % matchedRandomNumbers.length].price;

          const remainingPrizes = Math.min(Math.floor(oddsOfPrice / 100 * scratchCardWins.length), scratchCardWins.length);
          for (let j = 0; j < remainingPrizes; j++) {
            assignedPrizes.push(price);
          }

          scratchCardWinCount -= remainingPrizes;
        }

        shuffleArray(assignedPrizes);
        // console.log(assignedPrizes, 'assignedPrizes')
        for (let i = 0; i < scratchCardWins.length && i < assignedPrizes.length; i++) {
          const scratchCardWin = scratchCardWins[i];
          const assignedPrize = assignedPrizes[i];
          await scratchCardWin.update({ prize: assignedPrize, status: 0 });
        }

        await db.scratchCardWin.update(
          { dailyStatus: Sequelize.literal('dailyStatus + 1'), rescheduleTime: Sequelize.literal('rescheduleTime + 1') },
          { where: { scratchCardId } }
        );

        return { success: true, message: 'Prizes distributed successfully.' };
      }
    } catch (error) {
      console.error('Error while fetching data from the API:', error);
    }
  }
  return { success: false, message: 'No match found.' };
}

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

//------------------This is done code ---------------20-jun-2023----------



//------------------This is done code ---------------04-july-2023----------

async function userUpdatePrize(scratchCardId, userId) {
  const scratchPlayData = await db.scratchCardPlay.findAll({
    where: { scratchCardId },
  });

  if (scratchPlayData.length > 0) {
    try {
      const apiResponse = await axios.get(
        `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
      );

      const apiRandomNumber = apiResponse.data.data;
      const matchedRandomNumbers = apiRandomNumber.filter(
        (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ""
      );

      if (matchedRandomNumbers.length > 0) {
        const scratchCardWins = await db.scratchCardWin.findAll({
          where: { scratchCardId, userId },
        });

        const assignedPrizes = [];
        const totalPrizes = scratchCardWins.length;
        console.log(totalPrizes, "totalPrizes");
        const oddsPercentageArray = [];
        let oddsSum = 0;

        for (let i = 0; i < matchedRandomNumbers.length; i++) {
          const matchedRandomNumber = matchedRandomNumbers[i];
          const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
          oddsSum += oddsOfPrice;

          // Calculate the time to distribute for each oddsOfPrice
          const timeToDistribute = (scratchCardWins.length) * (oddsOfPrice) / 100;
          const assignedPrize = matchedRandomNumber.price;
          const distributedCount = Math.round(timeToDistribute);

          console.log(`Time to distribute for oddsOfPrice ${oddsOfPrice} (${assignedPrize}): ${distributedCount}`);

          for (let j = 0; j < distributedCount; j++) {
            assignedPrizes.push(assignedPrize);
          }
        }
        console.log(randomValue, "fffffffffff")

        for (let i = 0; i < totalPrizes; i++) {
          let randomValue = Math.random() * 100;

          console.log(randomValue, "")

          for (let j = 0; j < matchedRandomNumbers.length; j++) {
            const matchedRandomNumber = matchedRandomNumbers[j];
            const assignedPrize = matchedRandomNumber.price;
            const oddsPercentage = oddsPercentageArray[j];

            if (randomValue < oddsPercentage) {
              const scratchCardWin = scratchCardWins[i];
              const remainingCount = scratchCardWin.count - scratchCardWin.distributedCount;
              const prizeCount = Math.min(remainingCount, scratchCardWin.count * (oddsPercentage / 100));
              const distributedPrizeCount = Math.floor(prizeCount);

              await scratchCardWin.update({ prize: assignedPrize, status: 0 });
              assignedPrizes.push(assignedPrize);
              break;
            }

            randomValue -= oddsPercentage;
          }
        }

        console.log("Assigned Prizes:", assignedPrizes);
        console.log("Odds of Price Percentage:", oddsPercentageArray);

        return { success: true, message: "Prizes distributed successfully." };
      }
    } catch (error) {
      console.error("Error while fetching data from the API:", error);
    }
  }

  return { success: false, message: "No match found." };
}

//------------------This is done code ---------------04-July -2023----------
async function userUpdatePrize(scratchCardId, userId) {
  const scratchPlayData = await db.scratchCardPlay.findAll({
    where: { scratchCardId },
  });

  if (scratchPlayData.length > 0) {
    try {
      const apiResponse = await axios.get(
        `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
      );

      const apiRandomNumber = apiResponse.data.data;
      const matchedRandomNumbers = apiRandomNumber.filter(
        (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ""
      );

      if (matchedRandomNumbers.length > 0) {
        const scratchCardWins = await db.scratchCardWin.findAll({
          where: { scratchCardId, userId },
        });

        const assignedPrizes = [];
        const totalPrizes = scratchCardWins.length;
        console.log(totalPrizes, "totalPrizes");
        const oddsPercentageArray = [];
        let oddsSum = 0;

        for (let i = 0; i < matchedRandomNumbers.length; i++) {
          const matchedRandomNumber = matchedRandomNumbers[i];
          const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
          oddsSum += oddsOfPrice;

          // Calculate the time to distribute for each oddsOfPrice
          const timeToDistribute = (scratchCardWins.length) * (oddsOfPrice) / 100;
          const assignedPrize = matchedRandomNumber.price;
          const distributedCount = Math.round(timeToDistribute);

          console.log(`Time to distribute for oddsOfPrice ${oddsOfPrice} (${assignedPrize}): ${distributedCount}`);

          for (let j = 0; j < distributedCount; j++) {
            assignedPrizes.push(assignedPrize);
          }
        }
        for (let i = 0; i < totalPrizes; i++) {
          let randomValue = Math.random() * 100;

          for (let j = 0; j < matchedRandomNumbers.length; j++) {
            const matchedRandomNumber = matchedRandomNumbers[j];
            const assignedPrize = matchedRandomNumber.price;
            const oddsPercentage = oddsPercentageArray[j];
            // console.log(randomValue < oddsPercentage)
            if (randomValue < oddsPercentage) {
              const scratchCardWin = scratchCardWins[i];
              const remainingCount = scratchCardWin.count - scratchCardWin.distributedCount;
              const prizeCount = Math.min(remainingCount, scratchCardWin.count * (oddsPercentage / 100));
              const distributedPrizeCount = Math.floor(prizeCount);

              await scratchCardWin.update({ prize: assignedPrize, status: 0, distributedCount: distributedPrizeCount });
              assignedPrizes.push(assignedPrize);
              console.log(`Updating scratchCardWin with prize ${assignedPrize}`);
              console.log(`Remaining Count: ${remainingCount}`);
              console.log(`Distributed Prize Count: ${distributedPrizeCount}`);
              break;
            }

            randomValue -= oddsPercentage;
          }
        }

        console.log("Assigned Prizes:", assignedPrizes);
        console.log("Odds of Price Percentage:", oddsPercentageArray);

        return { success: true, message: "Prizes distributed successfully." };
      }
    } catch (error) {
      console.error("Error while fetching data from the API:", error);
    }
  }

  return { success: false, message: "No match found." };
}



async function userUpdatePrize(scratchCardId, userId) {
  const scratchPlayData = await db.scratchCardPlay.findAll({
    where: { scratchCardId },
  });

  if (scratchPlayData.length > 0) {
    try {
      const apiResponse = await axios.get(
        `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
      );

      const apiRandomNumber = apiResponse.data.data;
      const matchedRandomNumbers = apiRandomNumber.filter(
        (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ""
      );

      if (matchedRandomNumbers.length > 0) {
        const scratchCardWins = await db.scratchCardWin.findAll({
          where: { scratchCardId, userId },
        });

        const assignedPrizes = [];
        const totalPrizes = scratchCardWins.length;
        console.log(totalPrizes, "totalPrizes");
        const oddsPercentageArray = [];
        let oddsSum = 0;

        for (let i = 0; i < matchedRandomNumbers.length; i++) {
          const matchedRandomNumber = matchedRandomNumbers[i];
          const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
          oddsSum += oddsOfPrice;

          // Calculate the time to distribute for each oddsOfPrice
          const timeToDistribute = (scratchCardWins.length) * (oddsOfPrice) / 100;
          const assignedPrize = matchedRandomNumber.price;
          const distributedCount = Math.round(timeToDistribute);

          console.log(`Time to distribute for oddsOfPrice ${oddsOfPrice} (${assignedPrize}): ${distributedCount}`);

          for (let j = 0; j < distributedCount; j++) {
            assignedPrizes.push(assignedPrize);
          }
        }
        for (let i = 0; i < totalPrizes; i++) {
          let randomValue = Math.random() * oddsSum;

          for (let j = 0; j < matchedRandomNumbers.length; j++) {
            const matchedRandomNumber = matchedRandomNumbers[j];
            const assignedPrize = matchedRandomNumber.price;
            const oddsPercentage = parseFloat(matchedRandomNumber.odds_of_price) / oddsSum;


            if (randomValue <= oddsPercentage) {
              const scratchCardWin = scratchCardWins[i];
              const remainingCount = scratchCardWin.count - scratchCardWin.distributedCount;
              const prizeCount = Math.min(remainingCount, scratchCardWin.count * (oddsPercentage / 100));
              const distributedPrizeCount = Math.floor(prizeCount);

              await scratchCardWin.update({ prize: assignedPrizes[i], status: 0, distributedCount: distributedPrizeCount });
              console.log(`Updating scratchCardWin with prize ${assignedPrizes[i]}`);
              console.log(`Remaining Count: ${remainingCount}`);
              console.log(`Distributed Prize Count: ${distributedPrizeCount}`);
              break;
            }

            randomValue -= oddsPercentage;
          }
        }

        console.log("Assigned Prizes:", assignedPrizes);
        console.log("Odds of Price Percentage:", oddsPercentageArray);

        return { success: true, message: "Prizes distributed successfully." };
      }
    } catch (error) {
      console.error("Error while fetching data from the API:", error);
    }
  }

  return { success: false, message: "No match found." };
}

//2nd ----------------------------------------------------


const axios = require('axios');
const { Sequelize } = require('sequelize');
const db = require('../../_helpers/db');


// async function userUpdatePrize(scratchCardId, userId) {
//   const scratchPlayData = await db.scratchCardPlay.findAll({
//     where: { scratchCardId },
//   });

//   if (scratchPlayData.length > 0) {
//     try {
//       const apiResponse = await axios.get(
//         `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
//       );

//       const apiRandomNumber = apiResponse.data.data;
//       const matchedRandomNumbers = apiRandomNumber.filter(
//         (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ""
//       );

//       if (matchedRandomNumbers.length > 0) {
//         const scratchCardWins = await db.scratchCardWin.findAll({
//           where: { scratchCardId, userId },
//         });

//         const assignedPrizes = [];
//         const totalPrizes = scratchCardWins.length;
//         console.log(totalPrizes, "totalPrizes")
//         const oddsPercentageArray = [];
//         let oddsSum = 0;

//         for (let i = 0; i < matchedRandomNumbers.length; i++) {
//           const matchedRandomNumber = matchedRandomNumbers[i];
//           const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
//           oddsSum += oddsOfPrice;
//         }

//         for (let i = 0; i < matchedRandomNumbers.length; i++) {
//           const matchedRandomNumber = matchedRandomNumbers[i];
//           const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
//           console.log(oddsOfPrice, "oddsOfPrice")
//           const oddsPercentage = Math.floor((oddsOfPrice / oddsSum) * 100);
//           oddsPercentageArray.push(oddsPercentage);
//         }

//         for (let i = 0; i < totalPrizes; i++) {
//           let randomValue = Math.random() * 100;

//           for (let j = 0; j < matchedRandomNumbers.length; j++) {
//             const matchedRandomNumber = matchedRandomNumbers[j];
//             const assignedPrize = matchedRandomNumber.price;
//             const oddsPercentage = oddsPercentageArray[j];

//             if (randomValue < oddsPercentage) {
//               const scratchCardWin = scratchCardWins[i];
//               await scratchCardWin.update({ prize: assignedPrize, status: 0 });
//               assignedPrizes.push(assignedPrize);
//               break;
//             }

//             randomValue -= oddsPercentage;
//           }
//         }

//         console.log("Assigned Prizes:", assignedPrizes);
//         console.log("Odds of Price Percentage:", oddsPercentageArray);

//         return { success: true, message: "Prizes distributed successfully." };
//       }
//     } catch (error) {
//       console.error("Error while fetching data from the API:", error);
//     }
//   }

//   return { success: false, message: "No match found." };
// }


// async function userUpdatePrize(scratchCardId, userId) {
//   const scratchPlayData = await db.scratchCardPlay.findAll({
//     where: { scratchCardId },
//   });

//   if (scratchPlayData.length > 0) {
//     try {
//       const apiResponse = await axios.get(
//         `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
//       );

//       const apiRandomNumber = apiResponse.data.data;
//       const matchedRandomNumbers = apiRandomNumber.filter(
//         (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ""
//       );

//       if (matchedRandomNumbers.length > 0) {
//         const scratchCardWins = await db.scratchCardWin.findAll({
//           where: { scratchCardId, userId },
//         });

//         const assignedPrizes = [];
//         const totalPrizes = scratchCardWins.length;
//         console.log(totalPrizes, "totalPrizes");
//         const oddsPercentageArray = [];
//         let oddsSum = 0;

//         for (let i = 0; i < matchedRandomNumbers.length; i++) {
//           const matchedRandomNumber = matchedRandomNumbers[i];
//           const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
//           oddsSum += oddsOfPrice;

//           // Calculate the time to distribute for each oddsOfPrice
//           const timeToDistribute = (scratchCardWins.length) * (oddsOfPrice) / 100;
//           console.log(`Time to distribute for oddsOfPrice ${oddsOfPrice} : ${timeToDistribute}`);
//         }

//         for (let i = 0; i < matchedRandomNumbers.length; i++) {
//           const matchedRandomNumber = matchedRandomNumbers[i];
//           const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
//           const oddsPercentage = Math.floor((oddsOfPrice / oddsSum) * 100);
//           oddsPercentageArray.push(oddsPercentage);
//         }

//         let prizeIndex = 0;

//         for (let i = 0; i < totalPrizes; i++) {
//           let randomValue = Math.random() * 100;

//           for (let j = 0; j < matchedRandomNumbers.length; j++) {
//             const matchedRandomNumber = matchedRandomNumbers[j];
//             const assignedPrize = matchedRandomNumber.price;
//             const oddsPercentage = oddsPercentageArray[j];

//             if (randomValue < oddsPercentage) {
//               const scratchCardWin = scratchCardWins[i];
//               const remainingCount = scratchCardWin.count - scratchCardWin.distributedCount;
//               const prizeCount = Math.min(remainingCount, scratchCardWin.count * (oddsPercentage / 100));
//               const distributedPrizeCount = Math.floor(prizeCount);

//               await scratchCardWin.update({ prize: assignedPrize, status: 0, distributedCount: distributedPrizeCount });
//               assignedPrizes.push(assignedPrize);
//               break;
//             }

//             randomValue -= oddsPercentage;
//           }
//         }

//         console.log("Assigned Prizes:", assignedPrizes);
//         console.log("Odds of Price Percentage:", oddsPercentageArray);

//         return { success: true, message: "Prizes distributed successfully." };
//       }
//     } catch (error) {
//       console.error("Error while fetching data from the API:", error);
//     }
//   }

//   return { success: false, message: "No match found." };
// }

// async function userUpdatePrize(scratchCardId, userId) {
//   const scratchPlayData = await db.scratchCardPlay.findAll({
//     where: { scratchCardId },
//   });

//   if (scratchPlayData.length > 0) {
//     try {
//       const apiResponse = await axios.get(
//         `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
//       );

//       const apiRandomNumber = apiResponse.data.data;
//       const matchedRandomNumbers = apiRandomNumber.filter(
//         (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ""
//       );

//       if (matchedRandomNumbers.length > 0) {
//         const scratchCardWins = await db.scratchCardWin.findAll({
//           where: { scratchCardId, userId },
//         });

//         const assignedPrizes = [];
//         const totalPrizes = scratchCardWins.length;
//         console.log(totalPrizes, "totalPrizes");
//         const oddsPercentageArray = [];
//         let oddsSum = 0;

//         for (let i = 0; i < matchedRandomNumbers.length; i++) {
//           const matchedRandomNumber = matchedRandomNumbers[i];
//           const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
//           oddsSum += oddsOfPrice;

//           // Calculate the time to distribute for each oddsOfPrice
//           const timeToDistribute = (scratchCardWins.length) * (oddsOfPrice) / 100;
//           console.log(`Time to distribute for oddsOfPrice ${oddsOfPrice} (${matchedRandomNumber.price}): ${timeToDistribute}`);
//         }

//         for (let i = 0; i < matchedRandomNumbers.length; i++) {
//           const matchedRandomNumber = matchedRandomNumbers[i];
//           const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
//           const oddsPercentage = Math.floor((oddsOfPrice / oddsSum) * 100);
//           oddsPercentageArray.push(oddsPercentage);
//         }

//         let prizeIndex = 0;

//         for (let i = 0; i < totalPrizes; i++) {
//           let randomValue = Math.random() * 100;

//           for (let j = 0; j < matchedRandomNumbers.length; j++) {
//             const matchedRandomNumber = matchedRandomNumbers[j];
//             const assignedPrize = matchedRandomNumber.price;
//             const oddsPercentage = oddsPercentageArray[j];

//             if (randomValue < oddsPercentage) {
//               const scratchCardWin = scratchCardWins[i];
//               const remainingCount = scratchCardWin.count - scratchCardWin.distributedCount;
//               const prizeCount = Math.min(remainingCount, scratchCardWin.count * (oddsPercentage / 100));
//               const distributedPrizeCount = Math.floor(prizeCount);

//               await scratchCardWin.update({ prize: assignedPrize, status: 0, distributedCount: distributedPrizeCount });
//               assignedPrizes.push(assignedPrize);
//               break;
//             }

//             randomValue -= oddsPercentage;
//           }
//         }

//         console.log("Assigned Prizes:", assignedPrizes);
//         console.log("Odds of Price Percentage:", oddsPercentageArray);

//         return { success: true, message: "Prizes distributed successfully." };
//       }
//     } catch (error) {
//       console.error("Error while fetching data from the API:", error);
//     }
//   }

//   return { success: false, message: "No match found." };
// }

// async function userUpdatePrize(scratchCardId, userId) {
//   const scratchPlayData = await db.scratchCardPlay.findAll({
//     where: { scratchCardId },
//   });

//   if (scratchPlayData.length > 0) {
//     try {
//       const apiResponse = await axios.get(
//         `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
//       );

//       const apiRandomNumber = apiResponse.data.data;
//       const matchedRandomNumbers = apiRandomNumber.filter(
//         (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ""
//       );

//       if (matchedRandomNumbers.length > 0) {
//         const scratchCardWins = await db.scratchCardWin.findAll({
//           where: { scratchCardId, userId },
//         });

//         const assignedPrizes = [];
//         const totalPrizes = scratchCardWins.length;
//         console.log(totalPrizes, "totalPrizes");
//         const oddsPercentageArray = [];
//         let oddsSum = 0;

//         for (let i = 0; i < matchedRandomNumbers.length; i++) {
//           const matchedRandomNumber = matchedRandomNumbers[i];
//           const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
//           oddsSum += oddsOfPrice;

//           // Calculate the time to distribute for each oddsOfPrice
//           let timeToDistribute = Math.floor(totalPrizes * (oddsOfPrice / 100));
//           const assignedPrize = matchedRandomNumber.price;

//           if (timeToDistribute > 0 && timeToDistribute < 1) {
//             // If the value is between 0 and 1, round up to 1
//             timeToDistribute = 1;
//           } else {
//             timeToDistribute = Math.ceil(timeToDistribute);
//           }

//           console.log(`Time to distribute for oddsOfPrice ${oddsOfPrice} (${assignedPrize}): ${timeToDistribute}`);

//           for (let j = 0; j < timeToDistribute; j++) {
//             assignedPrizes.push(assignedPrize);
//           }
//         }

//         let prizeIndex = 0;

//         for (let i = 0; i < totalPrizes; i++) {
//           let randomValue = Math.random() * 100;

//           for (let j = 0; j < matchedRandomNumbers.length; j++) {
//             const matchedRandomNumber = matchedRandomNumbers[j];
//             const assignedPrize = matchedRandomNumber.price;
//             const oddsPercentage = oddsPercentageArray[j];

//             if (randomValue < oddsPercentage) {
//               const scratchCardWin = scratchCardWins[i];
//               const remainingCount = scratchCardWin.count - scratchCardWin.distributedCount;
//               const prizeCount = Math.min(remainingCount, scratchCardWin.count * (oddsPercentage / 100));
//               const distributedPrizeCount = Math.floor(prizeCount);

//               await scratchCardWin.update({ prize: assignedPrize, status: 0, distributedCount: distributedPrizeCount });
//               break;
//             }

//             randomValue -= oddsPercentage;
//           }
//         }

//         console.log("Assigned Prizes:", assignedPrizes);
//         console.log("Odds of Price Percentage:", oddsPercentageArray);

//         return { success: true, message: "Prizes distributed successfully." };
//       }
//     } catch (error) {
//       console.error("Error while fetching data from the API:", error);
//     }
//   }

//   return { success: false, message: "No match found." };
// }

//--------------------------Good Time------------


async function userUpdatePrize(scratchCardId, userId) {
  const scratchPlayData = await db.scratchCardPlay.findAll({
    where: { scratchCardId },
  });

  if (scratchPlayData.length > 0) {
    try {
      const apiResponse = await axios.get(
        `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
      );

      const apiRandomNumber = apiResponse.data.data;
      const matchedRandomNumbers = apiRandomNumber.filter(
        (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ""
      );

      if (matchedRandomNumbers.length > 0) {
        const scratchCardWins = await db.scratchCardWin.findAll({
          where: { scratchCardId, userId },
        });

        const assignedPrizes = [];
        const totalPrizes = scratchCardWins.length;
        console.log(totalPrizes, "totalPrizes");
        let oddsSum = 0;

        for (let i = 0; i < matchedRandomNumbers.length; i++) {
          const matchedRandomNumber = matchedRandomNumbers[i];
          const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
          oddsSum += oddsOfPrice;

          const timeToDistribute = (scratchCardWins.length) * (oddsOfPrice) / 100;
          const assignedPrize = matchedRandomNumber.price;
          const distributedCount = Math.round(timeToDistribute);

          console.log(`Time to distribute for oddsOfPrice ${oddsOfPrice} (${assignedPrize}): ${distributedCount}----------${timeToDistribute}`);

          for (let j = 0; j < distributedCount; j++) {
            assignedPrizes.push(assignedPrize);
          }
        }
        // for (let i = 0; i < scratchCardWins.length; i++) {
        //   const scratchCardWin = scratchCardWins[i];
        //   const assignedPrize = assignedPrizes[i];

        //   await scratchCardWin.update({ prize: assignedPrize });
        // }
        while (assignedPrizes.length < totalPrizes) {
          const remainingCount = totalPrizes - assignedPrizes.length;
          const remainingPrizes = matchedRandomNumbers.filter(
            (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== '' && !assignedPrizes.includes(item.price)
          );

          remainingPrizes.sort((a, b) => {
            const diffA = Math.abs(0.5 - ((scratchCardWins.length * parseFloat(a.odds_of_price)) / (100 * oddsSum)));
            const diffB = Math.abs(0.5 - ((scratchCardWins.length * parseFloat(b.odds_of_price)) / (100 * oddsSum)));
            return diffA - diffB;
          });

          for (let i = 0; i < remainingCount; i++) {
            assignedPrizes.push(remainingPrizes[i].price);
          }
        }

        for (let i = 0; i < scratchCardWins.length && i < assignedPrizes.length; i++) {
          const scratchCardWin = scratchCardWins[i];
          const assignedPrize = assignedPrizes[i];

          await scratchCardWin.update({ prize: assignedPrize, status: 0 });
        }
        console.log("Assigned Prizes:", assignedPrizes);
        return { success: true, message: "Prizes distributed successfully." };
      }
    } catch (error) {
      console.error("Error while fetching data from the API:", error);
    }
  }

  return { success: false, message: "No match found." };
}




// async function userUpdatePrize(scratchCardId, userId) {
//   const scratchPlayData = await db.scratchCardPlay.findAll({
//     where: { scratchCardId },
//   });

//   if (scratchPlayData.length > 0) {
//     try {
//       const apiResponse = await axios.get(
//         `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
//       );

//       const apiRandomNumber = apiResponse.data.data;
//       const matchedRandomNumbers = apiRandomNumber.filter(
//         (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ""
//       );

//       if (matchedRandomNumbers.length > 0) {
//         const scratchCardWins = await db.scratchCardWin.findAll({
//           where: { scratchCardId, userId },
//         });

//         const assignedPrizes = [];
//         const totalPrizes = scratchCardWins.length;
//         console.log(totalPrizes, "totalPrizes");

//         let oddsSum = 0;

//         for (let i = 0; i < matchedRandomNumbers.length; i++) {
//           const matchedRandomNumber = matchedRandomNumbers[i];
//           const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
//           oddsSum += oddsOfPrice;
//         }

//         const oddsPercentageArray = [];

//         for (let i = 0; i < matchedRandomNumbers.length; i++) {
//           const matchedRandomNumber = matchedRandomNumbers[i];
//           const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
//           const oddsPercentage = Math.floor((oddsOfPrice / oddsSum) * 100);
//           oddsPercentageArray.push(oddsPercentage);
//         }

//         const assignedPrizesCount = Array(matchedRandomNumbers.length).fill(0);
//         let prizesDistributed = 0;

//         while (prizesDistributed < totalPrizes) {
//           for (let i = 0; i < oddsPercentageArray.length; i++) {
//             const oddsPercentage = oddsPercentageArray[i];
//             const numPrizesToDistribute = Math.floor((oddsPercentage / 100) * totalPrizes);

//             // Handle the case where numPrizesToDistribute exceeds the remaining available prizes
//             const remainingPrizes = totalPrizes - prizesDistributed;
//             const actualNumPrizesToDistribute = Math.min(numPrizesToDistribute, remainingPrizes);

//             for (let j = 0; j < actualNumPrizesToDistribute; j++) {
//               const assignedPrize = matchedRandomNumbers[i].price;
//               const scratchCardWin = scratchCardWins[prizesDistributed];
//               await scratchCardWin.update({ prize: assignedPrize, status: 0 });
//               assignedPrizes.push(assignedPrize);
//               assignedPrizesCount[i]++;
//               prizesDistributed++;
//               if (prizesDistributed >= totalPrizes) break;
//             }
//             if (prizesDistributed >= totalPrizes) break;
//           }
//         }

//         console.log("Assigned Prizes:", assignedPrizes);
//         console.log("Assigned Prizes Count:", assignedPrizesCount);
//         console.log("Odds of Price Percentage:", oddsPercentageArray);

//         return { success: true, message: "Prizes distributed successfully." };
//       }
//     } catch (error) {
//       console.error("Error while fetching data from the API:", error);
//     }
//   }

//   return { success: false, message: "No match found." };
// }

//===================================================


// async function userUpdatePrize(scratchCardId, userId) {
//   const scratchPlayData = await db.scratchCardPlay.findAll({
//     where: { scratchCardId },
//   });

//   if (scratchPlayData.length === 0) {
//     return { success: false, message: "No match found." };
//   }

//   try {
//     const apiResponse = await axios.get(
//       `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
//     );

//     const apiRandomNumber = apiResponse.data.data;
//     const matchedRandomNumbers = apiRandomNumber.filter(
//       (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ""
//     );

//     if (matchedRandomNumbers.length === 0) {
//       return { success: false, message: "No prizes to distribute." };
//     }

//     const scratchCardWins = await db.scratchCardWin.findAll({
//       where: { scratchCardId, userId },
//     });

//     const assignedPrizes = [];
//     const totalPrizes = scratchCardWins.length;
//     console.log(totalPrizes, "totalPrizes");
//     const oddsSum = matchedRandomNumbers.reduce((sum, item) => sum + parseFloat(item.odds_of_price), 0);
//     const oddsPercentageArray = matchedRandomNumbers.map((item) => (parseFloat(item.odds_of_price) / oddsSum) * 100);

//     for (let i = 0; i < totalPrizes; i++) {
//       const randomValue = Math.random() * 100;
//       let cumulativePercentage = 0;

//       for (let j = 0; j < matchedRandomNumbers.length; j++) {
//         const matchedRandomNumber = matchedRandomNumbers[j];
//         const assignedPrize = matchedRandomNumber.price;
//         const oddsPercentage = oddsPercentageArray[j];

//         cumulativePercentage += oddsPercentage;

//         if (randomValue < cumulativePercentage) {
//           const quantity = Math.ceil((oddsPercentage / 100) * totalPrizes);
//           for (let k = 0; k < quantity; k++) {
//             const scratchCardWin = scratchCardWins[i + k];
//             await scratchCardWin.update({ prize: assignedPrize, status: 0 });
//             assignedPrizes.push(assignedPrize);
//           }
//           break;
//         }
//       }
//     }

//     console.log("Assigned Prizes:", assignedPrizes);
//     console.log("Odds of Price Percentage:", oddsPercentageArray);

//     return { success: true, message: "Prizes distributed successfully." };
//   } catch (error) {
//     console.error("Error while fetching data from the API:", error);
//     return { success: false, message: "An error occurred while fetching data from the API." };
//   }
// }




// async function allUpdatePrize(scratchCardId) {
//   const assignedPrizes = [];

//   const scratchPlayData = await db.scratchCardPlay.findAll({
//     where: { scratchCardId },
//   });

//   if (scratchPlayData.length > 0) {
//     try {
//       const apiResponse = await axios.get(
//         `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
//       );
//       const apiRandomNumber = apiResponse.data.data;

//       const matchedRandomNumbers = apiRandomNumber.filter(
//         (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ''
//       );

//       if (matchedRandomNumbers.length > 0) {
//         const scratchCardWins = await db.scratchCardWin.findAll({
//           where: { scratchCardId },
//         });


//         let scratchCardWinCount = scratchCardWins.length;

//         for (let i = 0; i < scratchCardWins.length; i++) {
//           const scratchCardWin = scratchCardWins[i];
//           const oddsOfPrice = parseFloat(matchedRandomNumbers[i % matchedRandomNumbers.length].odds_of_price);
//           const price = matchedRandomNumbers[i % matchedRandomNumbers.length].price;

//           const remainingPrizes = Math.min(Math.floor(oddsOfPrice / 100 * scratchCardWins.length), scratchCardWins.length);
//           for (let j = 0; j < remainingPrizes; j++) {
//             assignedPrizes.push(price);
//           }

//           scratchCardWinCount -= remainingPrizes;
//         }

//         shuffleArray(assignedPrizes);
//         // console.log(assignedPrizes, 'assignedPrizes')
//         for (let i = 0; i < scratchCardWins.length && i < assignedPrizes.length; i++) {
//           const scratchCardWin = scratchCardWins[i];
//           const assignedPrize = assignedPrizes[i];
//           await scratchCardWin.update({ prize: assignedPrize, status: 0 });
//         }

//         await db.scratchCardWin.update(
//           { dailyStatus: Sequelize.literal('dailyStatus + 1'), rescheduleTime: Sequelize.literal('rescheduleTime + 1') },
//           { where: { scratchCardId } }
//         );

//         return { success: true, message: 'Prizes distributed successfully.' };
//       }
//     } catch (error) {
//       console.error('Error while fetching data from the API:', error);
//     }
//   }
//   return { success: false, message: 'No match found.' };
// }


async function allUpdatePrize(scratchCardId) {
  const assignedPrizes = [];

  const scratchPlayData = await db.scratchCardPlay.findAll({
    where: { scratchCardId },
  });

  if (scratchPlayData.length > 0) {
    try {
      const apiResponse = await axios.get(
        `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
      );
      const apiRandomNumber = apiResponse.data.data;

      const matchedRandomNumbers = apiRandomNumber.filter(
        (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ''
      );

      if (matchedRandomNumbers.length > 0) {
        const scratchCardWins = await db.scratchCardWin.findAll({
          where: { scratchCardId },
        });

        const totalPrizes = scratchCardWins.length;
        console.log(totalPrizes, 'totalPrizes')
        let oddsSum = 0;

        for (let i = 0; i < matchedRandomNumbers.length; i++) {
          const matchedRandomNumber = matchedRandomNumbers[i];
          const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
          oddsSum += oddsOfPrice;

          const timeToDistribute = (scratchCardWins.length) * (oddsOfPrice) / 100;
          const assignedPrize = matchedRandomNumber.price;
          const distributedCount = Math.round(timeToDistribute);

          console.log(`Time to distribute for oddsOfPrice ${oddsOfPrice} (${assignedPrize}): ${distributedCount} ----------${timeToDistribute}`);

          for (let j = 0; j < distributedCount; j++) {
            assignedPrizes.push(assignedPrize);
          }
        }

        shuffleArray(assignedPrizes);

        for (let i = 0; i < scratchCardWins.length && i < assignedPrizes.length; i++) {
          const scratchCardWin = scratchCardWins[i];
          const assignedPrize = assignedPrizes[i];

          await scratchCardWin.update({ prize: assignedPrize });
        }

        await db.scratchCardWin.update(
          { rescheduleTime: Sequelize.literal('rescheduleTime + 1') },
          { where: { scratchCardId } }
        );

        console.log("Assigned Prizes:", assignedPrizes);
        return { success: true, message: 'Prizes distributed successfully.' };
      }
    } catch (error) {
      console.error('Error while fetching data from the API:', error);
    }
  }

  return { success: false, message: 'No match found.' };
}




function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}


async function processScratchCard(scratchCardId, userId) {
  console.log(scratchCardId);
  console.log(userId);
  const plays = await db.scratchCardPlay.findOne({
    where: {
      scratchCardId: scratchCardId,
      UserId: userId
    }
  });
  const numbersArray = plays.scratchCards;

  const arr1 = numbersArray.split(',').map(String);
  console.log(arr1, "arr1");

  let arr2 = [];
  const wins = await db.scratchCardWin.findAll({
    where: {
      scratchCardId: scratchCardId,
      UserId: userId,
      dailyStatus: 1
    }
  });
  for (const win of wins) {
    arr2.push(win.scratchCards);
  }
  console.log(arr2, " arr2 wins with dailystatus 1")

  const winsD = await db.scratchCardWin.findAll({
    where: {
      scratchCardId: scratchCardId,
      UserId: userId,
      dailyStatus: 0
    }
  });
  await Promise.all(winsD.map(async (win) => {
    await win.destroy();
  }));

  const lossD = await db.scratchCardLoss.findAll({
    where: {
      scratchCardId: scratchCardId,
      UserId: userId,
      dailyStatus: 0
    }
  });
  await Promise.all(lossD.map(async (win) => {
    await win.destroy();
  }));

  const losses = await db.scratchCardLoss.findAll({
    where: {
      scratchCardId: scratchCardId,
      UserId: userId,
      dailyStatus: 1
    }
  });
  const arr3 = losses.map(loss => loss.scratchCards);

  console.log(arr3, " arr3 losses with dailystatus 1")


  const arr4 = [...arr1, ...arr2, ...arr3];

  const arr5 = arr4.join(',').split(',');

  console.log(arr5, "all arr1 arr2 arr3 ")

  const scratchCardData = await db.scratchCard.findOne({
    where: {
      id: scratchCardId
    }
  });

  const oddsOfWin = scratchCardData.odds_of_win;

  function getPercentageArray(arr5, oddsOfWin) {
    const elementsNeeded = Math.ceil((oddsOfWin / 100) * arr5.length);
    // console.log(elementsNeeded, "elementsNeeded")
    const resultArray = arr5.slice(0, elementsNeeded);
    const remainingArray = arr5.slice(elementsNeeded);

    return {
      resultArray,
      remainingArray
    };
  }
  const result = getPercentageArray(arr5, oddsOfWin);

  const winArray = result.resultArray;
  console.log(winArray, 'winArray');
  const lossArray = result.remainingArray;
  console.log(lossArray, 'lossArray');

  const winsW = await db.scratchCardWin.findAll({
    where: {
      scratchCardId: scratchCardId,
      UserId: userId,
      dailyStatus: 1
    }
  });
  await Promise.all(winsW.map(async (win) => {
    await win.destroy();
  }));

  const lossL = await db.scratchCardLoss.findAll({
    where: {
      scratchCardId: scratchCardId,
      UserId: userId,
      dailyStatus: 1
    }
  });
  await Promise.all(lossL.map(async (win) => {
    await win.destroy();
  }));

  await Promise.all(winArray.map(async scratchCard => {
    await db.scratchCardWin.create({
      scratchCards: scratchCard,
      dailyStatus: 1,
      scratchCardId,
      UserId: userId
    });
  }));

  await Promise.all(lossArray.map(async scratchCard => {
    await db.scratchCardLoss.create({
      scratchCards: scratchCard,
      dailyStatus: 1,
      scratchCardId,
      UserId: userId
    });
  }));
}


module.exports = { allUpdatePrize, userUpdatePrize, processScratchCard };



// 17-07-2023------------------------


async function userUpdatePrize(scratchCardId, userId) {
  const scratchPlayData = await db.scratchCardPlay.findAll({
    where: { scratchCardId },
  });

  if (scratchPlayData.length > 0) {
    try {
      const apiResponse = await axios.get(
        `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
      );

      const apiRandomNumber = apiResponse.data.data;
      const matchedRandomNumbers = apiRandomNumber.filter(
        (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== undefined && item.price !== ""
      );

      if (matchedRandomNumbers.length > 0) {
        const scratchCardWins = await db.scratchCardWin.findAll({
          where: {
            scratchCardId,
            userId,
            dailyStatus: 1,
          },
        });

        const totalPrizes = scratchCardWins.length;
        console.log(totalPrizes, "totalPrizes");
        let oddsSum = 0;
        const assignedPrizes = [];
        const assignedRandomRNGs = [];

        for (let i = 0; i < matchedRandomNumbers.length; i++) {
          const matchedRandomNumber = matchedRandomNumbers[i];
          const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
          oddsSum += oddsOfPrice;

          const timeToDistribute = (scratchCardWins.length * oddsOfPrice) / 100;
          const assignedPrize = matchedRandomNumber.price;
          const distributedCount = Math.round(timeToDistribute);

          console.log(`Time to distribute for oddsOfPrice ${oddsOfPrice} (${assignedPrize}): ${distributedCount}---user-------${timeToDistribute}`);

          for (let j = 0; j < distributedCount; j++) {
            assignedPrizes.push(assignedPrize);
          }
        }

        for (let i = 0; i < totalPrizes; i++) {
          const randomNumber = generateUniqueRandomNumberInRange(apiRandomNumber);
          assignedRandomRNGs.push(randomNumber);
        }

        for (let i = 0; i < scratchCardWins.length && i < assignedPrizes.length && i < assignedRandomRNGs.length; i++) {
          const scratchCardWin = scratchCardWins[i];
          const assignedPrize = assignedPrizes[i];
          const assignedRandomRNG = assignedRandomRNGs[i];

          await scratchCardWin.update({ prize: assignedPrize, randomRNG: assignedRandomRNG, status: 0 });
        }

        console.log("Assigned Prizes:", assignedPrizes);
        console.log("Assigned RandomRNGs:", assignedRandomRNGs);
        return { success: true, message: "Prizes distributed successfully." };
      }
    } catch (error) {
      console.error("Error while fetching data from the API:", error);
    }
  }

  return { success: false, message: "No match found." };
}

function generateUniqueRandomNumberInRange(apiRandomNumbers) {
  const randomNumberSet = new Set();
  let randomNumber;

  while (true) {
    const randomIndex = Math.floor(Math.random() * apiRandomNumbers.length);
    const range = apiRandomNumbers[randomIndex].rng;
    randomNumber = generateRandomNumberInRange(range);

    if (!randomNumberSet.has(randomNumber)) {
      randomNumberSet.add(randomNumber);
      break;
    }
  }

  return randomNumber;
}

function generateRandomNumberInRange(range) {
  const [min, max] = range.split("-").map(Number);
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

//18 Morning-------------

async function userUpdatePrize(scratchCardId, userId) {
  const scratchPlayData = await db.scratchCardPlay.findAll({
    where: { scratchCardId },
  });

  if (scratchPlayData.length > 0) {
    try {
      const apiResponse = await axios.get(
        `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
      );

      const apiRandomNumbers = apiResponse.data.data;
      const matchedRandomNumbers = apiRandomNumbers.filter(
        (item) =>
          parseFloat(item.odds_of_price) !== 0 &&
          item.price !== undefined &&
          item.price !== ""
      );

      if (matchedRandomNumbers.length > 0) {
        const scratchCardWins = await db.scratchCardWin.findAll({
          where: {
            scratchCardId,
            userId,
            dailyStatus: 1,
          },
        });

        const assignedPrizes = [];
        const assignedRandomRNGs = [];

        for (const matchedRandomNumber of matchedRandomNumbers) {
          const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
          const assignedPrize = matchedRandomNumber.price;

          const distributedCount = Math.round(
            (scratchCardWins.length * oddsOfPrice) / 100
          );

          for (let i = 0; i < distributedCount; i++) {
            assignedPrizes.push(assignedPrize);

            const [min, max] = matchedRandomNumber.rng.split("-").map(Number);
            const assignedRandomRNG = generateRandomNumberInRange(min, max);
            assignedRandomRNGs.push(assignedRandomRNG);
          }
        }

        for (let i = 0; i < Math.min(scratchCardWins.length, assignedPrizes.length, assignedRandomRNGs.length); i++) {
          const scratchCardWin = scratchCardWins[i];
          const assignedPrize = assignedPrizes[i];
          const assignedRandomRNG = assignedRandomRNGs[i];

          await scratchCardWin.update({
            prize: assignedPrize,
            randomRNG: assignedRandomRNG,
            status: 0,
          });
        }

        console.log("Assigned Prizes:", assignedPrizes);
        console.log("Assigned RandomRNGs:", assignedRandomRNGs);
        return { success: true, message: "Prizes distributed successfully." };
      }
    } catch (error) {
      console.error("Error while fetching data from the API:", error);
    }
  }

  return { success: false, message: "No match found." };
}

function generateRandomNumberInRange(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

async function userUpdatePrize(scratchCardId, userId) {
  const scratchPlayData = await db.scratchCardPlay.findAll({
    where: { scratchCardId },
  });

  if (scratchPlayData.length > 0) {
    try {
      const apiResponse = await axios.get(
        `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
      );

      const apiRandomNumbers = apiResponse.data.data;
      const matchedRandomNumbers = apiRandomNumbers.filter(
        (item) =>
          parseFloat(item.odds_of_price) !== 0 &&
          item.price !== undefined &&
          item.price !== ""
      );

      if (matchedRandomNumbers.length > 0) {
        const scratchCardWins = await db.scratchCardWin.findAll({
          where: {
            scratchCardId,
            userId,
            dailyStatus: 1,
          },
        });

        const assignedPrizes = [];
        const assignedRandomRNGs = [];
        const totalPrizes = scratchCardWins.length;

        let oddsSum = 0;
        for (const matchedRandomNumber of matchedRandomNumbers) {
          const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
          oddsSum += oddsOfPrice;
        }

        for (const matchedRandomNumber of matchedRandomNumbers) {
          const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
          const assignedPrize = matchedRandomNumber.price;

          const timeToDistribute = (totalPrizes * oddsOfPrice) / 100;
          const distributedCount = Math.round(timeToDistribute);

          console.log(`Time to distribute for oddsOfPrice ${oddsOfPrice} (${assignedPrize}): ${distributedCount}---user-------${timeToDistribute}`);


          for (let i = 0; i < distributedCount; i++) {
            assignedPrizes.push(assignedPrize);

            const [min, max] = matchedRandomNumber.rng.split("-").map(Number);
            const assignedRandomRNG = generateRandomNumberInRange(min, max);
            assignedRandomRNGs.push(assignedRandomRNG);
          }
        }

        while (assignedPrizes.length < totalPrizes) {
          const remainingCount = totalPrizes - assignedPrizes.length;
          const remainingPrizes = matchedRandomNumbers.filter(
            (item) =>
              parseFloat(item.odds_of_price) !== 0 &&
              item.price !== undefined &&
              item.price !== "" &&
              !assignedPrizes.includes(item.price)
          );

          remainingPrizes.sort((a, b) => {
            const diffA = Math.abs(
              0.5 - ((totalPrizes * parseFloat(a.odds_of_price)) / (100 * oddsSum))
            );
            const diffB = Math.abs(
              0.5 - ((totalPrizes * parseFloat(b.odds_of_price)) / (100 * oddsSum))
            );
            return diffA - diffB;
          });

          for (let i = 0; i < remainingCount && i < remainingPrizes.length; i++) {
            const remainingPrize = remainingPrizes[i].price;
            assignedPrizes.push(remainingPrize);

            const [min, max] = remainingPrizes[i].rng.split("-").map(Number);
            const assignedRandomRNG = generateRandomNumberInRange(min, max);
            assignedRandomRNGs.push(assignedRandomRNG);
          }
        }

        for (let i = 0; i < totalPrizes && i < assignedPrizes.length && i < assignedRandomRNGs.length; i++) {
          const scratchCardWin = scratchCardWins[i];
          const assignedPrize = assignedPrizes[i];
          const assignedRandomRNG = assignedRandomRNGs[i];

          await scratchCardWin.update({ prize: assignedPrize, randomRNG: assignedRandomRNG, status: 0 });
        }

        console.log("Assigned Prizes:", assignedPrizes);
        console.log("Assigned RandomRNGs:", assignedRandomRNGs);
        return { success: true, message: "Prizes distributed successfully." };
      }
    } catch (error) {
      console.error("Error while fetching data from the API:", error);
    }
  }

  return { success: false, message: "No match found." };
}

function generateRandomNumberInRange(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}





//done ----------------------
async function userUpdatePrize(scratchCardId, userId) {
  const scratchPlayData = await db.scratchCardPlay.findAll({
    where: { scratchCardId },
  });

  if (scratchPlayData.length > 0) {
    try {
      const apiResponse = await axios.get(
        `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
      );

      const apiRandomNumber = apiResponse.data.data;
      const matchedRandomNumbers = apiRandomNumber.filter(
        (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ""
      );

      if (matchedRandomNumbers.length > 0) {
        const scratchCardWins = await db.scratchCardWin.findAll({
          where: {
            scratchCardId,
            userId,
            dailyStatus: 1,
          },
        });

        const assignedPrizes = [];
        const assignedRNGs = []; // Array to store the corresponding RNG values
        const totalPrizes = scratchCardWins.length;
        console.log(totalPrizes, "totalPrizes");
        let oddsSum = 0;

        for (let i = 0; i < matchedRandomNumbers.length; i++) {
          const matchedRandomNumber = matchedRandomNumbers[i];
          const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
          oddsSum += oddsOfPrice;

          const timeToDistribute = scratchCardWins.length * oddsOfPrice / 100;
          const assignedPrize = matchedRandomNumber.price;
          const distributedCount = Math.round(timeToDistribute);

          console.log(`Time to distribute for oddsOfPrice ${oddsOfPrice} (${assignedPrize}): ${distributedCount}---user-------${timeToDistribute}`);

          for (let j = 0; j < distributedCount; j++) {
            assignedPrizes.push(assignedPrize);
            assignedRNGs.push(getRandomNumberInRange(assignedPrize)); // Store the randomly generated value within the range
          }
        }
        while (assignedPrizes.length < totalPrizes) {
          const remainingCount = totalPrizes - assignedPrizes.length;
          const remainingPrizes = matchedRandomNumbers.filter(
            (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== '' && !assignedPrizes.includes(item.price)
          );

          remainingPrizes.sort((a, b) => {
            const diffA = Math.abs(0.5 - ((scratchCardWins.length * parseFloat(a.odds_of_price)) / (100 * oddsSum)));
            const diffB = Math.abs(0.5 - ((scratchCardWins.length * parseFloat(b.odds_of_price)) / (100 * oddsSum)));
            return diffA - diffB;
          });

          for (let i = 0; i < remainingCount; i++) {
            const remainingPrize = remainingPrizes[i].price;
            assignedPrizes.push(remainingPrize);
            assignedRNGs.push(getRandomNumberInRange(remainingPrize)); // Store the randomly generated value within the range
          }
        }

        for (let i = 0; i < scratchCardWins.length && i < assignedPrizes.length; i++) {
          const scratchCardWin = scratchCardWins[i];
          const assignedPrize = assignedPrizes[i];
          const assignedRNG = assignedRNGs[i]; // Get the corresponding RNG value

          await scratchCardWin.update({ prize: assignedPrize, status: 0 });

          // Update the randomRNG field in the scratchCardWin model with the corresponding RNG value
          await scratchCardWin.update({ randomRNG: assignedRNG });
        }
        console.log(assignedRNGs, "assignedRNG");
        console.log("Assigned Prizes:", assignedPrizes);
        return { success: true, message: "Prizes distributed successfully." };
      }
    } catch (error) {
      console.error("Error while fetching data from the API:", error);
    }
  }

  return { success: false, message: "No match found." };
}

const getRandomNumberInRange = (range) => {
  const [min, max] = range.split('-').map(Number);
  return Math.floor(Math.random() * (max - min + 1)) + min;
};

//-----------------------------without RNG

async function allUpdatePrize(scratchCardId) {
  const assignedPrizes = [];

  const scratchPlayData = await db.scratchCardPlay.findAll({
    where: { scratchCardId },
  });

  if (scratchPlayData.length > 0) {
    try {
      const apiResponse = await axios.get(
        `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
      );
      const apiRandomNumber = apiResponse.data.data;

      const matchedRandomNumbers = apiRandomNumber.filter(
        (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ''
      );

      if (matchedRandomNumbers.length > 0) {
        const scratchCardWins = await db.scratchCardWin.findAll({
          where: { scratchCardId },
        });

        const totalPrizes = scratchCardWins.length;
        console.log(totalPrizes, 'totalPrizes');
        let oddsSum = 0;

        for (let i = 0; i < matchedRandomNumbers.length; i++) {
          const matchedRandomNumber = matchedRandomNumbers[i];
          const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
          oddsSum += oddsOfPrice;

          let timeToDistribute = (scratchCardWins.length * oddsOfPrice) / 100;
          const assignedPrize = matchedRandomNumber.price;
          let distributedCount = Math.round(timeToDistribute);

          if (assignedPrizes.length + distributedCount > totalPrizes) {
            distributedCount = totalPrizes - assignedPrizes.length;
          }

          console.log(`Time to distribute for oddsOfPrice ${oddsOfPrice} (${assignedPrize}): ${distributedCount}----all------${timeToDistribute}`);

          for (let j = 0; j < distributedCount; j++) {
            assignedPrizes.push(assignedPrize);
          }
        }

        shuffleArray(assignedPrizes);

        // Add remaining prizes closest to 0.5 timeToDistribute
        while (assignedPrizes.length < totalPrizes) {
          const remainingCount = totalPrizes - assignedPrizes.length;
          const remainingPrizes = matchedRandomNumbers.filter(
            (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== '' && !assignedPrizes.includes(item.price)
          );

          remainingPrizes.sort((a, b) => {
            const diffA = Math.abs(0.5 - ((scratchCardWins.length * parseFloat(a.odds_of_price)) / (100 * oddsSum)));
            const diffB = Math.abs(0.5 - ((scratchCardWins.length * parseFloat(b.odds_of_price)) / (100 * oddsSum)));
            return diffA - diffB;
          });

          for (let i = 0; i < remainingCount; i++) {
            assignedPrizes.push(remainingPrizes[i].price);
          }
        }

        for (let i = 0; i < scratchCardWins.length && i < assignedPrizes.length; i++) {
          const scratchCardWin = scratchCardWins[i];
          const assignedPrize = assignedPrizes[i];

          await scratchCardWin.update({
            prize: assignedPrize, status: 0
          });
        }
        await db.scratchCardPlay.update(
          { rescheduleTime: Sequelize.literal('rescheduleTime + 1') },
          { where: { scratchCardId } },
        );

        console.log("Assigned Prizes:", assignedPrizes);
        return { success: true, message: 'Prizes distributed successfully.' };
      }
    } catch (error) {
      console.error('Error while fetching data from the API:', error);
    }
  }

  return { success: false, message: 'No match found.' };
}


async function userUpdatePrize(scratchCardId, userId) {
  const scratchPlayData = await db.scratchCardPlay.findAll({
    where: { scratchCardId },
  });

  if (scratchPlayData.length > 0) {
    try {
      const apiResponse = await axios.get(
        `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
      );

      const apiRandomNumber = apiResponse.data.data;
      const matchedRandomNumbers = apiRandomNumber.filter(
        (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ""
      );

      if (matchedRandomNumbers.length > 0) {
        const scratchCardWins = await db.scratchCardWin.findAll({
          where: {
            scratchCardId, userId,
            dailyStatus: 1
          },
        });

        const assignedPrizes = [];
        const totalPrizes = scratchCardWins.length;
        console.log(totalPrizes, "totalPrizes");
        let oddsSum = 0;

        for (let i = 0; i < matchedRandomNumbers.length; i++) {
          const matchedRandomNumber = matchedRandomNumbers[i];
          const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
          oddsSum += oddsOfPrice;

          const timeToDistribute = (scratchCardWins.length) * (oddsOfPrice) / 100;
          const assignedPrize = matchedRandomNumber.price;
          const distributedCount = Math.round(timeToDistribute);

          console.log(`Time to distribute for oddsOfPrice ${oddsOfPrice} (${assignedPrize}): ${distributedCount}---user-------${timeToDistribute}`);

          for (let j = 0; j < distributedCount; j++) {
            assignedPrizes.push(assignedPrize);
          }
        }
        while (assignedPrizes.length < totalPrizes) {
          const remainingCount = totalPrizes - assignedPrizes.length;
          const remainingPrizes = matchedRandomNumbers.filter(
            (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== '' && !assignedPrizes.includes(item.price)
          );

          remainingPrizes.sort((a, b) => {
            const diffA = Math.abs(0.5 - ((scratchCardWins.length * parseFloat(a.odds_of_price)) / (100 * oddsSum)));
            const diffB = Math.abs(0.5 - ((scratchCardWins.length * parseFloat(b.odds_of_price)) / (100 * oddsSum)));
            return diffA - diffB;
          });

          for (let i = 0; i < remainingCount; i++) {
            assignedPrizes.push(remainingPrizes[i].price);
          }
        }

        for (let i = 0; i < scratchCardWins.length && i < assignedPrizes.length; i++) {
          const scratchCardWin = scratchCardWins[i];
          const assignedPrize = assignedPrizes[i];

          await scratchCardWin.update({ prize: assignedPrize, status: 0 });
        }
        console.log("Assigned Prizes:", assignedPrizes);
        return { success: true, message: "Prizes distributed successfully." };
      }
    } catch (error) {
      console.error("Error while fetching data from the API:", error);
    }
  }

  return { success: false, message: "No match found." };
}

//-----------------------Test 
// async function allUpdatePrize(scratchCardId) {
//   const assignedPrizes = [];

//   const scratchPlayData = await db.scratchCardPlay.findAll({
//     where: { scratchCardId },
//   });

//   if (scratchPlayData.length > 0) {
//     try {
//       const apiResponse = await axios.get(
//         `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
//       );
//       const apiRandomNumber = apiResponse.data.data;

//       const matchedRandomNumbers = apiRandomNumber.filter(
//         (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ''
//       );

//       if (matchedRandomNumbers.length > 0) {
//         const scratchCardWins = await db.scratchCardWin.findAll({
//           where: { scratchCardId },
//         });


//         let scratchCardWinCount = scratchCardWins.length;

//         for (let i = 0; i < scratchCardWins.length; i++) {
//           const scratchCardWin = scratchCardWins[i];
//           const oddsOfPrice = parseFloat(matchedRandomNumbers[i % matchedRandomNumbers.length].odds_of_price);
//           const price = matchedRandomNumbers[i % matchedRandomNumbers.length].price;

//           const remainingPrizes = Math.min(Math.floor(oddsOfPrice / 100 * scratchCardWins.length), scratchCardWins.length);
//           for (let j = 0; j < remainingPrizes; j++) {
//             assignedPrizes.push(price);
//           }

//           scratchCardWinCount -= remainingPrizes;
//         }

//         shuffleArray(assignedPrizes);
//         // console.log(assignedPrizes, 'assignedPrizes')
//         for (let i = 0; i < scratchCardWins.length && i < assignedPrizes.length; i++) {
//           const scratchCardWin = scratchCardWins[i];
//           const assignedPrize = assignedPrizes[i];
//           await scratchCardWin.update({ prize: assignedPrize, status: 0 });
//         }

//         await db.scratchCardWin.update(
//           { dailyStatus: Sequelize.literal('dailyStatus + 1'), rescheduleTime: Sequelize.literal('rescheduleTime + 1') },
//           { where: { scratchCardId } }
//         );

//         return { success: true, message: 'Prizes distributed successfully.' };
//       }
//     } catch (error) {
//       console.error('Error while fetching data from the API:', error);
//     }
//   }
//   return { success: false, message: 'No match found.' };
// }



// async function userUpdatePrize(scratchCardId, userId) {
//   const scratchPlayData = await db.scratchCardPlay.findAll({
//     where: { scratchCardId },
//   });

//   if (scratchPlayData.length > 0) {
//     try {
//       const apiResponse = await axios.get(
//         `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
//       );

//       const apiRandomNumber = apiResponse.data.data;
//       const matchedRandomNumbers = apiRandomNumber.filter(
//         (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ""
//       );

//       if (matchedRandomNumbers.length > 0) {
//         const scratchCardWins = await db.scratchCardWin.findAll({
//           where: { scratchCardId, userId },
//         });

//         const assignedPrizes = [];
//         const totalPrizes = scratchCardWins.length;

//         const oddsPercentageArray = [];
//         let oddsSum = 0;

//         for (let i = 0; i < matchedRandomNumbers.length; i++) {
//           const matchedRandomNumber = matchedRandomNumbers[i];
//           const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
//           oddsSum += oddsOfPrice;
//         }

//         for (let i = 0; i < matchedRandomNumbers.length; i++) {
//           const matchedRandomNumber = matchedRandomNumbers[i];
//           const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
//           const oddsPercentage = (oddsOfPrice / oddsSum) * 100;
//           oddsPercentageArray.push(oddsPercentage);
//         }

//         for (let i = 0; i < totalPrizes; i++) {
//           let randomValue = Math.random() * 100;

//           for (let j = 0; j < matchedRandomNumbers.length; j++) {
//             const matchedRandomNumber = matchedRandomNumbers[j];
//             const assignedPrize = matchedRandomNumber.price;
//             const oddsPercentage = oddsPercentageArray[j];

//             if (randomValue < oddsPercentage) {
//               const scratchCardWin = scratchCardWins[i];
//               await scratchCardWin.update({ prize: assignedPrize, status: 0 });
//               assignedPrizes.push(assignedPrize);
//               break;
//             }

//             randomValue -= oddsPercentage;
//           }
//         }

//         console.log("Assigned Prizes:", assignedPrizes);
//         console.log("Odds of Price Percentage:", oddsPercentageArray);

//         return { success: true, message: "Prizes distributed successfully." };
//       }
//     } catch (error) {
//       console.error("Error while fetching data from the API:", error);
//     }
//   }

//   return { success: false, message: "No match found." };
// }

// async function userUpdatePrize(scratchCardId, userId) {
//   const scratchPlayData = await db.scratchCardPlay.findAll({
//     where: { scratchCardId },
//   });

//   if (scratchPlayData.length > 0) {
//     try {
//       const apiResponse = await axios.get(
//         `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
//       );

//       const apiRandomNumbers = apiResponse.data.data;
//       const matchedRandomNumbers = apiRandomNumbers.filter(
//         (item) =>
//           parseFloat(item.odds_of_price) !== 0 &&
//           item.price !== undefined &&
//           item.price !== ""
//       );

//       if (matchedRandomNumbers.length > 0) {
//         const scratchCardWins = await db.scratchCardWin.findAll({
//           where: {
//             scratchCardId,
//             userId,
//             dailyStatus: 1,
//           },
//         });

//         const assignedPrizes = [];
//         const assignedRandomRNGs = [];

//         for (const matchedRandomNumber of matchedRandomNumbers) {
//           const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
//           const assignedPrize = matchedRandomNumber.price;

//           const distributedCount = Math.round(
//             (scratchCardWins.length * oddsOfPrice) / 100
//           );

//           for (let i = 0; i < distributedCount; i++) {
//             assignedPrizes.push(assignedPrize);

//             const [min, max] = matchedRandomNumber.rng.split("-").map(Number);
//             const assignedRandomRNG = generateRandomNumberInRange(min, max);
//             assignedRandomRNGs.push(assignedRandomRNG);
//           }
//         }

//         const remainingCount = Math.max(
//           0,
//           scratchCardWins.length - assignedPrizes.length
//         );

//         if (remainingCount > 0) {
//           const remainingPrizes = matchedRandomNumbers
//             .filter(
//               (item) =>
//                 parseFloat(item.odds_of_price) !== 0 &&
//                 item.price !== undefined &&
//                 item.price !== "" &&
//                 !assignedPrizes.includes(item.price)
//             )
//             .map((item) => item.price);

//           for (let i = 0; i < remainingCount; i++) {
//             const assignedPrize =
//               remainingPrizes[i % remainingPrizes.length];

//             assignedPrizes.push(assignedPrize);

//             const randomIndex = Math.floor(
//               Math.random() * apiRandomNumbers.length
//             );
//             const range = apiRandomNumbers[randomIndex].rng;
//             const [min, max] = range.split("-").map(Number);
//             const assignedRandomRNG = generateRandomNumberInRange(min, max);
//             assignedRandomRNGs.push(assignedRandomRNG);
//           }
//         }

//         for (
//           let i = 0;
//           i <
//           Math.min(
//             scratchCardWins.length,
//             assignedPrizes.length,
//             assignedRandomRNGs.length
//           );
//           i++
//         ) {
//           const scratchCardWin = scratchCardWins[i];
//           const assignedPrize = assignedPrizes[i];
//           const assignedRandomRNG = assignedRandomRNGs[i];

//           await scratchCardWin.update({
//             prize: assignedPrize,
//             randomRNG: assignedRandomRNG,
//             status: 0,
//           });
//         }

//         console.log("Assigned Prizes:", assignedPrizes);
//         console.log("Assigned RandomRNGs:", assignedRandomRNGs);
//         return { success: true, message: "Prizes distributed successfully." };
//       }
//     } catch (error) {
//       console.error("Error while fetching data from the API:", error);
//     }
//   }

//   return { success: false, message: "No match found." };
// }

// function generateRandomNumberInRange(min, max) {
//   return Math.floor(Math.random() * (max - min + 1)) + min;
// }



// async function userUpdatePrize(scratchCardId, userId) {
//   const scratchPlayData = await db.scratchCardPlay.findAll({
//     where: { scratchCardId },
//   });

//   if (scratchPlayData.length > 0) {
//     try {
//       const apiResponse = await axios.get(
//         `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
//       );

//       const apiRandomNumbers = apiResponse.data.data;
//       const matchedRandomNumbers = apiRandomNumbers.filter(
//         (item) =>
//           parseFloat(item.odds_of_price) !== 0 &&
//           item.price !== undefined &&
//           item.price !== ""
//       );

//       if (matchedRandomNumbers.length > 0) {
//         const scratchCardWins = await db.scratchCardWin.findAll({
//           where: {
//             scratchCardId,
//             userId,
//             dailyStatus: 1,
//           },
//         });

//         const assignedPrizes = [];
//         const totalPrizes = scratchCardWins.length;
//         console.log(totalPrizes, "totalPrizes");
//         let oddsSum = 0;

//         for (let i = 0; i < matchedRandomNumbers.length; i++) {
//           const matchedRandomNumber = matchedRandomNumbers[i];
//           const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
//           oddsSum += oddsOfPrice;

//           const timeToDistribute = (scratchCardWins.length * oddsOfPrice) / 100;
//           const assignedPrize = matchedRandomNumber.price;
//           const distributedCount = Math.round(timeToDistribute);

//           console.log(`Time to distribute for oddsOfPrice ${oddsOfPrice} (${assignedPrize}): ${distributedCount}---user-------${timeToDistribute}`);

//           for (let j = 0; j < distributedCount; j++) {
//             assignedPrizes.push(assignedPrize);
//           }
//         }

//         while (assignedPrizes.length < totalPrizes) {
//           const remainingCount = totalPrizes - assignedPrizes.length;
//           const remainingPrizes = matchedRandomNumbers.filter(
//             (item) =>
//               parseFloat(item.odds_of_price) !== 0 &&
//               item.price !== "" &&
//               !assignedPrizes.includes(item.price)
//           );

//           remainingPrizes.sort((a, b) => {
//             const diffA = Math.abs(
//               0.5 -
//               ((scratchCardWins.length * parseFloat(a.odds_of_price)) /
//                 (100 * oddsSum))
//             );
//             const diffB = Math.abs(
//               0.5 -
//               ((scratchCardWins.length * parseFloat(b.odds_of_price)) /
//                 (100 * oddsSum))
//             );
//             return diffA - diffB;
//           });

//           for (let i = 0; i < remainingCount; i++) {
//             assignedPrizes.push(remainingPrizes[i].price);
//           }
//         }

//         const assignedRandomRNGs = generateUniqueRandomNumbersInRange(
//           totalPrizes,
//           apiRandomNumbers
//         );

//         for (
//           let i = 0;
//           i <
//           Math.min(
//             scratchCardWins.length,
//             assignedPrizes.length,
//             assignedRandomRNGs.length
//           );
//           i++
//         ) {
//           const scratchCardWin = scratchCardWins[i];
//           const assignedPrize = assignedPrizes[i];
//           const assignedRandomRNG = assignedRandomRNGs[i];

//           await scratchCardWin.update({
//             prize: assignedPrize,
//             randomRNG: assignedRandomRNG,
//             status: 0,
//           });
//         }

//         console.log("Assigned Prizes:", assignedPrizes);
//         console.log("Assigned RandomRNGs:", assignedRandomRNGs);
//         return { success: true, message: "Prizes distributed successfully." };
//       }
//     } catch (error) {
//       console.error("Error while fetching data from the API:", error);
//     }
//   }

//   return { success: false, message: "No match found." };
// }

// // function generateUniqueRandomNumbersInRange(count, apiRandomNumbers) {
// //   const randomRNGs = [];
// //   const usedNumbers = new Set();

// //   while (randomRNGs.length < count) {
// //     const randomIndex = Math.floor(Math.random() * apiRandomNumbers.length);
// //     const range = apiRandomNumbers[randomIndex].rng;
// //     const [min, max] = range.split("-").map(Number);
// //     const randomNumber = generateRandomNumberInRange(min, max);

// //     if (!usedNumbers.has(randomNumber)) {
// //       usedNumbers.add(randomNumber);
// //       randomRNGs.push(randomNumber);
// //     }
// //   }

// //   return randomRNGs;
// // }


// function generateRandomNumberInRange(min, max) {
//   return Math.floor(Math.random() * (max - min + 1)) + min;
// }



// async function userUpdatePrize(scratchCardId, userId) {
//   const scratchPlayData = await db.scratchCardPlay.findAll({
//     where: { scratchCardId },
//   });

//   if (scratchPlayData.length > 0) {
//     try {
//       const apiResponse = await axios.get(
//         `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
//       );

//       const apiRandomNumber = apiResponse.data.data;
//       const matchedRandomNumbers = apiRandomNumber.filter(
//         (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ""
//       );
//       console.log(matchedRandomNumbers, 'matchedRandomNumbers')
//       if (matchedRandomNumbers.length > 0) {
//         const scratchCardWins = await db.scratchCardWin.findAll({
//           where: {
//             scratchCardId,
//             userId,
//             dailyStatus: 1,
//           },
//         });

//         const assignedPrizes = [];
//         const totalPrizes = scratchCardWins.length;
//         console.log(totalPrizes, "totalPrizes");
//         let oddsSum = 0;

//         for (let i = 0; i < matchedRandomNumbers.length; i++) {
//           const matchedRandomNumber = matchedRandomNumbers[i];
//           const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
//           oddsSum += oddsOfPrice;

//           const timeToDistribute = (scratchCardWins.length * oddsOfPrice) / 100;
//           const assignedPrize = matchedRandomNumber.price;
//           const distributedCount = Math.round(timeToDistribute);

//           console.log(
//             `Time to distribute for oddsOfPrice ${oddsOfPrice} (${assignedPrize}): ${distributedCount}---user-------${timeToDistribute}`
//           );

//           for (let j = 0; j < distributedCount; j++) {
//             assignedPrizes.push(assignedPrize);
//           }
//         }

//         while (assignedPrizes.length < totalPrizes) {
//           const remainingCount = totalPrizes - assignedPrizes.length;
//           const remainingPrizes = matchedRandomNumbers.filter(
//             (item) =>
//               parseFloat(item.odds_of_price) !== 0 &&
//               item.price !== "" &&
//               !assignedPrizes.includes(item.price)
//           );

//           remainingPrizes.sort((a, b) => {
//             const diffA = Math.abs(
//               0.5 -
//               (scratchCardWins.length *
//                 parseFloat(a.odds_of_price)) /
//               (100 * oddsSum)
//             );
//             const diffB = Math.abs(
//               0.5 -
//               (scratchCardWins.length *
//                 parseFloat(b.odds_of_price)) /
//               (100 * oddsSum)
//             );
//             return diffA - diffB;
//           });

//           for (let i = 0; i < remainingCount; i++) {
//             assignedPrizes.push(remainingPrizes[i].price);
//           }
//         }

//         // New code to update randomRNG column
//         const prizeRNGMap = {};
//         for (let i = 0; i < scratchCardWins.length && i < assignedPrizes.length; i++) {
//           const scratchCardWin = scratchCardWins[i];
//           const assignedPrize = assignedPrizes[i];

//           if (!prizeRNGMap[assignedPrize]) {
//             const rngValue = getRandomRNGValue(); // Replace with your logic to generate a random RNG value
//             prizeRNGMap[assignedPrize] = rngValue;
//           }

//           const randomRNG = prizeRNGMap[assignedPrize];
//           await scratchCardWin.update({ prize: assignedPrize, status: 0, randomRNG });
//         }
//         console.log("Assigned Prizes:", assignedPrizes);
//         return { success: true, message: "Prizes distributed successfully." };
//       }
//     } catch (error) {
//       console.error("Error while fetching data from the API:", error);
//     }
//   }

//   return { success: false, message: "No match found." };
// }


// async function userUpdatePrize(scratchCardId, userId) {
//   const scratchPlayData = await db.scratchCardPlay.findAll({
//     where: { scratchCardId },
//   });

//   if (scratchPlayData.length > 0) {
//     try {
//       const apiResponse = await axios.get(
//         `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
//       );

//       const apiRandomNumber = apiResponse.data.data;
//       const matchedRandomNumbers = apiRandomNumber.filter(
//         (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ""
//       );

//       if (matchedRandomNumbers.length > 0) {
//         const scratchCardWins = await db.scratchCardWin.findAll({
//           where: {
//             scratchCardId,
//             userId,
//             dailyStatus: 1,
//           },
//         });

//         const assignedPrizes = [];
//         const assignedRNGs = []; // Array to store the corresponding RNG values
//         const totalPrizes = scratchCardWins.length;
//         console.log(totalPrizes, "totalPrizes");
//         let oddsSum = 0;

//         for (let i = 0; i < matchedRandomNumbers.length; i++) {
//           const matchedRandomNumber = matchedRandomNumbers[i];
//           const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
//           oddsSum += oddsOfPrice;

//           const timeToDistribute = scratchCardWins.length * oddsOfPrice / 100;
//           const assignedPrize = matchedRandomNumber.price;
//           const distributedCount = Math.round(timeToDistribute);

//           console.log(`Time to distribute for oddsOfPrice ${oddsOfPrice} (${assignedPrize}): ${distributedCount}---user-------${timeToDistribute}`);

//           // for (let j = 0; j < distributedCount; j++) {
//           //   assignedPrizes.push(assignedPrize);
//           //   assignedRNGs.push(matchedRandomNumber.rng); // Store the corresponding RNG value
//           // }
//           for (let j = 0; j < distributedCount; j++) {
//             assignedPrizes.push(assignedPrize);
//             assignedRNGs.push(getRandomNumberInRange(assignedPrize)); // Store the randomly generated value within the range
//           }
//         }
//         while (assignedPrizes.length < totalPrizes) {
//           const remainingCount = totalPrizes - assignedPrizes.length;
//           const remainingPrizes = matchedRandomNumbers.filter(
//             (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== '' && !assignedPrizes.includes(item.price)
//           );

//           remainingPrizes.sort((a, b) => {
//             const diffA = Math.abs(0.5 - ((scratchCardWins.length * parseFloat(a.odds_of_price)) / (100 * oddsSum)));
//             const diffB = Math.abs(0.5 - ((scratchCardWins.length * parseFloat(b.odds_of_price)) / (100 * oddsSum)));
//             return diffA - diffB;
//           });

//           // for (let i = 0; i < remainingCount; i++) {
//           //   assignedPrizes.push(remainingPrizes[i].price);
//           //   assignedRNGs.push(remainingPrizes[i].rng); // Store the corresponding RNG value
//           // }
//           for (let i = 0; i < remainingCount; i++) {
//             const remainingPrize = remainingPrizes[i].price;
//             assignedPrizes.push(remainingPrize);
//             assignedRNGs.push(getRandomNumberInRange(remainingPrize)); // Store the randomly generated value within the range
//           }
//         }

//         for (let i = 0; i < scratchCardWins.length && i < assignedPrizes.length; i++) {
//           const scratchCardWin = scratchCardWins[i];
//           const assignedPrize = assignedPrizes[i];
//           const assignedRNG = assignedRNGs[i]; // Get the corresponding RNG value

//           await scratchCardWin.update({ prize: assignedPrize, status: 0 });

//           // Update the randomRNG table with the corresponding RNG value
//           await db.scratchCardWin.update(
//             { randomRNG: assignedRNG },
//             { where: { prize: assignedPrize } }
//           );
//         }
//         console.log(assignedRNGs, "assignedRNG")
//         console.log("Assigned Prizes:", assignedPrizes);
//         return { success: true, message: "Prizes distributed successfully." };
//       }
//     } catch (error) {
//       console.error("Error while fetching data from the API:", error);
//     }
//   }

//   return { success: false, message: "No match found." };
// }

// const getRandomNumberInRange = (range) => {
//   const [min, max] = range.split('-').map(Number);
//   return Math.floor(Math.random() * (max - min + 1)) + min;
// };



async function allUpdatePrize(scratchCardId) {
  const assignedPrizes = [];

  const scratchPlayData = await db.scratchCardPlay.findAll({
    where: { scratchCardId },
  });

  if (scratchPlayData.length > 0) {
    try {
      const apiResponse = await axios.get(
        `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
      );
      const apiRandomNumber = apiResponse.data.data;

      const matchedRandomNumbers = apiRandomNumber.filter(
        (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ''
      );

      if (matchedRandomNumbers.length > 0) {
        const scratchCardWins = await db.scratchCardWin.findAll({
          where: { scratchCardId },
        });

        const totalPrizes = scratchCardWins.length;
        console.log(totalPrizes, 'totalPrizes')
        let oddsSum = 0;

        for (let i = 0; i < matchedRandomNumbers.length; i++) {
          const matchedRandomNumber = matchedRandomNumbers[i];
          const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
          oddsSum += oddsOfPrice;

          const timeToDistribute = (scratchCardWins.length) * (oddsOfPrice) / 100;
          const assignedPrize = matchedRandomNumber.price;
          const distributedCount = Math.round(timeToDistribute);

          if (assignedPrizes.length + distributedCount > totalPrizes) {
            distributedCount = totalPrizes - assignedPrizes.length;
          }

          console.log(`Time to distribute for oddsOfPrice ${oddsOfPrice} (${assignedPrize}): ${distributedCount}----all------${timeToDistribute}`);

          for (let j = 0; j < distributedCount; j++) {
            assignedPrizes.push(assignedPrize);
          }
        }

        shuffleArray(assignedPrizes);

        for (let i = 0; i < scratchCardWins.length && i < assignedPrizes.length; i++) {
          const scratchCardWin = scratchCardWins[i];
          const assignedPrize = assignedPrizes[i];

          await scratchCardWin.update({ prize: assignedPrize, status: 0 });
        }

        await db.scratchCardWin.update(
          { rescheduleTime: Sequelize.literal('rescheduleTime + 1') },
          { where: { scratchCardId } }
        );

        console.log("Assigned Prizes:", assignedPrizes);
        return { success: true, message: 'Prizes distributed successfully.' };
      }
    } catch (error) {
      console.error('Error while fetching data from the API:', error);
    }
  }

  return { success: false, message: 'No match found.' };
}