const db = require('../../_helpers/db');
const axios = require('axios');
const { Sequelize } = require('sequelize');


// async function allUpdatePrize(scratchCardId) {
//   const assignedPrizes = [];
//   const assignedRNGs = [];
//   const scratchPlayData = await db.scratchCardPlay.findAll({
//     where: { scratchCardId },
//   });

//   if (scratchPlayData.length > 0) {
//     try {
//       const apiResponse = await axios.get(
//         `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
//       );
//       const apiRandomNumber = apiResponse.data.data;

//       const matchedRandomNumbers = apiRandomNumber.filter(
//         (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ''
//       );

//       if (matchedRandomNumbers.length > 0) {
//         const scratchCardWins = await db.scratchCardWin.findAll({
//           where: { scratchCardId },
//         });

//         const totalPrizes = scratchCardWins.length;
//         console.log(totalPrizes, 'totalPrizes');
//         let oddsSum = 0;

//         for (let i = 0; i < matchedRandomNumbers.length; i++) {
//           const matchedRandomNumber = matchedRandomNumbers[i];
//           const range = matchedRandomNumber.rng;
//           const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
//           oddsSum += oddsOfPrice;

//           let timeToDistribute = (scratchCardWins.length * oddsOfPrice) / 100;
//           const assignedPrize = matchedRandomNumber.price;
//           let distributedCount = Math.round(timeToDistribute);
//           console.log(`Time to distribute for oddsOfPrice ${oddsOfPrice} (${assignedPrize}): ${distributedCount}----all------${timeToDistribute}`);

//           if (assignedPrizes.length + distributedCount > totalPrizes) {
//             distributedCount = totalPrizes - assignedPrizes.length;
//           }


//           for (let j = 0; j < distributedCount; j++) {
//             assignedPrizes.push(assignedPrize);
//             assignedRNGs.push(getRandomNumberInRange(range));
//           }
//         }

//         shuffleArray(assignedPrizes);

//         // Add remaining prizes closest to 0.5 timeToDistribute
//         while (assignedPrizes.length < totalPrizes) {
//           const remainingCount = totalPrizes - assignedPrizes.length;
//           const remainingPrizes = matchedRandomNumbers.filter(
//             (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== '' && !assignedPrizes.includes(item.price)
//           );

//           remainingPrizes.sort((a, b) => {
//             const diffA = Math.abs(0.5 - ((scratchCardWins.length * parseFloat(a.odds_of_price)) / (100 * oddsSum)));
//             const diffB = Math.abs(0.5 - ((scratchCardWins.length * parseFloat(b.odds_of_price)) / (100 * oddsSum)));
//             return diffA - diffB;
//           });

//           for (let i = 0; i < remainingCount; i++) {
//             assignedPrizes.push(remainingPrizes[i].price);
//             const range = remainingPrizes[i].rng;
//             assignedRNGs.push(getRandomNumberInRange(range)); // Store the randomly generated value within the range

//           }
//         }

//         for (let i = 0; i < scratchCardWins.length && i < assignedPrizes.length; i++) {
//           const scratchCardWin = scratchCardWins[i];
//           const assignedPrize = assignedPrizes[i];
//           const assignedRNG = assignedRNGs[i]; // Get the corresponding RNG value

//           await scratchCardWin.update({
//             randomRNG: assignedRNG,
//             prize: assignedPrize, status: 0
//           });
//         }
//         await db.scratchCardPlay.update(
//           { rescheduleTime: Sequelize.literal('rescheduleTime + 1') },
//           { where: { scratchCardId } },
//         );

//         console.log("Assigned AssignedRNG", assignedRNGs);
//         console.log("Assigned Prizes:", assignedPrizes);
//         return { success: true, message: 'Prizes distributed successfully.' };
//       }
//     } catch (error) {
//       console.error('Error while fetching data from the API:', error);
//     }
//   }

//   return { success: false, message: 'No match found.' };
// }

async function allUpdatePrize(scratchCardId) {
  const assignedPrizes = [];
  const assignedRNGs = [];
  const scratchPlayData = await db.scratchCardPlay.findAll({
    where: { scratchCardId },
  });

  if (scratchPlayData.length > 0) {
    try {
      const apiResponse = await axios.get(
        `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
      );
      const apiRandomNumber = apiResponse.data.data;

      const matchedRandomNumbers = apiRandomNumber.filter(
        (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ''
      );

      if (matchedRandomNumbers.length > 0) {
        const scratchCardWins = await db.scratchCardWin.findAll({
          where: { scratchCardId },
        });

        const totalPrizes = scratchCardWins.length;
        console.log(totalPrizes, 'totalPrizes');
        let oddsSum = 0;

        for (const matchedRandomNumber of matchedRandomNumbers) {
          const range = matchedRandomNumber.rng;
          const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
          oddsSum += oddsOfPrice;

          let timeToDistribute = (scratchCardWins.length * oddsOfPrice) / 100;
          const assignedPrize = matchedRandomNumber.price;
          let distributedCount = Math.round(timeToDistribute);
          console.log(`Time to distribute for oddsOfPrice ${oddsOfPrice} (${assignedPrize}): ${distributedCount}----all------${timeToDistribute}`);

          if (assignedPrizes.length + distributedCount > totalPrizes) {
            distributedCount = totalPrizes - assignedPrizes.length;
          }

          for (let j = 0; j < distributedCount; j++) {
            assignedPrizes.push(assignedPrize);
            assignedRNGs.push(getRandomNumberInRange(range));
          }
        }

        shuffleArray(assignedPrizes);

        // Add remaining prizes closest to 0.5 timeToDistribute
        while (assignedPrizes.length < totalPrizes) {
          const remainingCount = totalPrizes - assignedPrizes.length;
          const remainingPrizes = matchedRandomNumbers.filter(
            (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== '' && !assignedPrizes.includes(item.price)
          );

          if (remainingPrizes.length === 0) {
            console.error('Error: No valid remaining prizes found.');
            break;
          }

          remainingPrizes.sort((a, b) => {
            const diffA = Math.abs(0.5 - ((scratchCardWins.length * parseFloat(a.odds_of_price)) / (100 * oddsSum)));
            const diffB = Math.abs(0.5 - ((scratchCardWins.length * parseFloat(b.odds_of_price)) / (100 * oddsSum)));
            return diffA - diffB;
          });

          for (let i = 0; i < Math.min(remainingCount, remainingPrizes.length); i++) {
            const remainingPrize = remainingPrizes[i];
            assignedPrizes.push(remainingPrize.price);
            const range = remainingPrize.rng;
            assignedRNGs.push(getRandomNumberInRange(range)); // Store the randomly generated value within the range
          }
        }

        for (let i = 0; i < scratchCardWins.length && i < assignedPrizes.length; i++) {
          const scratchCardWin = scratchCardWins[i];
          const assignedPrize = assignedPrizes[i];
          const assignedRNG = assignedRNGs[i]; // Get the corresponding RNG value

          await scratchCardWin.update({
            randomRNG: assignedRNG,
            prize: assignedPrize,
            status: 0
          });
        }

        await db.scratchCardPlay.update(
          { rescheduleTime: Sequelize.literal('rescheduleTime + 1') },
          { where: { scratchCardId } },
        );

        console.log("Assigned AssignedRNG", assignedRNGs);
        console.log("Assigned Prizes:", assignedPrizes);
        return { success: true, message: 'Prizes distributed successfully.' };
      }
    } catch (error) {
      console.error('Error while fetching data from the API:', error);
    }
  }

  return { success: false, message: 'No match found.' };
}


function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

//----------------------------------add scratchcard -------------------

async function processScratchCard(scratchCardId, userId) {
  console.log(scratchCardId);
  console.log(userId);
  const plays = await db.scratchCardPlay.findOne({
    where: {
      scratchCardId: scratchCardId,
      UserId: userId
    }
  });
  // const arr1 = plays.map(play => play.scratchCards);
  const numbersArray = plays.scratchCards;

  const arr1 = numbersArray.split(',').map(String);

  let arr2 = [];
  const wins = await db.scratchCardWin.findAll({
    where: {
      scratchCardId: scratchCardId,
      UserId: userId,
      dailyStatus: 1
    }
  });
  for (const win of wins) {
    arr2.push(win.scratchCards);
  }
  const winsD = await db.scratchCardWin.findAll({
    where: {
      scratchCardId: scratchCardId,
      UserId: userId,
      dailyStatus: 0
    }
  });
  await Promise.all(winsD.map(async (win) => {
    await win.destroy();
  }));

  const lossD = await db.scratchCardLoss.findAll({
    where: {
      scratchCardId: scratchCardId,
      UserId: userId,
      dailyStatus: 0
    }
  });
  await Promise.all(lossD.map(async (win) => {
    await win.destroy();
  }));

  const losses = await db.scratchCardLoss.findAll({
    where: {
      scratchCardId: scratchCardId,
      UserId: userId,
      dailyStatus: 1
    }
  });
  const arr3 = losses.map(loss => loss.scratchCards);
  const arr4 = [...arr1, ...arr2, ...arr3];

  const arr5 = arr4.join(',').split(',');
  const scratchCardData = await db.scratchCard.findOne({
    where: {
      id: scratchCardId
    }
  });

  const oddsOfWin = scratchCardData.odds_of_win;
  function getPercentageArray(arr5, oddsOfWin) {
    const elementsNeeded = Math.round((oddsOfWin / 100) * arr5.length);
    const resultArray = arr5.slice(0, elementsNeeded);
    const remainingArray = arr5.slice(elementsNeeded);

    return {
      resultArray,
      remainingArray
    };
  }
  const result = getPercentageArray(arr5, oddsOfWin);

  const winArray = result.resultArray;
  const lossArray = result.remainingArray;

  const winsW = await db.scratchCardWin.findAll({
    where: {
      scratchCardId: scratchCardId,
      UserId: userId,
      dailyStatus: 1
    }
  });
  await Promise.all(winsW.map(async (win) => {
    await win.destroy();
  }));

  const lossL = await db.scratchCardLoss.findAll({
    where: {
      scratchCardId: scratchCardId,
      UserId: userId,
      dailyStatus: 1
    }
  });
  await Promise.all(lossL.map(async (win) => {
    await win.destroy();
  }));

  await Promise.all(winArray.map(async scratchCard => {
    await db.scratchCardWin.create({
      scratchCards: scratchCard,
      dailyStatus: 1,
      scratchCardId,
      UserId: userId
    });
  }));

  await Promise.all(lossArray.map(async scratchCard => {
    await db.scratchCardLoss.create({
      scratchCards: scratchCard,
      dailyStatus: 1,
      scratchCardId,
      UserId: userId
    });
  }));
}


async function userUpdatePrize(scratchCardId, userId) {
  const scratchPlayData = await db.scratchCardPlay.findAll({
    where: { scratchCardId },
  });

  if (scratchPlayData.length > 0) {
    try {
      const apiResponse = await axios.get(
        `${process.env.ASSET_URL}/api/scratchtable/scratch/${scratchCardId}`
      );

      const apiRandomNumber = apiResponse.data.data;
      const matchedRandomNumbers = apiRandomNumber.filter(
        (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== ""
      );

      // console.log(matchedRandomNumbers, 'matchedRandomNumbers')

      if (matchedRandomNumbers.length > 0) {
        const scratchCardWins = await db.scratchCardWin.findAll({
          where: {
            scratchCardId,
            userId,
            dailyStatus: 1,
          },
        });

        const assignedPrizes = [];
        const assignedRNGs = []; // Array to store the corresponding RNG values
        const totalPrizes = scratchCardWins.length;
        console.log(totalPrizes, "totalPrizes");
        let oddsSum = 0;

        for (let i = 0; i < matchedRandomNumbers.length; i++) {
          const matchedRandomNumber = matchedRandomNumbers[i];
          const range = matchedRandomNumber.rng;
          const oddsOfPrice = parseFloat(matchedRandomNumber.odds_of_price);
          oddsSum += oddsOfPrice;

          const timeToDistribute = scratchCardWins.length * oddsOfPrice / 100;
          const assignedPrize = matchedRandomNumber.price;
          const distributedCount = Math.round(timeToDistribute);

          console.log(`Time to distribute for oddsOfPrice ${oddsOfPrice} (${assignedPrize}): ${distributedCount}---user-------${timeToDistribute}`);

          for (let j = 0; j < distributedCount; j++) {
            assignedPrizes.push(assignedPrize);
            assignedRNGs.push(getRandomNumberInRange(range)); // Store the randomly generated value within the range
          }
        }
        while (assignedPrizes.length < totalPrizes) {
          const remainingCount = totalPrizes - assignedPrizes.length;
          const remainingPrizes = matchedRandomNumbers.filter(
            (item) => parseFloat(item.odds_of_price) !== 0 && item.price !== '' && !assignedPrizes.includes(item.price)
          );

          remainingPrizes.sort((a, b) => {
            const diffA = Math.abs(0.5 - ((scratchCardWins.length * parseFloat(a.odds_of_price)) / (100 * oddsSum)));
            const diffB = Math.abs(0.5 - ((scratchCardWins.length * parseFloat(b.odds_of_price)) / (100 * oddsSum)));
            return diffA - diffB;
          });

          for (let i = 0; i < remainingCount; i++) {
            const remainingPrize = remainingPrizes[i].price;
            const range = remainingPrizes[i].rng;

            assignedPrizes.push(remainingPrize);
            assignedRNGs.push(getRandomNumberInRange(range)); // Store the randomly generated value within the range
          }
        }

        for (let i = 0; i < scratchCardWins.length && i < assignedPrizes.length; i++) {
          const scratchCardWin = scratchCardWins[i];
          const assignedPrize = assignedPrizes[i];
          const assignedRNG = assignedRNGs[i]; // Get the corresponding RNG value

          await scratchCardWin.update({ randomRNG: assignedRNG, prize: assignedPrize, status: 0 });

          // Update the randomRNG field in the scratchCardWin model with the corresponding RNG value
          // await scratchCardWin.update({ randomRNG: assignedRNG });
        }
        console.log("Assigned AssignedRNG", assignedRNGs);
        console.log("Assigned Prizes:", assignedPrizes);
        return { success: true, message: "Prizes distributed successfully." };
      }
    } catch (error) {
      console.error("Error while fetching data from the API:", error);
    }
  }

  return { success: false, message: "No match found." };
}

const getRandomNumberInRange = (range) => {
  const [min, max] = range.split('-').map(Number);
  const randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
  console.log(`Generated random number for range ${range}: ${randomNumber}`);
  return randomNumber;
};


module.exports = { allUpdatePrize, userUpdatePrize, processScratchCard };
