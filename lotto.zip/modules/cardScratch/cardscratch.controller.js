const express = require('express');
const router = express.Router();
const ScratchCardService = require('./cardscratch.service');
const db = require('../../_helpers/db');


async function updatePrize(req, res) {
    const { scratchCardId } = req.body;
    try {
        const price = await ScratchCardService.allUpdatePrize(scratchCardId);
        if (price) {
            return res.json({ success: true, price });
        }
        return res.json({ success: false, message: 'No match found.' });
    } catch (error) {
        console.error('Error while updating prize:', error);
        return res.status(500).json({ success: false, message: 'Internal server error.' });
    }
};



async function userUpdatePrize(req, res) {
    const { scratchCardId, userId } = req.body;
    try {
        const { success, message, assignedPrizes } = await ScratchCardService.userUpdatePrize(scratchCardId, userId);
        if (success) {
            return res.json({ success: true, assignedPrizes });
        }
        return res.json({ success: false, message });
    } catch (error) {
        console.error('Error while updating prize:', error);
        return res.status(500).json({ success: false, message: 'Internal server error.' });
    }
}


// async function playScratchCard(req, res) {
//     try {
//         const { scratchCardId, userId } = req.body;

//         await ScratchCardService.processScratchCard(scratchCardId, userId);

//         res.status(200).json({ message: 'Scratch card played successfully.' });
//     } catch (error) {
//         console.error('Error playing scratch card:', error);
//         res.status(500).json({ error: 'Internal server error.' });
//     }
// }

// async function playScratchCard(req, res) {
//     try {
//         const { scratchCardId } = req.body;

//         // Retrieve all userId values from scratchCardPlay table
//         const users = await db.scratchCardPlay.findAll({ attributes: ['UserId'] });
//         console.log(users,"users")
//         const userIds = users.map(user => user.dataValues.userId);

//         console.log(userIds,"userIds")

//         // Process scratch card for each userId
//         for (const userId of userIds) {
//             await ScratchCardService.processScratchCard(scratchCardId, userId);
//         }

//         res.status(200).json({ message: 'Scratch card played successfully.' });
//     } catch (error) {
//         console.error('Error playing scratch card:', error);
//         res.status(500).json({ error: 'Internal server error.' });
//     }
// }


// async function playScratchCard(req, res) {
//     try {
//         const { scratchCardId } = req.body;

//         const users = await db.scratchCardPlay.findAll({
//             attributes: ['UserId'],
//             where: {
//                 scratchCardId: scratchCardId
//             }
//         });

//         const userIds = users.map(user => user.dataValues.UserId);

//         for (const userId of userIds) {
//             await ScratchCardService.processScratchCard(scratchCardId, userId);
//         }

//         res.status(200).json({ message: 'Scratch card played successfully.' });
//     } catch (error) {
//         console.error('Error playing scratch card:', error);
//         res.status(500).json({ error: 'Internal server error.' });
//     }
// }
async function playScratchCard(req, res) {
    try {
        const { scratchCardId } = req.body;

        const users = await db.scratchCardPlay.findAll({
            attributes: ['UserId'],
            where: {
                scratchCardId: scratchCardId
            }
        });

        const userIds = users.map(user => user.dataValues.UserId);
        const processedCombinations = []; // Array to store processed combinations

        for (const userId of userIds) {
            const combination = `${scratchCardId}-${userId}`;

            if (!processedCombinations.includes(combination)) {
                await ScratchCardService.processScratchCard(scratchCardId, userId);
                processedCombinations.push(combination); // Mark combination as processed
            }
        }

        res.status(200).json({ message: 'Scratch card played successfully.' });
    } catch (error) {
        console.error('Error playing scratch card:', error);
        res.status(500).json({ error: 'Internal server error.' });
    }
}



module.exports = router;
router.put('/store', updatePrize);

router.put('/store/user', userUpdatePrize);

router.post('/scratch-card/play', playScratchCard);