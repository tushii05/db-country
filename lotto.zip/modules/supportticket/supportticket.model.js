const { DataTypes, literal } = require('sequelize');

module.exports = model;

function model(sequelize) {
    const attributes = {
        UserId: { type: DataTypes.INTEGER, allowNull: false },
        name: { type: DataTypes.STRING, allowNull: false },
        email: { type: DataTypes.STRING, allowNull: false },
        images: { type: DataTypes.JSON, allowNull: false },
        randomNo: { type: DataTypes.STRING, allowNull: true },
        subject: { type: DataTypes.STRING, allowNull: false },
        status: { type: DataTypes.STRING, allowNull: false, defaultValue: 0, comment: "0: Pending, 1: Open, 2: Answered, 3:Closed" },
        priority: { type: DataTypes.TINYINT, allowNull: false, defaultValue: 1, comment: "1 = Low, 2 = medium, 3 = heigh" },
        message: { type: DataTypes.TEXT('long'), allowNull: true },
    };

    const options = {
        defaultScope: {
            // exclude hash by default
            attributes: { exclude: [''] }
        },
        scopes: {
            // include hash with this scope
            withHash: { attributes: {}, }
        }
    };
    return sequelize.define('SupportTicket', attributes, options);
}