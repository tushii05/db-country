﻿const db = require('../../_helpers/db');
const { Sequelize, literal } = require('sequelize');
const { supportRandomNo } = require("../../_middleware/random-number");
const { Op } = require("sequelize");

module.exports = {
    getAll,
    getById,
    create,
    update,
    _delete
};
async function getAll({ offset = 0, limit = 100, orderBy = 'id', orderType = 'DESC', search = null }) {
    let where = {};
    if (search !== null) {
        where = {
            [Op.or]: [
                { name: { [Op.like]: `%${search}%` } }
            ]
        }
    }
    const supportCount = await db.supportTicket.count({
        where
    });
    return await db.supportTicket.findAll({
        where,
        include: [{ model: db.supportTicketMessage }],
        offset: parseInt(offset),
        limit: parseInt(limit),
        order: [[orderBy, orderType]]
    })
        .then((rows) => {
            return {
                count: supportCount,
                rows
            };
        });
};

async function getById(id) {
    return await getSupportTicket(id);
}


async function create(params) {
    params.randomNo = await supportRandomNo();
    const d = await db.supportTicket.create({ ...params });
    return d;
}


async function update(id, params) {
    const supportTicket = await db.supportTicket.findOne({ where: { id: id } });
    if (!supportTicket) throw 'supportTicket not found'
    Object.assign(supportTicket, params);
    return await supportTicket.save();
}
// helper functions

async function getSupportTicket(id) {
    const supportTicket = await db.supportTicket.findByPk(id);
    if (!supportTicket) throw 'supportTicket not found';
    return await db.supportTicket.findOne({
        where: { id: id },
        include: [{
            model: db.supportTicketMessage,
        }]
    });
}
async function _delete(id) {
    const supportTicket = await db.supportTicket.findOne({ where: { id: id } });
    if (supportTicket) {
        await supportTicket.destroy();
        return true;
    }
}
