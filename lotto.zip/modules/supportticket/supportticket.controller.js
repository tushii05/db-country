﻿const express = require('express');
const router = express.Router();
const Joi = require('joi');
const { validateRequest } = require('../../_middleware/validate-request');
const supportTicketService = require('./supportticket.service');
let multer = require('multer');
const fs = require('fs');



const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, "uploads/supportTicket");
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + "-" + file.originalname.toLowerCase().split(' ').join('-'));
    }
});

const upload = multer({
    storage: storage,
    fileFilter: (req, file, cb) => {
        if (file.mimetype == "application/pdf" || file.mimetype == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" || file.mimetype == "application/vnd.openxmlformats-officedocument.wordprocessingml.document" || file.mimetype == "image/png" || file.mimetype == "image/jpeg") {
            cb(null, true);
        } else {
            return cb('Only .pdf, .xlsx, .docx, .png, .jpg and .jpeg formats allowed!', false);
        }
    }
});


const cpUpload = upload.array('images');
function uploadImage(req, res, next) {
    cpUpload(req, res, function (err) {
        if (!fs.existsSync("supportTicket")) {
            fs.mkdirSync("supportTicket");
        }
        if (err instanceof multer.MulterError) {
            return res.status(400).json({ message: JSON.stringify(err) });
        } else if (err) {
            return res.status(400).json({ message: err });
        }
        next();
    });
}


// routes
router.get('/', getAllSchema, getAll);
router.post('/store', uploadImage, storeSchema, store);
router.get('/:id', getById);
router.put('/:id', uploadImage, update);
router.delete('/:id', _delete);
module.exports = router;
// currency section
function getAllSchema(req, res, next) {
    const schema = Joi.object({
        offset: Joi.number().integer().min(0).empty(''),
        limit: Joi.number().integer().min(1).empty(''),
        orderBy: Joi.string().valid('id', 'createdAt', 'name').empty(''),
        orderType: Joi.string().valid('DESC', 'ASC').empty(''),
        search: Joi.string().empty(''),
    });
    validateRequest(req, next, schema, 'query');
}
function getAll(req, res, next) {
    supportTicketService.getAll(req.query)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}


function store(req, res, next) {
    const images = [];
    if (req.files) {
        req.files.forEach(file => {
            images.push({
                filename: file.filename,
                url: `${process.env.ASSET_URL}/supportTicket/${file.filename}`
            });
        });
    }
    req.body.images = images;
    supportTicketService.create(req.body)
        .then(data => { res.json({ message: 'Success', data }) })
        .catch(next);
}


function storeSchema(req, res, next) {
    const schema = Joi.object({
        UserId: Joi.number().required(),
        name: Joi.string().required(),
        randomNo: Joi.string().empty(''),
        email: Joi.string().required(),
        subject: Joi.string().required(),
        message: Joi.string().empty(''),
        priority: Joi.number().empty(''),
        images: Joi.array().items(Joi.object({
            filename: Joi.string(),
            url: Joi.string(),

        }))
    });
    validateRequest(req, next, schema);
}

function getById(req, res, next) {
    supportTicketService.getById(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function update(req, res, next) {
    if (req.file) {
        req.body.images = `${process.env.ASSET_URL}/supportTicket/${req.file.filename}`;
    }
    supportTicketService.update(req.params.id, req.body)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function _delete(req, res, next) {
    supportTicketService._delete(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}


//Helper 
