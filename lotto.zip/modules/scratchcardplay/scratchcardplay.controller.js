﻿const express = require('express');
const router = express.Router();
const Joi = require('joi');
const { validateRequest } = require('../../_middleware/validate-request');
const scratchCardPlayService = require('./scratchcardplay.service');
module.exports = router;

router.get('/', getAllSchema, getAll);
router.post('/store', storeSchema, store);
router.get('/:id', getById);
router.put("/:id", update);
module.exports = router;

function getAllSchema(req, res, next) {
    const schema = Joi.object({
        offset: Joi.number().integer().min(0).empty(''),
        limit: Joi.number().integer().min(1).empty(''),
        orderBy: Joi.string().valid('id', 'createdAt').empty(''),
        orderType: Joi.string().valid('DESC', 'ASC').empty(''),
        search: Joi.string().empty(''),
    });
    validateRequest(req, next, schema, 'query');
}

function getAll(req, res, next) {
    scratchCardPlayService.getAll(req.query)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function store(req, res, next) {
    scratchCardPlayService.create(req.body)
        .then(data => { res.json({ message: 'Success', data }) })
        .catch(next);
}

function storeSchema(req, res, next) {
    const schema = Joi.object({
        scratchCardId: Joi.number().integer().required(),
        userId: Joi.number().integer().required(),
        scratchCardPrice: Joi.string().required(),
        scratchDraw: Joi.number().integer().required(),
        scratchCards: Joi.array().items(Joi.object(
            { scratchCardNumber: Joi.string().required() }
        )).min(1).required(),
        totalPrice: Joi.string().required(),
        transactionId: Joi.string().empty(''),
    });
    validateRequest(req, next, schema);
}

function getById(req, res, next) {
    scratchCardPlayService.getById(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

async function update(req, res, next) {
    const scratchCardId = req.params.id;
    scratchCardPlayService.update(scratchCardId)
        .then(result => {
            if (result.success) {
                res.json({ message: 'Scratch Draw Count updated successfully' });
            } else {
                res.status(404).json({ message: 'Scratch Card not found' });
            }
        })
        .catch(error => next(error));
}