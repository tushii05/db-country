const { DataTypes, literal } = require('sequelize');

module.exports = model;

function model(sequelize) {
    const attributes = {
        scratchCardId: { type: DataTypes.INTEGER, allowNull: false },
        scratchCardPrice: { type: DataTypes.DECIMAL, allowNull: false },
        scratchDraw: { type: DataTypes.INTEGER, allowNull: true },
        scratchDrawCount: { type: DataTypes.INTEGER, allowNull: true, defaultValue: 0 },
        scratchCards: { type: DataTypes.STRING, allowNull: false },
        totalPrice: { type: DataTypes.STRING, allowNull: null },
        transactionId: { type: DataTypes.STRING, allowNull: null },
        randomNumber: { type: DataTypes.STRING, allowNull: true },
        won: { type: DataTypes.INTEGER, allowNull: true, defaultValue: 0 },
        rescheduleTime: { type: DataTypes.INTEGER, allowNull: true, defaultValue: 0 },
        winning_card: { type: DataTypes.INTEGER, allowNull: true, defaultValue: 0 },
        buyLimit: { type: DataTypes.INTEGER, allowNull: true, defaultValue: 0 },

    };

    const options = {
        defaultScope: {
            // exclude hash by default
            attributes: { exclude: [''] }
        },
        scopes: {
            // include hash with this scope
            withHash: { attributes: {}, }
        }
    };

    return sequelize.define('scratchCardPlays', attributes, options);
}