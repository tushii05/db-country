﻿const db = require('../../_helpers/db');
const { Sequelize, Op } = require('sequelize');
const { sendEmail } = require('../../_middleware/email');
const crypto = require('crypto');
module.exports = {
    getAll,
    getById,
    create,
    update,
};

async function getAll({ offset = 0, orderBy = 'id', orderType = 'DESC', search = null }) {
    let where = {};
    if (search !== null) {
        where = { '$User.fname$': { [Op.like]: `%${search}%` } }
    }

    return await db.scratchCardPlay.findAndCountAll({
        where,
        include: [
            { model: db.scratchCard },
            {
                model: db.User,
                attributes: ["fname", "userName", "email", "totalScratchCardWon"]
            }
        ],
        offset: parseInt(offset),
        order: [[orderBy, orderType]]
    });
}

async function getById(id) {
    return await getLotteryTicket(id);
}

// async function generateUniqueRandomNumber(scratchCardId) {
//     const randomNumber = Math.floor(Math.random() * 100000) + 1;
//     const exists = await db.scratchCardPlay.findOne({
//         where: { scratchCardId, randomNumber }
//     });
//     if (exists) {
//         return generateUniqueRandomNumber(scratchCardId); // Recursively generate a new number if it already exists
//     }
//     console.log(randomNumber,"randomNumber")
//     return randomNumber;
// }





async function generateUniqueRandomNumber(scratchCardId) {
    const buffer = crypto.randomBytes(8);
    const randomNumber = buffer.readUIntLE(0, 8);
    const exists = await db.scratchCardPlay.findOne({
        where: { scratchCardId, randomNumber }
    });
    if (exists) {
        return generateUniqueRandomNumber(scratchCardId);
    }
    return randomNumber;
}

async function create(params) {
    let ticketArr = [];
    if (params.scratchCards) {
        for (const value of params.scratchCards) {
            ticketArr.push(value.scratchCardNumber);
        }
    }
    const Lottery = {
        "scratchCardId": params.scratchCardId,
        "UserId": params.userId,
        "scratchCardPrice": params.scratchCardPrice,
        "scratchDraw": params.scratchDraw,
        "scratchCards": ticketArr.join(","),
        "totalPrice": params.totalPrice,
        "transactionId": params.transactionId,
    }
    // for scratchDrawCount -------------------

    const matchingScratchCard = await db.scratchCard.findOne({
        where: { id: params.scratchCardId }
    });

    if (matchingScratchCard) {
        const newScratchDrawCount = matchingScratchCard.scratchDrawCount + params.scratchDraw;
        const newBuyLimit = matchingScratchCard.buyLimit + params.scratchDraw;

        await db.scratchCard.update(
            { scratchDrawCount: newScratchDrawCount, buyLimit: newBuyLimit },
            { where: { id: params.scratchCardId } }
        );
    }

    //for Update all old records with the new scratchCards value
    const cardMatchingRows = await db.scratchCardPlay.findAll({
        where: { UserId: params.userId, scratchCardId: params.scratchCardId },
    });

    if (cardMatchingRows.length > 0) {
        // Concatenate existing scratchCards values with new values
        const existingScratchCards = cardMatchingRows[0].scratchCards;
        Lottery.scratchCards = existingScratchCards ? `${existingScratchCards},${Lottery.scratchCards}` : Lottery.scratchCards;

        // Update all old records with the new scratchCards value
        await db.scratchCardPlay.update(
            { scratchCards: Lottery.scratchCards },
            { where: { UserId: params.userId, scratchCardId: params.scratchCardId } }
        );
    }

    const LotterySql = await db.scratchCardPlay.create(Lottery);
    let totalScratchCardPlay = await db.scratchCardPlay.findOne({
        attributes: [
            [db.sequelize.fn("SUM", db.sequelize.cast(db.sequelize.col("totalPrice"), 'integer')), "totalPrice"]
        ],
        where: { UserId: params.userId }
    });

    await db.User.update(
        { BuyTicketId: LotterySql.id, totalCardAmount: totalScratchCardPlay.dataValues.totalPrice },
        { where: { id: params.userId } }
    )
    //for scratchCardCount --------------------------
    const matchingRows = await db.scratchCardPlay.findAll({
        where: { UserId: params.userId, scratchCardId: params.scratchCardId },
        order: [['id', 'ASC']]
    });

    if (matchingRows.length > 0) {
        const oldScratchDrawCount = matchingRows[0].scratchDrawCount;
        const newScratchDrawCount = oldScratchDrawCount + params.scratchDraw;

        const oldBuyLimit = matchingRows[0].buyLimit;
        const newBuyLimit = oldBuyLimit + params.scratchDraw;

        await db.scratchCardPlay.update(
            { scratchDrawCount: newScratchDrawCount, buyLimit: newBuyLimit },
            { where: { UserId: params.userId, scratchCardId: params.scratchCardId } }
        );
    }
    //--------------
    try {

        const [user] = await Promise.all([
            db.User.findOne({ where: { id: params.userId } }),
            db.scratchCardPlay.findOne({ where: { id: LotterySql.id } })
        ]);
        if (!user || !user.email || user.email.trim() === "") {
            throw new Error("User email not found");
        }
        const randomNumber = await generateUniqueRandomNumber(params.scratchCardId);
        // Generate a unique random number
        await db.scratchCardPlay.update(
            { randomNumber: randomNumber },
            { where: { id: LotterySql.id } }
        );

        const html = `
    <div style="background-color: #f8f8f8; padding: 20px; font-family: Arial, sans-serif;">
        <h2 style="color: #ff5722; margin-bottom: 20px;">Scratch Card Purchase Successful</h2>
        <p style="font-size: 16px;">Dear <b>${user.fname} ${user.lname}</b>,</p>
        <p style="font-size: 16px;">Congratulations! You have successfully purchased Scratch Card on Lifetime Lotto.</p>
        <p style="font-size: 16px;">To know more details about your Scratch Card, <a href="${process.env.ASSET_URL}/ticketlist" style="color: #007bff; text-decoration: none;">Click Here</a>.</p>
        <p style="font-size: 16px;">We hope you enjoy playing on Lifetime Lotto and make the most out of your Scratch Card.</p>
        <br>
        <p style="font-size: 16px;">The team at Lifetime Lotto</p>
    </div>
    
    `;
        const subject = "Scratch Card Purchase Successful";
        await sendEmail(user.email, subject, html);
    } catch (error) {
    }
    return LotterySql;
}

// Helper functions 

async function getLotteryTicket(id) {
    const ticket = await db.scratchCardPlay.findByPk(id);
    if (!ticket) throw 'Scratch Card not found';
    return await db.scratchCardPlay.findOne({
        where: { id: id },
        include: [
            { model: db.scratchCard },
            {
                model: db.User,
                attributes: ["fname", "userName", "email", "totalScratchCardWon"]
            }
        ]
    });
}

// async function update(scratchCardId) {
//     const lotteryTickets = await db.scratchCardPlay.findAll({
//         where: { scratchCardId },
//         order: [['UserId', 'DESC']]
//     });

//     if (lotteryTickets.length > 0) {
//         const updatedScratchDrawCount = lotteryTickets[0].scratchDrawCount + lotteryTickets[0].scratchDraw;
//         await db.scratchCardPlay.update(
//             { scratchDrawCount: updatedScratchDrawCount },
//             { where: { scratchCardId, UserId: lotteryTickets[0].UserId } }
//         );
//         return { success: true, message: 'Scratch Draw Count updated successfully' };
//     }

//     return { success: false, message: 'Scratch Card not found' };
// }


async function update(scratchCardId) {
    const lotteryTickets = await db.scratchCardPlay.findAll({
        where: { scratchCardId },
    });

    if (lotteryTickets.length > 0) {
        const scratchDrawSumByUser = {};

        lotteryTickets.forEach((ticket) => {
            const userId = ticket.UserId;
            const scratchDraw = ticket.scratchDraw;

            if (!scratchDrawSumByUser[userId]) {
                scratchDrawSumByUser[userId] = scratchDraw;
            } else {
                scratchDrawSumByUser[userId] += scratchDraw;
            }
        });

        await Promise.all(
            Object.entries(scratchDrawSumByUser).map(([userId, scratchDrawSum]) =>
                db.scratchCardPlay.update(
                    {
                        scratchDrawCount: db.sequelize.literal(`scratchDrawCount + ${scratchDrawSum}`),
                        buyLimit: 0
                    },
                    { where: { scratchCardId, UserId: userId } }
                )
            )
        );

        return { success: true, message: 'Scratch Draw Count updated successfully' };
    }

    return { success: false, message: 'Scratch Card not found' };
}
