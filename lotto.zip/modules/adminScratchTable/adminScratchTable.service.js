const db = require('../../_helpers/db');

module.exports = {
    getAll,
    getById,
    getByScratchCardId,
    getScratchCardId,
    create,
    update,
    _delete
};

async function getAll({ offset = 0, limit = 100, orderBy = 'id', orderType = 'DESC' }) {
    return await db.ScratchTable.findAll({
        offset: parseInt(offset),
        limit: parseInt(limit),
        order: [[orderBy, orderType]]
    });
}

async function getById(id) {
    return await getById(id);
}

async function getByScratchCardId(id) {
    return await getByScratchCardId(id);
}
async function getScratchCardId(scratchCardId) {
    const ScratchTables = await db.ScratchTable.findAll({ where: { scratchCardId } });
    if (!ScratchTables || ScratchTables.length === 0) throw 'ScratchTable Is not found';
    return ScratchTables;
}
async function create(params) {
    const d = await db.ScratchTable.create(params);
    return d;
}

//Helper Function 

async function getById(id) {
    const ScratchTable = await db.ScratchTable.findByPk(id);
    if (!ScratchTable) throw 'ScratchTable not found';
    return ScratchTable;
}

function calculateRngData(rng, price) {
    const data = [];
    const ranges = rng.split(';');
    ranges.forEach(range => {
        const [start, end] = range.split('-');
        const startNum = parseInt(start);
        const endNum = parseInt(end);
        for (let i = startNum; i <= endNum; i++) {
            const rangeData = {
                rng: i,
                price
            };
            data.push(rangeData);
        }
    });
    return data;
}

async function getByScratchCardId(scratchCardId) {
    const ScratchTables = await db.ScratchTable.findAll({ where: { scratchCardId } });
    if (!ScratchTables || ScratchTables.length === 0) throw 'ScratchTable Is not found';
    const calculatedData = [];
    for (const ScratchTable of ScratchTables) {
        const rng = ScratchTable.rng;
        const price = ScratchTable.price;
        const calculatedRangeData = calculateRngData(rng, price);
        calculatedData.push(...calculatedRangeData);
    }
    return {
        ScratchTables,
        calculatedData
    };
}

async function update(paramsArray) {
    const updatedRows = [];
    let scratchTables = [];
    for (let i = 0; i < paramsArray.length; i++) {
        const params = paramsArray[i];
        scratchTables = await db.ScratchTable.findAll({ where: { scratchCardId: params.scratchCardId } });
        if (!scratchTables || scratchTables.length === 0) {
            throw 'ScratchTable not found';
        }
        if (i >= scratchTables.length) {
            const newScratchTable = await db.ScratchTable.create(params);
            updatedRows.push(newScratchTable);
        } else {
            const scratchTable = scratchTables[i];
            Object.assign(scratchTable, params);
            await scratchTable.save();
            updatedRows.push(scratchTable);
        }
    }
    if (paramsArray.length < scratchTables.length) {
        const rowsToDelete = scratchTables.slice(paramsArray.length);
        for (const scratchTable of rowsToDelete) {
            await scratchTable.destroy();
        }
    }
    return updatedRows;
}


async function _delete(scratchCardId) {
    await db.ScratchTable.destroy({ where: { scratchCardId: scratchCardId } });
    return true;
}
