const express = require('express');
const router = express.Router();
const Joi = require('joi');
const crypto = require('crypto');

const { validateRequest } = require('../../_middleware/validate-request');
const ScratchTableService = require('./adminScratchTable.service');
const { generateRandomNumberTable } = require('../../_middleware/random-number')
module.exports = router;


router.get('/', getAllSchema, getAll);
router.post('/store', storeSchema, store);
router.get('/:id', getById);
router.get('/scratchcard/:scratchCardId', getByScratchCardId);
router.get('/scratch/:scratchCardId', getScratchCardId);
router.put('/update', updateHandler);
router.delete('/delete/:scratchCardId', deleteScratchTable);

module.exports = router;

function getAllSchema(req, res, next) {
    const schema = Joi.object({
        offset: Joi.number().integer().min(0).empty(''),
        limit: Joi.number().integer().min(1).empty(''),
        orderBy: Joi.string().valid('id', 'createdAt').empty(''),
        orderType: Joi.string().valid('DESC', 'ASC').empty(''),
        search: Joi.string().empty(''),
    });
    validateRequest(req, next, schema, 'query');
}
function getAll(req, res, next) {
    ScratchTableService.getAll(req.query)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}


// function store(req, res, next) {
//     const data = req.body;
//     const createdRecords = [];
//     const totalOdds = data.reduce((sum, item) => sum + parseFloat(item.odds_of_price), 0);
//     const rangeEnd = 100000;

//     (async () => {
//         let currentRangeStart = 1;
//         let currentRangeEnd = 0;
//         let previousRngEnd = 0;

//         for (let i = 0; i < data.length; i++) {
//             const item = data[i];
//             const odds = parseFloat(item.odds_of_price);
//             const oddsPercentage = (odds / totalOdds) * rangeEnd;

//             const previousRangeEnd = currentRangeEnd;
//             currentRangeStart = previousRangeEnd + 1;
//             currentRangeEnd = currentRangeStart + Math.floor(oddsPercentage) - 1;

//             if (currentRangeEnd === previousRangeEnd) {
//                 currentRangeEnd++;
//             }

//             let rng = currentRangeStart === currentRangeEnd ? currentRangeStart.toString() : `${currentRangeStart}-${currentRangeEnd}`;

//             if (odds === 0) {
//                 rng = '0';
//                 currentRangeStart = previousRngEnd + 1;
//                 currentRangeEnd = currentRangeStart + Math.floor(oddsPercentage) - 1;
//             }

//             const record = await ScratchTableService.create({ ...item, rng });
//             createdRecords.push(record);

//             previousRngEnd = currentRangeEnd;
//         }

//         res.json({ message: 'Success', data: createdRecords });
//     })();
// }



// function store(req, res, next) {
//     const data = req.body;
//     const createdRecords = [];
//     const totalOdds = data.reduce((sum, item) => sum + parseFloat(item.odds_of_price), 0);
//     const rangeEnd = 100000;

//     (async () => {
//         let currentRangeStart = 1;
//         let currentRangeEnd = 0;
//         let previousRngEnd = 0;

//         for (let i = 0; i < data.length; i++) {
//             const item = data[i];
//             const odds = parseFloat(item.odds_of_price);
//             const oddsPercentage = (odds / totalOdds) * rangeEnd;

//             const previousRangeEnd = currentRangeEnd;
//             currentRangeStart = previousRangeEnd + 1;
//             currentRangeEnd = currentRangeStart + Math.floor(oddsPercentage) - 1;

//             if (currentRangeEnd === previousRangeEnd) {
//                 currentRangeEnd++;
//             }

//             let rng;

//             if (odds === 0) {
//                 rng = '0';
//                 currentRangeStart = previousRngEnd + 1;
//                 currentRangeEnd = currentRangeStart + Math.floor(oddsPercentage) - 1;
//             } else {
//                 const randomBytes = crypto.randomBytes(8);
//                 const randomHex = randomBytes.toString('hex');
//                 const randomNumber = parseInt(randomHex, 16);
//                 const rangeSize = currentRangeEnd - currentRangeStart + 1;
//                 const randomNumberInRange = currentRangeStart + (randomNumber % rangeSize);
//                 rng = `${currentRangeStart}-${currentRangeEnd}`;
//             }

//             const record = await ScratchTableService.create({ ...item, rng });
//             createdRecords.push(record);

//             previousRngEnd = currentRangeEnd;
//         }

//         res.json({ message: 'Success', data: createdRecords });
//     })();
// }



// function generateRandomNumberTable(rangeStart, rangeEnd) {
//     const rangeSize = BigInt(rangeEnd - rangeStart + 1);
//     const byteSize = Math.ceil((rangeSize.toString(2).length + 7) / 8) || 1;

//     let randomNumber;
//     do {
//         const randomBytes = crypto.randomBytes(byteSize);
//         randomNumber = BigInt('0x' + randomBytes.toString('hex'));
//     } while (randomNumber > ((BigInt(2) ** BigInt(byteSize * 8) - rangeSize) - 1n));

//     const finalNumber = randomNumber + BigInt(rangeStart);
//     return Number(finalNumber);
// }

function store(req, res, next) {
    const data = req.body;
    const createdRecords = [];
    const totalOdds = data.reduce((sum, item) => sum + parseFloat(item.odds_of_price), 0);
    const rangeEnd = 10000000;

    (async () => {
        let currentRangeStart = 1;
        let currentRangeEnd = 0;
        let previousRngEnd = 0;

        for (let i = 0; i < data.length; i++) {
            const item = data[i];
            const odds = parseFloat(item.odds_of_price);
            const oddsPercentage = (odds / totalOdds) * rangeEnd;

            const previousRangeEnd = currentRangeEnd;
            currentRangeStart = previousRangeEnd + 1;
            currentRangeEnd = currentRangeStart + Math.floor(oddsPercentage) - 1;

            if (currentRangeEnd === previousRangeEnd) {
                currentRangeEnd++;
            }

            let rng;

            if (odds === 0) {
                rng = '0';
                currentRangeStart = previousRngEnd + 1;
                currentRangeEnd = currentRangeStart + Math.floor(oddsPercentage) - 1;
            } else {
                const randomNumberInRange = generateRandomNumberTable(currentRangeStart, currentRangeEnd);
                rng = `${currentRangeStart}-${currentRangeEnd}`;
            }

            const record = await ScratchTableService.create({ ...item, rng });
            createdRecords.push(record);

            previousRngEnd = currentRangeEnd;
        }

        res.json({ message: 'Success', data: createdRecords });
    })();
}



function storeSchema(req, res, next) {
    const schema = Joi.array().items(
        Joi.object({
            rng: Joi.string().empty(''),
            odds_of_price: Joi.number().required(),
            price: Joi.string().required(),
            scratchCardId: Joi.number().required()
        })
    );
    validateRequest(req, next, schema);
}


function getById(req, res, next) {
    ScratchTableService.getById(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function getByScratchCardId(req, res, next) {
    ScratchTableService.getByScratchCardId(req.params.scratchCardId)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function getScratchCardId(req, res, next) {
    ScratchTableService.getScratchCardId(req.params.scratchCardId)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

// async function updateHandler(req, res, next) {
//     const paramsArray = req.body;
//     const createdRecords = [];
//     let totalOdds = 0;
//     for (const item of paramsArray) {
//         totalOdds += parseInt(item.odds_of_price);
//     }
//     let scratchTables = await db.ScratchTable.findAll({ where: { scratchCardId: paramsArray[0].scratchCardId } });
//     if (!scratchTables || scratchTables.length === 0) {
//         throw 'ScratchTable not found';
//     }
//     let currentRange = 0;
//     for (let i = 0; i < paramsArray.length; i++) {
//         const params = paramsArray[i];
//         const odds = parseInt(params.odds_of_price);
//         const rangeStart = currentRange + 1;
//         const rangeEnd = currentRange + odds;
//         const rng = `${rangeStart}-${rangeEnd}`;
//         if (i >= scratchTables.length) {
//             const newScratchTable = await db.ScratchTable.create({ ...params, rng });
//             createdRecords.push(newScratchTable);
//         } else {
//             const scratchTable = scratchTables[i];
//             Object.assign(scratchTable, { ...params, rng });
//             await scratchTable.save();
//             createdRecords.push(scratchTable);
//         }
//         currentRange += odds;
//     }
//     if (paramsArray.length < scratchTables.length) {
//         const rowsToDelete = scratchTables.slice(paramsArray.length);
//         for (const scratchTable of rowsToDelete) {
//             await scratchTable.destroy();
//         }
//     }
//     res.json({ message: 'Success', data: createdRecords });
// }


async function updateHandler(req, res, next) {
    const paramsArray = req.body;
    const createdRecords = [];
    const totalOdds = paramsArray.reduce((sum, item) => sum + parseFloat(item.odds_of_price), 0);
    const rangeEnd = 10000000;

    let currentRangeStart = 1;
    let currentRangeEnd = 0;
    let previousRngEnd = 0;

    try {
        let scratchTables = await db.ScratchTable.findAll({ where: { scratchCardId: paramsArray[0].scratchCardId } });

        if (!scratchTables || scratchTables.length === 0) {
            throw new Error('ScratchTable not found');
        }

        for (let i = 0; i < paramsArray.length; i++) {
            const params = paramsArray[i];
            const odds = parseFloat(params.odds_of_price);
            const oddsPercentage = (odds / totalOdds) * rangeEnd;

            const previousRangeEnd = currentRangeEnd;
            currentRangeStart = previousRangeEnd + 1;
            currentRangeEnd = currentRangeStart + Math.floor(oddsPercentage) - 1;

            if (currentRangeEnd === previousRangeEnd) {
                currentRangeEnd++;
            }

            let rng = currentRangeStart === currentRangeEnd ? currentRangeStart.toString() : `${currentRangeStart}-${currentRangeEnd}`;

            if (odds === 0) {
                rng = '0';
                currentRangeStart = previousRngEnd + 1;
                currentRangeEnd = currentRangeStart + Math.floor(oddsPercentage) - 1;
            }

            if (i >= scratchTables.length) {
                const newRecord = await ScratchTableService.create({ ...params, rng });
                createdRecords.push(newRecord);
            } else {
                const scratchTable = scratchTables[i];
                Object.assign(scratchTable, { ...params, rng });
                await scratchTable.save();
                createdRecords.push(scratchTable);
            }

            previousRngEnd = currentRangeEnd;
        }

        if (paramsArray.length < scratchTables.length) {
            const rowsToDelete = scratchTables.slice(paramsArray.length);
            for (const scratchTable of rowsToDelete) {
                await scratchTable.destroy();
            }
        }

        res.json({ message: 'Success', data: createdRecords });
    } catch (error) {
        // Handle the error appropriately
        console.error(error);
        res.status(500).json({ error: 'An error occurred' });
    }
}




function deleteScratchTable(req, res, next) {
    const scratchCardId = req.params.scratchCardId;
    ScratchTableService._delete(scratchCardId)
        .then(data => res.json({ message: 'Deleted Successfully', data }))
        .catch(next);
}