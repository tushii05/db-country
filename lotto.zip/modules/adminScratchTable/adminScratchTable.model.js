const { DataTypes, literal } = require('sequelize');

module.exports = model;

function model(sequelize) {
    const attributes = {
        rng: { type: DataTypes.STRING, allowNull: true },
        odds_of_price: { type: DataTypes.STRING, allowNull: false },
        price: { type: DataTypes.STRING, allowNull: false },
        status: { type: DataTypes.TINYINT, allowNull: true, defaultValue: 0 },
    };
    const options = {
        defaultScope: {
            attributes: { exclude: [''] }
        },
        scopes: {
            withHash: { attributes: {}, }
        }
    };
    return sequelize.define('ScratchTable', attributes, options);
}