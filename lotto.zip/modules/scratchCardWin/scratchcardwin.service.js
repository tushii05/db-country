const db = require('../../_helpers/db');
const { Sequelize, literal } = require('sequelize');
const { Op } = require("sequelize");

module.exports = {
    getAll,
    getById,
    create,
    update,
    _delete
};

async function getAll({ offset = 0, orderBy = 'id', orderType = 'ASC' }) {
    return await db.scratchCardWin.findAndCountAll({
        offset: parseInt(offset),
        order: [[orderBy, orderType]]
    });
}

async function getById(id) {
    return await getCurrency(id);
}



async function create(params) {
    const scratchCards = params.scratchCards.split(','); // Split the scratchCards string into an array using comma as the delimiter
    const scratchCardWinArray = [];
    for (let i = 0; i < scratchCards.length; i++) {
        const scratchcardNumber = i + 1;
        const data = await db.scratchCardWin.create({ ...params, scratchcardNumber, scratchCards: scratchCards[i] });
        scratchCardWinArray.push(data);
    }
    return scratchCardWinArray;
}



async function update(id, params) {
    const scratchCardWin = await db.scratchCardWin.findOne({ where: { id: id } });
    if (!scratchCardWin) throw 'scratchCardWin not found';

    if (scratchCardWin.dailyStatus > 0) {
        scratchCardWin.dailyStatus -= 1;
    }

    Object.assign(scratchCardWin, params);
    return await scratchCardWin.save();
}

// Helper Functions

async function getCurrency(id) {
    const scratchCardWin = await db.scratchCardWin.findByPk(id);
    if (!scratchCardWin) throw 'scratchCardWin not found';
    return scratchCardWin;
}

async function _delete(id) {
    const scratchCardWin = await db.scratchCardWin.findOne({ where: { id: id } });
    if (scratchCardWin) {
        await scratchCardWin.destroy();
        return true;
    }
}