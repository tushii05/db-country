const db = require('../../_helpers/db')
const express = require('express');
const router = express.Router();
const { sendEmail } = require('../../_middleware/email');
const notificationService = require('./notification.service');

// Send email to multiple recipients
router.post('/send', sendEmailHandler);
router.post('/send/all', sendEmailToAllUsers);
router.get("/mail", getAll, getAllSchema);

module.exports = router;

async function sendEmailHandler(req, res) {
    const { to, subject, text } = req.body;

    try {
        await sendEmail(to, subject, text);
        const email = await db.Notification.create({
            to: to,
            subject: subject,
            text: text,
            status: 'sent',
        });
        res.status(200).json({ message: 'Email sent successfully!', email });
    } catch (err) {
        res.status(500).json({ message: 'Error sending email' });
    }
};

async function sendEmailToAllUsers(req, res) {
    try {
        const { subject, text } = req.body;
        const subscribers = await db.Subscribe.findAll({ attributes: ['mail'] });
        const emails = subscribers.map(subscriber => subscriber.mail);
        const emailPromises = emails.map(async (email) => {
            try {
                await sendEmail(email, subject, text);
                return { email, status: 'sent' };
            } catch (err) {
                return { email, status: 'error' };
            }
        });
        const results = await Promise.all(emailPromises);
        const successes = results.filter(result => result.status === 'sent');
        const errors = results.filter(result => result.status === 'error');
        res.status(200).json({
            message: 'Emails sent successfully!',
            successes,
            errors
        });
    } catch (err) {
        res.status(500).json({ message: 'Error sending email' });
    }
};


function getAll(req, res, next) {
    notificationService.getAll(req.query)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}


function getAllSchema(req, res, next) {
    const schema = Joi.object({
        offset: Joi.number().integer().min(0).empty(''),
        limit: Joi.number().integer().min(1).empty(''),
        orderBy: Joi.string().valid('id', 'createdAt').empty(''),
        orderType: Joi.string().valid('DESC', 'ASC').empty(''),
        search: Joi.string().empty(''),
    });
    validateRequest(req, next, schema);
}