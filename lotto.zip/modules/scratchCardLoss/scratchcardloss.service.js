const db = require('../../_helpers/db');
const { Sequelize, literal } = require('sequelize');
const { Op } = require("sequelize");


module.exports = {
    getAll,
    getById,
    create,
    update,
    updateStatus,
    _delete
};

async function getAll({ offset = 0, orderBy = 'id', orderType = 'ASC' }) {
    return await db.scratchCardLoss.findAndCountAll({
        offset: parseInt(offset),
        order: [[orderBy, orderType]]
    });
}

async function getById(id) {
    return await getCurrency(id);
}


async function create(params) {
    const scratchCards = params.scratchCards.split(',');
    const scratchCardLossArray = [];
    for (let i = 0; i < scratchCards.length; i++) {
        const scratchcardNumber = i + 1;
        const data = await db.scratchCardLoss.create({ ...params, scratchcardNumber, scratchCards: scratchCards[i] });
        scratchCardLossArray.push(data);
    }
    return scratchCardLossArray;
}



async function update(id, params) {
    const scratchCardLoss = await db.scratchCardLoss.findOne({ where: { id: id } });
    if (!scratchCardLoss) throw 'scratchCardLoss not found';

    if (scratchCardLoss.dailyStatus > 0) {
        scratchCardLoss.dailyStatus -= 1;
    }

    Object.assign(scratchCardLoss, params);
    return await scratchCardLoss.save();
}

// Helper Functions

async function getCurrency(id) {
    const scratchCardLoss = await db.scratchCardLoss.findByPk(id);
    if (!scratchCardLoss) throw 'scratchCardLoss not found';
    return scratchCardLoss;
}

async function _delete(id) {
    const scratchCardLoss = await db.scratchCardLoss.findOne({ where: { id: id } });
    if (scratchCardLoss) {
        await scratchCardLoss.destroy();
        return true;
    }
}

async function updateStatus(id) {
    const updateParams = { status: 0 };
    const [affectedRows] = await db.scratchCardLoss.update(updateParams, { where: { scratchCardId: id } });
    if (affectedRows === 0) {
        return null;
    }
    const scratchCardLosses = await db.scratchCardLoss.findAll({ where: { scratchCardId: id } });
    for (const scratchCardLoss of scratchCardLosses) {
        scratchCardLoss.dailyStatus += 1;
        await scratchCardLoss.save();
    }
    return scratchCardLosses;
}