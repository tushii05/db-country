const express = require('express');
const router = express.Router();
const Joi = require('joi');
const { validateRequest } = require('../../_middleware/validate-request');
const scratchCardLossService = require('./scratchcardloss.service');
module.exports = router;

router.get('/', getAllSchema, getAll);
router.post('/store', storeSchema, store);
router.get('/:id', getById);
router.put('/:id', update);
router.put('/status/:scratchCardId', updateStatus);
module.exports = router;

function getAllSchema(req, res, next) {
    const schema = Joi.object({
        offset: Joi.number().integer().min(0).empty(''),
        limit: Joi.number().integer().min(1).empty(''),
        orderBy: Joi.string().valid('id', 'createdAt').empty(''),
        orderType: Joi.string().valid('DESC', 'ASC').empty(''),
        search: Joi.string().empty(''),
    });
    validateRequest(req, next, schema, 'query');
}

function getAll(req, res, next) {
    scratchCardLossService.getAll(req.query)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function store(req, res, next) {
    scratchCardLossService.create(req.body)
        .then(data => { res.json({ message: 'Success', data }) })
        .catch(next);
}


function storeSchema(req, res, next) {
    const schema = Joi.object({
        UserId: Joi.number().integer().required(),
        scratchCardId: Joi.number().integer().required(),
        scratchCards: Joi.string().empty(''),
    });
    validateRequest(req, next, schema);
}

function getById(req, res, next) {
    scratchCardLossService.getById(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function update(req, res, next) {
    scratchCardLossService.update(req.params.id, req.body)
        .then(data => res.json({ message: 'Update Success', data }))
        .catch(next);
}

function updateStatus(req, res, next) {
    const scratchCardId = req.params.scratchCardId; // Access scratchCardId from query parameter
    scratchCardLossService.updateStatus(scratchCardId)
        .then(() => res.json({ message: 'Update Success' }))
        .catch(next);
}