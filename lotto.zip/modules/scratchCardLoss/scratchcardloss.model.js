const { DataTypes, literal } = require('sequelize');

module.exports = model;

function model(sequelize) {
    const attributes = {
        scratchCards: { type: DataTypes.STRING, allowNull: false },
        prize: { type: DataTypes.INTEGER, allowNull: true, defaultValue: 0 },
        status: { type: DataTypes.TINYINT, allowNull: false, defaultValue: 0 },
        dailyStatus: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 1 },
    };
    const options = {
        defaultScope: {

            attributes: { exclude: [''] }
        },
        scopes: {
            // include hash with this scope
            withHash: { attributes: {}, }
        }
    };

    return sequelize.define('scratchCardLoss', attributes, options);
}