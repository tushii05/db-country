const db = require('../../_helpers/db');
const { Op } = require("sequelize");
const { commissionRandomNo } = require("../../_middleware/random-number");


module.exports = {
    getAll,
    getById,
    create,
    update,
    _delete
};


async function getAll({ offset = 0, orderBy = 'id', orderType = 'ASC', search = null }) {
    let where = {};
    if (search !== null) {
        where = {
            [Op.or]: [
                { to_id: { [Op.like]: `%${search}%` } },
                { from_id: { [Op.like]: `%${search}%` } }
            ]
        }
    }
    return await db.Commission.findAndCountAll({
        where,
        offset: parseInt(offset),
        order: [[orderBy, orderType]],
        include: [{
            model: db.User,
            as: 'User',
            attributes: ['id', 'username', 'email', "fname", "lname"]
        }]
    });
}


async function getById(id) {
    return await getCommission(id);
}



// Automatic Calculate Value of amount 

async function create(params) {
    params.randomNo = await commissionRandomNo();

    if (params.percent && params.main_amount) {
        const commissionAmount = parseFloat((params.percent / 100) * params.main_amount);
        params.amount = commissionAmount.toFixed(2);
    }

    const commission = await db.Commission.create(params);
    if (params.from_id) {
        const user = await db.User.findOne({ where: { id: params.from_id } });
        if (user) {
            const commissionBalance = parseFloat(user.commission_balance || 0);
            const newCommissionBalance = commissionBalance + parseFloat(params.amount || 0);
            await user.update({ commission_balance: newCommissionBalance.toFixed(2) });
        }
    }
    return commission;
}



async function update(id, params) {
    const Commission = await db.Commission.findOne({ where: { id: id } });
    if (!Commission) throw 'Commission not found'
    Object.assign(Commission, params);
    return await Commission.save();
}

// Helper Functions

async function getCommission(id) {
    const Commission = await db.Commission.findByPk(id);
    if (!Commission) throw 'Commission not found';
    return Commission;
}

async function _delete(id) {
    const Commission = await db.Commission.findOne({ where: { id: id } });
    if (Commission) {
        await Commission.destroy();
        return true;
    }
}
