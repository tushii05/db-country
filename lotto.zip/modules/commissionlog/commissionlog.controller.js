const express = require('express');
const router = express.Router();
const Joi = require('joi');
const { validateRequest } = require('../../_middleware/validate-request');
const commissionService = require('./commissionlog.service');

router.get('/', getAllSchema, getAll);
router.post('/store', storeSchema, store);
router.get('/:id', getById);
router.put('/:id', update);
router.delete('/:id', _delete);
module.exports = router;

function getAllSchema(req, res, next) {
    const schema = Joi.object({
        offset: Joi.number().integer().min(0).empty(''),
        limit: Joi.number().integer().min(1).empty(''),
        orderBy: Joi.string().valid('id', 'createdAt').empty(''),
        orderType: Joi.string().valid('DESC', 'ASC').empty(''),
        search: Joi.string().empty(''),
    });
    validateRequest(req, next, schema, 'query');
}

function getAll(req, res, next) {
    commissionService.getAll(req.query)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function store(req, res, next) {
    const params = { ...req.body, UserId: req.body.from_id };
    commissionService.create(params)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function storeSchema(req, res, next) {
    const schema = Joi.object({
        to_id: Joi.number().required(),
        from_id: Joi.number().required(),
        level: Joi.number().required(),
        percent: Joi.number().required(),
        main_amount: Joi.number().required(),
        commission_type: Joi.string().required(),
        UserId: Joi.number().empty(''),
    });
    validateRequest(req, next, schema);
}

function getById(req, res, next) {
    commissionService.getById(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function update(req, res, next) {
    commissionService.update(req.params.id, req.body)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}

function _delete(req, res, next) {
    commissionService._delete(req.params.id)
        .then(data => res.json({ message: 'Success', data }))
        .catch(next);
}
