const { DataTypes, literal } = require('sequelize');

module.exports = model;

function model(sequelize) {
    const attributes = {
        to_id: { type: DataTypes.INTEGER, allowNull: false },
        from_id: { type: DataTypes.INTEGER, allowNull: false },
        level: { type: DataTypes.INTEGER, allowNull: false },
        UserId: { type: DataTypes.INTEGER, allowNull: false },
        percent: { type: DataTypes.INTEGER, allowNull: false },
        randomNo: { type: DataTypes.STRING, allowNull: true },
        amount: { type: DataTypes.DOUBLE, allowNull: false },
        main_amount: { type: DataTypes.DOUBLE, allowNull: false },
        commission_type: { type: DataTypes.STRING, allowNull: false },
    };

    const options = {
        defaultScope: {
            // exclude hash by default
            attributes: { exclude: [''] }
        },
        scopes: {
            // include hash with this scope
            withHash: { attributes: {}, }
        }
    };

    return sequelize.define('CommissionLog', attributes, options);
}