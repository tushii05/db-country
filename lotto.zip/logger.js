// const winston = require('winston');

// var options = {
//     console: {
//         level: 'debug',
//         handleExceptions: true,
//         json: false,
//         colorize: true,
//     },
//     file: {
//         level: 'info',
//         filename: 'logs.log',
//         handleExceptions: true,
//         json: true,
//         maxsize: 5242880, // 5MB
//         maxFiles: 5,
//         colorize: false,
//     },
// };


// const logger = winston.createLogger({
//     format: winston.format.combine(
//         winston.format.timestamp(),
//         winston.format.json()
//     ), transports: [
//         new winston.transports.File(options.file),
//         new winston.transports.Console(options.console),
//         new winston.transports.File({ filename: 'error.log', level: 'error' }),
//         new winston.transports.File({ filename: 'logs.log', level: 'info' })
//     ],
//     exitOnError: false,

// });


// module.exports = logger;


const winston = require('winston');

const options = {
    console: {
        level: 'debug',
        handleExceptions: true,
        format: winston.format.combine(
            winston.format.colorize(),
            winston.format.simple()
        )
    },
    file: {
        level: 'info',
        filename: 'logs.log',
        handleExceptions: true,
        maxsize: 5242880, // 5MB
        maxFiles: 5,
        format: winston.format.json()
    },
};

const logger = winston.createLogger({
    transports: [
        new winston.transports.File(options.file),
        new winston.transports.Console(options.console),
        new winston.transports.File({ filename: 'error.log', level: 'error' }),
        new winston.transports.File({ filename: 'logs.log', level: 'info' })
    ],
    exitOnError: false
});

module.exports = { logger };



// const fs = require('fs');

// function logError(err, message) {
//     const timestamp = new Date().toISOString();
//     const logMessage = `${timestamp} - ${err.message} - ${message}\n`;

//     // Append log message to a log file
//     fs.appendFile('cron_job.log', logMessage, (error) => {
//         if (error) {
//             console.error('Error writing to log file:', error);
//         }
//     });
// }

// module.exports = {
//     logError
// };
