const cron = require('node-cron');
const axios = require('axios');
const { Op } = require('sequelize');
const db = require('./_helpers/db');


const updateScratchcardStatus = async () => {
    try {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const year = today.getFullYear().toString();
        const month = (today.getMonth() + 1).toString().padStart(2, '0');
        const day = today.getDate().toString().padStart(2, '0');
        const todayString = `${year}-${month}-${day}`;
        const scratchcards = await db.scratchCard.findAll({ where: { endDate: todayString } });
        for (const scratchcard of scratchcards) {
            scratchcard.status = 0;
            await scratchcard.save();
        }


        console.log('Scratchcard statuses updated successfully.');
    } catch (error) {
        console.error('Error updating scratchcard statuses:', error);
    }
};

cron.schedule('0 0 0 * * *', updateScratchcardStatus);

const cronSchedule = '*/60 * * * * *';


const cronJob = cron.schedule(cronSchedule, async () => {
    try {
        const currentTime = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: false, timeZone: 'Etc/UTC' });
        const scratchCards = await db.scratchCard.findAll();
        const dataValuesArray = scratchCards.map((scratchCard) => scratchCard.dataValues);

        // console.log(currentTime,'currentTime')
        for (const scratchCard of dataValuesArray) {
            const frequencyArr = JSON.parse(scratchCard.frequency.replace(/\\/g, ''));

            for (const freq of frequencyArr) {
                switch (freq.frequency) {
                    case 'Monthly':
                        if (currentTime === scratchCard.startTime && isScheduledDate(freq.schedule)) {
                            await makeApiHit(scratchCard.id);
                        }
                        break;
                    case 'Weekly':
                        if (currentTime === scratchCard.startTime && isScheduledDay(freq.schedule)) {
                            await makeApiHit(scratchCard.id);
                        }
                        break;
                    case 'Daily':
                        if (currentTime === scratchCard.startTime) {
                            await makeApiHit(scratchCard.id);
                        }
                        break;
                    default:
                        console.error(`Invalid frequency: ${freq.frequency}`);
                }
            }
        }
    } catch (error) {
        console.error('Error processing scratch cards:', error);
    }
});

async function makeApiHit(scratchCardId) {
    try {
        const apiUrl4 = `${process.env.ASSET_URL}/api/cardscratch/scratch-card/play`
        const apiUrl1 = `${process.env.ASSET_URL}/api/cardscratch/store`;
        const apiUrl2 = `${process.env.ASSET_URL}/api/scratchcardplay/${scratchCardId}`;
        // const apiUrl3 = `${process.env.ASSET_URL}/api/scratchcardloss/status/${scratchCardId}`

        const requestBody = {
            scratchCardId: scratchCardId
        };

        const response4 = await axios.post(apiUrl4, requestBody);
        console.log(`API 4 response for scratchCardId ${scratchCardId}(API 4):`, response4.data);

        const response = await axios.put(apiUrl1, requestBody);
        console.log(`API 1 response for scratchCardId ${scratchCardId}(API 1):`, response.data);

        const response2 = await axios.put(apiUrl2);
        console.log(`API 2 response for scratchCardId ${scratchCardId} (API 2):`, response2.data);

        // const response3 = await axios.put(apiUrl3);
        // console.log(`API response for scratchCardId ${scratchCardId} (API 3):`, response3.data);

    } catch (error) {
        console.error(`Error hitting API for scratchCardId ${scratchCardId}:`, error);
    }
}

function isScheduledDate(schedule) {
    const currentDateTime = new Date();
    const scheduledDate = parseInt(schedule);
    const scheduledDateTime = new Date(currentDateTime.getFullYear(), currentDateTime.getMonth(), scheduledDate);
    return currentDateTime.toDateString() === scheduledDateTime.toDateString();
}


function isScheduledDay(schedule) {
    const currentDateTime = new Date();
    const currentDay = currentDateTime.toLocaleDateString('en-IN', { weekday: 'long' });
    return schedule.toLowerCase() === currentDay.toLowerCase();
}

cronJob.start();

module.exports = cronJob;