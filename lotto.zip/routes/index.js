var router = require('express').Router();

router.use('/admin', require('./../modules/admin/admin.controller'));

router.use('/user', require('./../modules/users/users.controller'));

router.use('/user-logs', require('./../modules/userloginlogs/userloginlogs.controller'));

router.use('/transaction', require('./../modules/usertransaction/usertransaction.controller'));

router.use('/currency', require('./../modules/currency/currency.controller'));

router.use('/gameinfo', require('./../modules/gameinfo/gameinfo.controller'));

router.use('/gamephase', require('./../modules/gamephase/gamephase.controller'));

router.use('/timezone', require('./../modules/timezone/timezone.controller'));

router.use('/scratchcard', require('./../modules/scratchcard/scratchcard.controller'));

router.use('/winner-tickets', require('./../modules/winnerticket/winnerticket.controller'));

router.use('/user-referral', require('./../modules/userreferal/userreferal.controller'));

router.use('/support-tickets', require('./../modules/supportticket/supportticket.controller'));

router.use('/ticket-message', require('./../modules/supportticketmessage/supportticketmessage.controller'));

router.use('/ticket-attachment', require('./../modules/supportticketattachment/supportticketattachment.controller'));

router.use('/buytickets', require('../modules/buyticket/buyticket.controller'));

router.use('/mail', require('../modules/sendemail/sendemail.controller'));

router.use('/lotterygenerat', require('../modules/lotterygenerat/lotterygenerat.controller'));

router.use('/scratchgenerat', require('../modules/scratchgeneratno/scratchgeneratno.controller'));

router.use('/map', require('../modules/countrystatecity/countrystatecity.controller'));

router.use('/countries', require('../modules/countries/countries.controller'));

router.use('/states', require('../modules/state/states.controller'));

router.use('/city', require('../modules/city/city.controller'));

router.use('/stripe', require('../modules/stripe/stripe.controller'));

router.use('/contact', require('../modules/contactus/contactus.controller'));

router.use('/subscribe', require('../modules/subscribe/subscribe.controller'));

router.use('/notification', require('../modules/notification/notification.controller'));

router.use('/usernotification', require('../modules/usernotification/usernotification.controller'));

router.use('/withdrawals', require('../modules/withdrawals/withdrawals.controller'));

router.use('/commission', require('../modules/commissionlog/commissionlog.controller'));

router.use('/scratchtable', require('../modules/adminScratchTable/adminScratchTable.controller'));

router.use('/scratchcardplay', require('../modules/scratchcardplay/scratchcardplay.controller'));

router.use('/scratchcardwin', require('../modules/scratchCardWin/scratchcardwin.controller'));

router.use('/scratchcardloss', require('../modules/scratchCardLoss/scratchcardloss.controller'));

router.use('/cardscratch', require('../modules/cardScratch/cardscratch.controller'));

router.use('/coinbase', require('../modules/CoinbaseCommerce/Coinbase'))

module.exports = router;