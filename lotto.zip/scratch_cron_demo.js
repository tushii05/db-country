// const cron = require('node-cron');
// const axios = require('axios');
// const { Op } = require('sequelize');
// const db = require('./_helpers/db');

// const cronSchedule = '*/60 * * * * *';  // Runs 60 sec

// // const cronSchedule = '0 0 1 1 * *'; // Runs once a year on January 1st at 12:00 AM


// // Define the cron job
// const cronJob = cron.schedule(cronSchedule, async () => {
//     try {
//         // Get the current time
//         const currentTime = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', timeZone: 'IST' });
//         console.log(currentTime)
//         const currentTimeWithoutSeconds = currentTime.slice(0, -3);


//         // console.log(currentTimeWithoutSeconds)
//         // Fetch all scratch cards
//         const scratchCards = await db.scratchCard.findAll();
//         // console.log(scratchCards)
//         for (const scratchCard of scratchCards) {
//             const frequencyArr = JSON.parse(scratchCard.frequency.replace(/\\/g, ''));
//             // console.log(frequencyArr)

//             for (const freq of frequencyArr) {
//                 switch (freq.frequency) {
//                     case 'Monthly':
//                         if (currentTimeWithoutSeconds === scratchCard.startTime && isScheduledDate(freq.schedule)) {
//                             await makeApiHit(scratchCard.id);
//                         }

//                         break;
//                     case 'Weekly':
//                         if (currentTimeWithoutSeconds === scratchCard.startTime && isScheduledDay(freq.schedule)) {
//                             await makeApiHit(scratchCard.id);
//                         }

//                         break;
//                     case 'Daily':
//                         if (currentTimeWithoutSeconds === scratchCard.startTime) {
//                             await makeApiHit(scratchCard.id);
//                         }

//                         break;
//                     default:
//                         console.error(`Invalid frequency: ${freq.frequency}`);
//                 }
//                 // console.log(scratchCard.startTime, freq.schedule)
//             }
//         }
//     } catch (error) {
//         console.error('Error processing scratch cards:', error);
//     }
// });

// async function makeApiHit(scratchCardId) {
//     try {
//         const apiUrl1 = 'http://localhost:5000/api/cardscratch/store';
//         const apiUrl2 = `http://localhost:5000/api/scratchcardplay/${scratchCardId}`;
//         const apiUrl3 = `http://localhost:5000/api/scratchcardloss/status/${scratchCardId}`
//         const requestBody = {
//             scratchCardId: scratchCardId
//         };
//         const response = await axios.put(apiUrl1, requestBody);
//         console.log(`API response for scratchCardId ${scratchCardId} (API 1)::`, response.data);

//         const response2 = await axios.put(apiUrl2);
//         console.log(`API response for scratchCardId ${scratchCardId} (API 2):`, response2.data);

//         const response3 = await axios.put(apiUrl3);
//         console.log(`API response for scratchCardId ${scratchCardId} (API 3):`, response3.data);

//     } catch (error) {
//         console.error(`Error hitting API for scratchCardId ${scratchCardId}:`, error);
//     }
// }

// function isScheduledDate(schedule) {
//     const currentDate = new Date().getDate();
//     const scheduledDate = parseInt(schedule); // Convert the schedule to an integer
//     console.log(scheduledDate)
//     return currentDate === scheduledDate;
// }

// function isScheduledDay(schedule) {
//     const currentDay = new Date().toLocaleDateString('en-IN', { weekday: 'long' });
//     console.log(currentDay)
//     return schedule.toLowerCase() === currentDay.toLowerCase();
// }

// // Start the cron job
// cronJob.start();

// module.exports = cronJob;


const cron = require('node-cron');
const axios = require('axios');
const { Op } = require('sequelize');
const db = require('./_helpers/db');

const cronSchedule = '*/60 * * * * *';  // Runs 60 sec

// const cronSchedule = '0 0 1 1 * *'; // Runs once a year on January 1st at 12:00 AM


const cronJob = cron.schedule(cronSchedule, async () => {
    try {
        const currentTime = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: false, timeZone: 'IST' });
        const scratchCards = await db.scratchCard.findAll();
        // console.log(currentTime)
        for (const scratchCard of scratchCards) {

            const frequencyArr = JSON.parse(scratchCard.frequency.replace(/\\/g, ''));
            // console.log(frequencyArr)

            for (const freq of frequencyArr) {
                switch (freq.frequency) {
                    case 'Monthly':
                        if (currentTime === scratchCard.startTime && isScheduledDate(freq.schedule)) {
                            await makeApiHit(scratchCard.id);
                        }
                        break;
                    case 'Weekly':
                        if (currentTime === scratchCard.startTime && isScheduledDay(freq.schedule)) {
                            await makeApiHit(scratchCard.id);
                        }
                        break;
                    case 'Daily':
                        if (currentTime === scratchCard.startTime) {
                            await makeApiHit(scratchCard.id);
                        }
                        break;
                    default:
                        console.error(`Invalid frequency: ${freq.frequency}`);
                }
            }
        }
    } catch (error) {
        console.error('Error processing scratch cards:', error);
    }
});

async function makeApiHit(scratchCardId) {
    try {
        const apiUrl4 = `${process.env.ASSET_URL}/api/cardscratch/scratch-card/play`
        const apiUrl1 = `${process.env.ASSET_URL}/api/cardscratch/store`;
        const apiUrl2 = `${process.env.ASSET_URL}/api/scratchcardplay/${scratchCardId}`;
        // const apiUrl3 = `${process.env.ASSET_URL}/api/scratchcardloss/status/${scratchCardId}`

        const requestBody = {
            scratchCardId: scratchCardId
        };

        const response4 = await axios.post(apiUrl4, requestBody);
        console.log(`API response for scratchCardId ${scratchCardId}(API 4):`, response4.data);

        const response = await axios.put(apiUrl1, requestBody);
        console.log(`API response for scratchCardId ${scratchCardId}(API 1):`, response.data);

        const response2 = await axios.put(apiUrl2);
        console.log(`API response for scratchCardId ${scratchCardId} (API 2):`, response2.data);

        // const response3 = await axios.put(apiUrl3);
        // console.log(`API response for scratchCardId ${scratchCardId} (API 3):`, response3.data);

    } catch (error) {
        console.error(`Error hitting API for scratchCardId ${scratchCardId}:`, error);
    }
}

function isScheduledDate(schedule) {
    const currentDateTime = new Date();
    const scheduledDate = parseInt(schedule);
    const scheduledDateTime = new Date(currentDateTime.getFullYear(), currentDateTime.getMonth(), scheduledDate);
    return currentDateTime.toDateString() === scheduledDateTime.toDateString();
}


function isScheduledDay(schedule) {
    const currentDateTime = new Date();
    const currentDay = currentDateTime.toLocaleDateString('en-IN', { weekday: 'long' });
    return schedule.toLowerCase() === currentDay.toLowerCase();
}

cronJob.start();

module.exports = cronJob;