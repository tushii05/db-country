const axios = require('axios');
const moment = require("moment-timezone");
const mysql = require('mysql2');
const nodemailer = require('nodemailer');

const pool = mysql.createPool({
    host: "localhost",
    user: "root",
    database: "lotto",
    password: "",
});
const db = pool.promise();

// console.log(db)


//Common Functions
function arrayIntersect(arr1, arr2) {
    const set = new Set(arr2);
    return arr1.filter((value) => set.has(value));
}

function inArray(needle, haystack) {
    return haystack.includes(needle);
}


function searchForId(search_value, array, id_path) {
    // console.log(array, "array")
    // console.log(id_path, "id_path")
    // console.log(search_value, "search_value")
    for (let key1 in array) {
        let val1 = array[key1];
        // console.log(val1, "val1"); break;

        let temp_path = [...id_path];
        if (typeof val1.info === "object" && Object.keys(val1.info)) {
            for (let key2 in val1.info) {
                let val2 = val1.info[key2];
                if (val2 === search_value) {
                    // console.log(val2, "val2");break;
                    temp_path.push(val1);
                    return temp_path[0];
                }
            }
        } else if (val1.info === search_value) {
            temp_path.push({});
            return temp_path;
        }
    }
    return null;
}


async function sendMail(to, toName, subject, message) {
    try {
        let transporter = nodemailer.createTransport({
            host: 'smtp.hostinger.com',
            port: 465,
            secure: true,
            auth: {
                user: 'support@creativewebsoft.in',
                pass: 'Creative@s430',
            },
        });

        let info = await transporter.sendMail({
            from: '"Agnito Technologies" <support@creativewebsoft.in>',
            to: `${toName} <${to}>`,
            subject: subject,
            html: message,
        });

        console.log('Message sent: %s', info.messageId);
    } catch (error) {
        console.log('Error occurred: ', error);
    }
}

// const winner = await postWinner(Number(phase.lottery_id), ticket?.UserId, Number(phase.phase_id), numbers[nums], game_data.frequency)

const postWinner = async (lottery, UserId, phase, tickets, frequency) => {

    const requestBody = {
        gameInformationId: lottery,
        UserId: UserId,
        gamePhaseId: phase,
        ticketNumber: tickets,
        frequency: frequency
    };

    const response = await axios.post("http://159.223.51.198:5000/api/winner-tickets/store", requestBody).
        then((res) => { return res.data })
        .catch((error) => {
            console.error('ErrorFace:', error.message)
        })
    console.log("response", response)


    return response
}


const postWinTransaction = async (prize, UserId, tickets, name) => {

    const requestBody = {
        userId: UserId,
        amount: prize,
        tickets: tickets,
        currency: 'usd',
        transactionType: 'Winning',
        description: `Winning from ${name} of ${tickets} `
    };

    const response = await axios.post("http://159.223.51.198:5000/api/transaction/store/win", requestBody).
        then((res) => { return res.data })
        .catch((error) => {
            console.error('ErrorFace:', error.message)
        })
    console.log("response", response)


    return response
}
// postWinTransaction();


const postWinCommissionTransaction = async (combody) => {
    const response = await axios.post("http://159.223.51.198:5000/api/transaction/commission/store", combody).
        then((res) => { return res.data })
        .catch((error) => {
            console.error('ErrorFace:', error.message)
        })
    console.log("response", response)


    return response
}

async function CreateCommissionLog(body) {
    try {
        const response = await axios.post("http://159.223.51.198:5000/api/commission/store", body);
        console.log('Response:', response.data);
    } catch (error) {
        console.error('ErrorFace:', error.message);
    }
}


async function getCommission(winAmount, id) {
    const apiResponse = await axios.get(
        `http://159.223.51.198:5000/api/user-referral`
    );

    const apiResponse1 = await axios.get(
        `http://159.223.51.198:5000/api/user/refer/${id}`
    );
    const refer_by = apiResponse1.data.data.user.refer_by;
    const username = apiResponse1.data.data.user.userName;
    const apiResponse2 = await axios.get(
        `http://159.223.51.198:5000/api/user/transaction/${id}`
    );
    const winLength = apiResponse2.data.data.winning.length - 1;
    // const winLength = 1;
    // console.log(refer_by, "refer_by")

    // console.log(winLength, "winLength")
    const apiRandomNumber = apiResponse.data;
    const filtered = apiRandomNumber?.data?.filter((per) => {
        return per.commission_type === "win";
    });
    const percent = filtered?.map((per) => per.percent);
    const level = filtered?.map((per) => per.level).reverse();

    const commission = filtered?.map((per) => per.commission_type)
    const winStatus = filtered?.map((per) => per.status);
    // console.log(refer_by, percent, level, commission, winStatus, "percent,level,commission,winStatus");
    // console.log(refer_by !== 0 && winStatus[0] !== 0)
    let count = 0;
    if (refer_by !== 0 && winStatus[0] !== 0) {
        // console.log(winLength < level.length && count === 0, "jfdjfjdfjjl");
        // const handleCommission = async () => {
        if (winLength < level.length && count === 0) {
            const body = {
                to_id: Number(id),
                from_id: Number(refer_by),
                UserName: username,
                level: level[winLength],
                percent: percent[winLength],
                main_amount: winAmount,
                commission_type: "win",
            };
            // console.log(body);
            const res = await CreateCommissionLog(body);
            if (res) {
                const commissionAmount = parseFloat(
                    (percent[winLength] / 100) * winAmount
                ).toFixed(2);

                const combody = {
                    transactionType: "Commission",
                    amount: commissionAmount.toString(),
                    userId: +refer_by,
                    sender: "Commission",
                    receiver: "User",
                    description: "Commission win ",
                };
                const resCommissionTransactions = await postWinCommissionTransaction(combody);
                console.log("resCommissionTransactions", resCommissionTransactions);
            }
            // console.log(res3,"res3");
            count++;
            // console.log(userId);
        }
        // };
    }
}
// getCommission()




const main = async () => {
    // moment.tz.setDefault("Asia/Kolkata");
    const timezone = 'Asia/Kolkata';
    // const timezone = 'Etc/UTC';
    moment.tz.setDefault(timezone);

    const currentDate = new Date();
    console.log(currentDate, 'currentDate')

    const year = currentDate.getFullYear();
    const month = String(currentDate.getMonth() + 1).padStart(2, '0'); // Adding 1 and padding with leading zeros
    const day = String(currentDate.getDate()).padStart(2, '0'); // Padding with leading zeros

    const formattedDate = `${year}-${month}-${day}`;
    // console.log(formattedDate, 'formattedDate');

    const hours = String(currentDate.getHours()).padStart(2, '0');
    const minutes = String(currentDate.getMinutes()).padStart(2, '0');

    const formattedDateTime = `${hours}:${minutes}`;
    // console.log(formattedDateTime, "formattedDateTime");


    const current_day = moment().format('dddd').toLowerCase();
    // console.log(current_day)
    const current_date = moment().format("YYYY-MM-DD");
    console.log(current_date, 'current_date')
    // const current_date = "2023-07-19"//"2023-06-29";  //formattedDate;
    // console.log(current_date)
    const current_time = moment().format("HH:mm");
    console.log(current_time, 'current_time')
    // const current_time = "11:51"//"10:40"; // formattedDateTime
    console.log(current_time)
    const weekDaysArr = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
    // let lotteryData = [];

    try {
        let lotteryData = [];
        const [lotteries_qry] = await db.query(`
        select info.image as info_image, info.gameName as info_name, info.gameNumber as info_number, info.gameDuration as info_duration, info.maxNumberTickets as info_max_tickets, info.ticketPrice as info_ticket_price, info.minPrizePool as info_price_pool, info.startTime as info_time, info.id as info_id, info.sold as info_sold, info.nextDraw as info_next_draw, info.status as info_status, GROUP_CONCAT(ticketnos.number order by ticketnos.id) as ticket_numbers from gameInformations as info left join lotterygenerateNos as ticketnos on ticketnos.gameInformationId = info.id where info.status=1 group by info.id order by info.id DESC`);
        // const lotteries = lotteriesResult.map((lotteriesRow) => {
        //     return lotteriesRow;
        // });
        // const lotteries = [];
        // for (let i = 0; i < lotteries_qry.length; i++) {
        //     const lotteries_row = lotteries_qry[i];
        //     lotteries.push(lotteries_row);
        // }
        const lotteries = lotteries_qry.map(lotteries_row => lotteries_row);

        // console.log("first!!!!!!!!!!!!!!!!!!!");
        // console.log(lotteries, 'lotteries');


        // for (let lotteryIndex = 0; lotteryIndex < lotteries.length; lotteryIndex++) {
        //     const lottery = lotteries[lotteryIndex];
        const lottery_generate_number_data = [];
        // for (let key in lotteries) {
        //     let lottery = lotteries[key];
        await Promise.all(Object.keys(lotteries).map(async (key) => {
            let lottery = lotteries[key];
            // console.log(lottery)
            const [lottery_generate_number_qry] = await db.query(`select * from lotterygenerateNos where gameInformationId = "${lottery["info_id"]}" and status = 1`);
            lottery_generate_number_qry.forEach(lottery_generate_number_row => {
                lottery_generate_number_data.push(lottery_generate_number_row);
            })
            // console.log(lottery_generate_number_data,'lottery_generate_number_data')
            const [phases_qry] = await db.query(`select id as phase_id, game as phase_game, gameData as phase_game_data, status as phase_status, gameInformationId as lottery_id 
            from gamePhases as phase where status=1 and gameInformationId='${lottery["info_id"]}'`);
            const phases = [];

            const phasesData = [];
            // for (let phases_qryIndex = 0; phases_qryIndex < phases_qry.length; phases_qryIndex++) {
            //     const phases_row = phases_qry[phases_qryIndex];
            phases_qry.map(async (phases_row) => {
                //     // Your code logic here using `phases_row`


                // console.log(phases_row, 'phases_row');

                // console.log(lottery_generate_number_data.length * parseInt(lottery.info_ticket_price))
                // console.log(parseInt(lottery.info_price_pool))
                // console.log(lottery.info_time <= current_time)
                if (parseInt(lottery_generate_number_data.length) * parseInt(lottery.info_ticket_price) >= parseInt(lottery.info_price_pool) ||
                    lottery.info_time <= current_time) {
                    // console.log(parseInt(lottery_generate_number_data.length), "parseInt(lottery_generate_number_data.length)")
                    // console.log(parseInt(lottery.info_ticket_price),"parseInt(lottery.info_ticket_price)")
                    // console.log(parseInt(lottery.info_ticket_price),"lottery.info_ticket_price)") 
                    // console.log(parseInt(lottery.info_price_pool),"parseInt(lottery.info_price_pool)")

                    // console.log(lottery.info_time, "lottery.info_time", current_time, "current_time")

                    // console.log(phases_row.phase_game_data, 'phase_game_data_decode');

                    const phase_game_data_decode = JSON.parse(phases_row.phase_game_data);


                    // console.log(phase_game_data_decode, "phase_game_data_decode")
                    const phase_game_data = phase_game_data_decode.reduce((a, b) => {
                        return a.frequency < b.frequency ? a : b;
                    }, phase_game_data_decode.shift());
                    // console.log(phase_game_data.frequency, "phase_game_data")
                    //####
                    // console.log(phase_game_data, 'phase_game_data')
                    if (phase_game_data['frequency'] == 1) {
                        console.log("Daily")
                        // console.log(lottery["info_next_draw"] == 1)
                        if (lottery["info_next_draw"] == 1) {
                            // console.log(current_time, lottery["info_time"], lottery, "Helloooooooo")
                            console.log(current_time, "current_time", lottery.info_time, "lottery.info_time")

                            if (current_time <= lottery["info_time"]) {
                                // await db.query(`update gameInformations set gameDuration = '${current_date}' where id = '${lottery["info_id"]}'`);
                                await db.query(`update gameInformations set gameDuration = '${moment().format("YYYY-MM-DD")}' where id = ${lottery["info_id"]}`)
                                console.log("first")
                            } else {
                                await db.query(`update gameInformations set gameDuration = '${moment().add(1, 'day').format('YYYY-MM-DD')}'  where id = ${lottery["info_id"]}`);
                                console.log("2nd")
                                // await db.query(`update gameInformations set gameDuration = '${moment().add(1, 'day').format('YYYY-MM-DD')}'  where id = ${lottery["info_id"]}`);
                            }
                        } else {
                            await db.query(`update gameInformations set gameDuration = '${moment().format("YYYY-MM-DD")}', nextDraw = '1' where id = ${lottery["info_id"]}`)
                            console.log("3rd")
                            // await db.query(`update gameInformations set gameDuration = '${current_date}', nextDraw = '1' where id = ${lottery["info_id"]}`);
                        }

                    }
                    else if (phase_game_data['frequency'] == 2) {
                        // console.log(phase_game_data['frequency'] == 2);
                        console.log("Weekly");

                        // const weeklyDaysDate1 = [];
                        // const fetchWeekDays = [];
                        // for (let i = 0; i < phase_game_data.schedules.length; i++) {
                        //     fetchWeekDays.push(phase_game_data.schedules[i].value);
                        // }
                        const fetchWeekDays = phase_game_data.schedules.map((schedule) => schedule.value);
                        // console.log(fetchWeekDays,"fetchWeekDays");
                        const commonWeekDays = arrayIntersect(weekDaysArr, fetchWeekDays);
                        // const commonWeekDays = weekDaysArr.filter(day => fetchWeekDays.includes(day));

                        // console.log(lottery.info_time)

                        const weeklyDateArr = [];
                        if (commonWeekDays.includes(moment().format('dddd').toLowerCase())) { //66
                            // console.log(current_date, "!!!!!!!!!!!!!!!!!!!!");
                            // console.log(current_time <= lottery["info_time"], "current_time <= lottery.info_time");
                            if (current_time <= lottery["info_time"]) {
                                await db.query(`update gameInformations set gameDuration = "${current_date}" where id = "${lottery['info_id']}"`);

                            } else {
                                commonWeekDays.forEach(cwd => {
                                    const weeklyDate1 = moment().day(cwd).add(1, 'week').format('YYYY-MM-DD');
                                    weeklyDateArr.push(weeklyDate1);
                                });
                                // console.log(commonWeekDays, "weeklyDate1");
                                // const dateStr = `weeklyDateArr[0].format('YYYY-MM-DD')`; // Replace this with your actual date string

                                // const weeklyDate2 = moment(dateStr, 'YYYY-MM-DD').format('YYYY-MM-DD');
                                const weeklyDate2 = moment(weeklyDateArr[0]).format('YYYY-MM-DD');
                                // console.log(weeklyDate2, 'weeklyDate2')


                                if (weeklyDate2 > lottery["info_duration"]) { //75##
                                    await db.query(`update gameInformations set gameDuration = "${weeklyDate2}"where id = "${lottery['info_id']}"`);
                                } else {
                                    await db.query(`update gameInformations set gameDuration = "${weeklyDate2}", nextDraw = '1' where id = "${lottery['info_id']}"`)
                                }
                            }
                        } else {
                            console.log("2nd");
                            commonWeekDays.forEach(cwd => {
                                const weeklyDate3 = moment().day(cwd).add(1, 'week');
                                weeklyDateArr.push(weeklyDate3);
                            });
                            const weeklyDate4 = moment(weeklyDateArr[0]).format('YYYY-MM-DD');
                            // console.log(weeklyDate4, "weeklyDate4")
                            if (weeklyDate4 > lottery["info_duration"]) {
                                await db.query(`update gameInformations set gameDuration = "${weeklyDate4}" where id = ${lottery['info_id']}`)
                            } else {
                                // console.log("2nd");
                                await db.query(`update gameInformations set gameDuration = "${weeklyDate4}", nextDraw = '1' where id = "${lottery['info_id']}"`)
                            }
                            // }               
                        } //#91

                    } else if (phase_game_data['frequency'] == 3) {  //91###
                        console.log('Monthly');
                        // const fetchMonthDays = [];
                        // for (let j = 0; j < phase_game_data.schedules.length; j++) {
                        //     fetchMonthDays.push(phase_game_data.schedules[j].value);
                        // }
                        const fetchMonthDays = phase_game_data.schedules.map((schedule) => schedule.value);
                        // console.log(fetchMonthDays,"fetchMonthDays")
                        fetchMonthDays.sort();

                        const lastMonthDay = fetchMonthDays[fetchMonthDays.length - 1];

                        if (moment().date() > lastMonthDay) { //98##
                            console.log("first")
                            const currentDate = moment();
                            const nextMonth = currentDate.add(1, 'month').format('YYYY-MM');
                            const firstDayOfMonth = moment(nextMonth).startOf('month').format('YYYY-MM-DD');
                            const reachedMonthlyDate = `${firstDayOfMonth}-${fetchMonthDays[0].toString().padStart(2, '0')}`;
                            console.log(reachedMonthlyDate, 'reachedMonthlyDate');
                            if (lottery["info_next_draw"] == 1) {
                                await db.query(`update gameInformations set gameDuration = '${reachedMonthlyDate}' where id = "${lottery["info_id"]}"`)
                            } else {
                                await db.query(`update gameInformations set gameDuration = '${reachedMonthlyDate}', nextDraw = '1' where id = "${lottery["info_id"]}"`)
                            }
                        }
                        else if (fetchMonthDays.includes(moment().format('D'))) {//107##
                            console.log("2nd");
                            if (current_time <= lottery["info_time"]) {//108###
                                console.log("InTime")
                                const inTimeMonthlyDate = moment().format('YYYY-MM-DD');
                                if (lottery["info_next_draw"] == 1) {
                                    await db.query(`update gameInformations set gameDuration = '${inTimeMonthlyDate}' where id = "${lottery["info_id"]}"`);
                                } else {
                                    await db.query(`update gameInformations set gameDuration = '${inTimeMonthlyDate}', nextDraw = '1' where id = "${lottery["info_id"]}"`);
                                }
                            } else { //116###
                                const monthlyNextDay = moment().add(1, 'day').format('D');
                                const monthlyLastDay = moment().endOf('month').format('D');
                                const monthlyFoundDay = [];
                                fetchMonthDays.forEach((element) => {
                                    if (element >= monthlyNextDay && element <= monthlyLastDay) {
                                        monthlyFoundDay.push(element);
                                    }
                                });
                                if (monthlyFoundDay.length > 0) {//126###
                                    const monthlyFoundDate = moment().format('YYYY-MM') + '-' + (monthlyFoundDay[0].length === 1 ? '0' + monthlyFoundDay[0] : monthlyFoundDay[0]);

                                    if (lottery["info_next_draw"] == 1) {
                                        await db.query(`update gameInformations set gameDuration = '${monthlyFoundDate}' where id = "${lottery["info_id"]}"`);
                                    } else {
                                        await db.query(`update gameInformations set gameDuration = '${monthlyFoundDate}', nextDraw = '1' where id = "${lottery["info_id"]}"`);
                                    }
                                } else { //134
                                    const monthlyNotFoundDate = moment().add(1, 'month').startOf('month').format('YYYY-MM-') + (fetchMonthDays[0].length === 1 ? '0' + fetchMonthDays[0] : fetchMonthDays[0]);

                                    if (lottery["info_next_draw"] == 1) {
                                        await db.query(`update gameInformations set gameDuration = 
                                        '${monthlyNotFoundDate}' where id = "${lottery["info_id"]}"`)
                                    } else {
                                        await db.query(`update gameInformations set gameDuration = 
                                        '${monthlyNotFoundDate}', nextDraw = '1' where id = "${lottery["info_id"]}"`)
                                    }
                                }
                            }
                        }
                        else {//144##

                            console.log("Three  Nikal Gai");
                            const monthlyNextDay1 = moment().add(1, 'day').format('DD');
                            const monthlyLastDay1 = moment().endOf('month').format('D');
                            const monthlyFoundDay1 = [];
                            console.log(fetchMonthDays, "fetchMonthDays")

                            // fetchMonthDays.forEach((element) => {
                            //     if (element >= monthlyNextDay1 && element <= monthlyLastDay1) {
                            //         monthlyFoundDay1.push(element);
                            //         console.log(monthlyFoundDay1, "monthlyFoundDay1 inner 1");

                            //     }
                            //     console.log(monthlyFoundDay1, "monthlyFoundDay1 inner 2");

                            // });
                            for (const element of fetchMonthDays) {
                                if (element >= monthlyNextDay1 && element <= monthlyLastDay1) {
                                    monthlyFoundDay1.push(element);
                                    console.log(monthlyFoundDay1, "monthlyFoundDay1 inner 1");
                                }
                                console.log(monthlyFoundDay1, "monthlyFoundDay1 inner 2");
                            }
                            console.log(monthlyFoundDay1, "monthlyFoundDay1 out ");
                            const monthlyPostDate = moment().format('YYYY-MM-') + (monthlyFoundDay1[0].length === 1 ? '0' + monthlyFoundDay1[0] : monthlyFoundDay1[0]);
                            console.log(monthlyPostDate, "monthlyPostDate")
                            if (lottery["info_next_draw"] == 1) {
                                await db.query(`update gameInformations set gameDuration = '${monthlyPostDate}' where id = "${lottery["info_id"]}"`);
                                // console.log("Three  Nikal Gai !!!!!!!!!!!!!!!");
                            } else {
                                await db.query(`update gameInformations set gameDuration = '${monthlyPostDate}', nextDraw = '1' where id = "${lottery["info_id"]}"`)
                            }
                        }
                    }
                }
                phases.push(phases_row);
                // console.log(phases_row)

                // console.log(phases)
                // console.log(phases_row, "phase_row")
            });
            lotteryData.push({ "info": lottery, "phases": phases });
        }));
        // console.log(lotteryData, 'lotteryData1111111111');
        lotteryData = searchForId(current_time, lotteryData, []);
        // console.log("first")
        // console.log(lotteryData, 'lotteryData22222222222');

        if (lotteryData) {
            if ((lotteryData.info.info_next_draw) == 1) {
                const [buy_tickets_qry] = await db.query(`select * from BuyTickets where lotteryId = '${lotteryData.info.info_id}'`)
                // console.log(buy_tickets_qry);
                // let buyTicketsData = [];
                // for (let buy_tickets_qryIndex = 0; buy_tickets_qryIndex < buy_tickets_qry.length; buy_tickets_qryIndex++) {
                //     const currentBuyTicketData = buy_tickets_qry[buy_tickets_qryIndex];
                //     buyTicketsData.push(currentBuyTicketData);
                // }
                const buyTicketsData = buy_tickets_qry.map(currentBuyTicketData => currentBuyTicketData);


                // console.log(buyTicketsData, "buyTicketsData");
                let buyTicketsAmountArr = [];
                buyTicketsData.forEach((buyTicket) => {
                    buyTicketsAmountArr.push(parseInt(buyTicket.totalPrice));
                    // console.log(buyTicketsAmountArr,'buyTicketsAmountArr');break;
                });
                // buyTicketsAmount = reduce(buyTicketsAmountArr);

                // for (let lotteryDataIndex = 0; lotteryDataIndex < lotteryData.phases.length; lotteryDataIndex++) {
                //     const phase = lotteryData.phases[lotteryDataIndex];
                lotteryData.phases.map(async (phase) => {
                    const phase_game_data = JSON.parse(phase.phase_game_data);
                    // console.log(phase, "first");
                    // console.log(phase_game_data, 'phase_game_data');break;

                    // for (let phase_game_dataIndex = 0; phase_game_dataIndex < phase_game_data.length; phase_game_dataIndex++) {
                    //     const game_data = phase_game_data[phase_game_dataIndex];
                    phase_game_data.map(async (game_data) => {

                        // console.log(game_data, "game_data", game_data.frequency == 3)

                        if (game_data.frequency == 1) {
                            let numbers = lotteryData.info.ticket_numbers.split(",");
                            let winners = game_data.winners;
                            // let nuGetArray = [];
                            if (winners != 0) {
                                let nuGet = [];
                                if (winners == 1) {
                                    nuGet = Array.from({ length: parseInt(winners) }, () => Math.floor(Math.random() * numbers.length));
                                } else {
                                    const nuGetSet = new Set();

                                    // nuGet = Array.from({ length: winners }, () => numbers[Math.floor(Math.random() * numbers.length)]);
                                    // for (let i = 0; i < parseInt(winners); i++) {
                                    //     const randomIndex = Math.floor(Math.random() * numbers.length);
                                    //     nuGet.push(randomIndex);
                                    // }
                                    while (nuGetSet.size < parseInt(winners)) {
                                        const randomIndex = Math.floor(Math.random() * numbers.length);
                                        nuGetSet.add(randomIndex);
                                    }
                                    nuGet = Array.from(nuGetSet);
                                }
                                console.log(nuGet, 'nuGet')

                                if (nuGet.length > 0) {
                                    for (let numsIndex = 0; numsIndex < nuGet.length; numsIndex++) {
                                        const nums = nuGet[numsIndex];
                                        // console.log(numbers)
                                        // console.log(`SELECT * FROM BuyTickets WHERE tickets LIKE '%${numbers[nums]}%'`)
                                        const [ticket_qry_1] = await db.query(`SELECT * FROM BuyTickets WHERE tickets LIKE '%${numbers[nums]}%'`)
                                        // console.log(ticket_qry_1, "ticket_qry_1")

                                        const [ticket] = ticket_qry_1;
                                        // console.log(ticket, "ticket");
                                        if (ticket) {

                                            await db.query(`insert into Winners (gameInformationId, UserId, gamePhaseId, ticketNumber, frequency)
                                             values('${phase.lottery_id}', '${parseInt(ticket.UserId)}', '${phase.phase_id}', '${numbers[nums]}', '${game_data.frequency}')`);
                                            // const rows = [
                                            //     {
                                            //         gameInformationId: phase.lottery_id,
                                            //         UserId: parseInt(ticket.UserId),
                                            //         gamePhaseId: phase.phase_id,
                                            //         ticketNumber: numbers[nums],
                                            //         frequency: game_data.frequency,
                                            //     }
                                            // ];
                                            // await db.query('insert into Winners (gameInformationId, UserId, gamePhaseId, ticketNumber, frequency) values (?)', rows);


                                            // const winner = await postWinner(Number(phase.lottery_id), ticket?.UserId, Number(phase.phase_id), numbers[nums], Number(game_data.frequency))

                                            // console.log(winner, "winner winner winner")

                                            const [users_qry] = await db.query(`select * from Users where id = '${parseInt(ticket.UserId)}'`);

                                            // console.log(users_qry, 'users_qry')
                                            // while (users_row = await users_qry.fetchRow()) {
                                            // console.log(users_qry.then(res=> console.log(res)))
                                            // for (let users_qryIndex = 0; users_qryIndex < users_qry.length; users_qryIndex++) {
                                            //     const users_row = users_qry[users_qryIndex];
                                            users_qry.map(async (users_row) => {
                                                // const users_row = rows[i];
                                                // console.log(users_row, 'users_row')
                                                const totalBalance = parseInt(users_row["balance"]) + parseInt(game_data.prize);
                                                const winTransactionRes = await postWinTransaction(Number(game_data.prize), ticket?.UserId, numbers[nums], lotteryData.info.info_name)
                                                // console.log(winTransactionRes, "winTransactionRes")
                                                if (winTransactionRes.message === "Success") {
                                                    getCommission(Number(game_data.prize), ticket?.UserId)
                                                }
                                                console.log("kjslhgjhdghfg")
                                                // Change with Tushar Start------------------------
                                                const cwts_qry = await db.query(`select win_trx_count from Users where id = '${users_row["id"]}'`)
                                                const cwts_win_trx = [];
                                                // for (let cwts_qryIndex = 0; cwts_qryIndex < cwts_qry.length; cwts_qryIndex++) {
                                                //     const cwts_row = cwts_qry[cwts_qryIndex];
                                                cwts_qry.map(async (cwts_row) => {
                                                    const win_trx_count = parseInt(cwts_row["win_trx_count"]) + 1;
                                                    cwts_win_trx.push(win_trx_count);
                                                });
                                                // Change with Tushar END-----------------------------

                                                // await db.query(`update Users set balance = '${totalBalance}', win_trx_count = '${cwts_win_trx[0]}' where id = '${users_row["id"]}'`)

                                                const mailUserName = users_row["fname"] + " " + users_row["lname"];
                                                const mailTicketNumber = numbers[nums];
                                                const mailLotteryName = lotteryData.info.info_name;
                                                const mailLink = "http://159.223.51.198:5000/winners";
                                                const mailWinningAmount = game_data.prize;
                                                const mailRemainingTime = new Date(lotteryData.info.info_duration + " " + lotteryData.info.info_time);
                                                mailRemainingTime.setDate(mailRemainingTime.getDate() + 1);
                                                const mailRemainingTimeFormatted = `${mailRemainingTime.getDate()}/${mailRemainingTime.getMonth() + 1}/${mailRemainingTime.getFullYear()} ${mailRemainingTime.getHours()}:${mailRemainingTime.getMinutes()}`;
                                                const to = users_row["email"];
                                                const toName = mailUserName;
                                                const subject = "Congratulations " + mailUserName;
                                                const message = `Hi ${mailUserName},
                                                    Congratulations! you got the winning of ${mailWinningAmount} in your recent draw for the 
                                                    ${mailLotteryName} and ticket number: ${mailTicketNumber}.
                                                    See your winning status (<a href="${mailLink}" target="_blank">click here</a>).
                                                    Your next draw for this lottery will take place on ${mailRemainingTimeFormatted}.
                                                    
                                                    Keep playing, keep winning,
                                                    The team Lifetime Lotto.`;
                                                const emailPromises = [];
                                                emailPromises.push(sendMail(to, toName, subject, message)); // Replace `sendMail` with your actual email sending function

                                                // Add more email addresses and messages to the `emailPromises` array if needed

                                                Promise.all(emailPromises)
                                                    .then(() => {
                                                        console.log('All emails sent successfully');
                                                    })
                                                    .catch(error => {
                                                        console.error('Failed to send emails:', error);
                                                    });
                                                // sendMail(to, toName, subject, message);
                                            });
                                        }
                                        else {
                                            await db.query(`insert into Winners (gameInformationId, UserId, gamePhaseId, ticketNumber, frequency) values('${phase["lottery_id"]}', null, '${phase["phase_id"]}', '${numbers[nums]}', '${game_data.frequency}')`);
                                            // const rows = [
                                            //     {
                                            //         gameInformationId: phase.lottery_id,
                                            //         UserId: null,
                                            //         gamePhaseId: phase.phase_id,
                                            //         ticketNumber: numbers[nums],
                                            //         frequency: game_data.frequency,
                                            //     }
                                            // ];
                                            // await db.query('insert into Winners (gameInformationId, UserId, gamePhaseId, ticketNumber, frequency) values (?)', rows);
                                            // const winner = await postWinner(Number(phase.lottery_id), ticket?.UserId, Number(phase.phase_id), numbers[nums], Number(game_data.frequency))

                                            // console.log(winner, "winner winner winner")

                                        }
                                        const newDateTime = moment(lotteryData.info.info_duration).add(1, 'day').format('YYYY-MM-DD');
                                        // console.log(lotteryData.info.info_id)
                                        await db.query(`UPDATE gameInformations SET gameDuration = '${newDateTime.trim()}' WHERE id = ${lotteryData.info.info_id}`);
                                        const [ticket_qry_2] = await db.query(`select * from BuyTickets where lotteryId = '${lotteryData.info.info_id}' and tickets not like '%${numbers[nums]}%'`);
                                        // for (let ticket_qry_2Index = 0; ticket_qry_2Index < ticket_qry_2.length; ticket_qry_2Index++) {
                                        //     const ticket_row_2 = ticket_qry_2[ticket_qry_2Index];
                                        ticket_qry_2.map(async (ticket_row_2) => {
                                            // console.log(ticket_row_2,"ticket_row_2")
                                            // console.log(parseInt(ticket_row_2.UserId))
                                            const [ticket_row_users_qry] = await db.query(`select * from Users where id = '${parseInt(ticket_row_2.UserId)}'`)


                                            const [ticket_row_users_row] = ticket_row_users_qry;
                                            // console.log(ticket_row_users_row)
                                            const ticket_row_2_split = ticket_row_2.tickets.split('|');
                                            // console.log(ticket_row_2_split)
                                            // for (let ticket_row_2_splitIndex = 0; ticket_row_2_splitIndex < ticket_row_2_split.length; ticket_row_2_splitIndex++) {
                                            //     const row_2_split = ticket_row_2_split[ticket_row_2_splitIndex];
                                            ticket_row_2_split.map(async (row_2_split) => {
                                                const mailUserName1 = ticket_row_users_row.fname + " " + ticket_row_users_row.lname;
                                                const mailLotteryName1 = lotteryData.info.info_name;
                                                const mailTicketNumber1 = row_2_split;
                                                const mailLink1 = "http://159.223.51.198:5000/winners";
                                                const mailRemainingTime1 = `
                                                        <script>
                                                            var day = new Date(${lotteryData.info.info_duration} ${lotteryData.info.info_time});
                                                            var nextDay = new Date(day);
                                                            nextDay.setDate(day.getDate() + 1);
                                                            document.write(nextDay.getDate()+'/'+(nextDay.getMonth() + 1)+'/'+nextDay.getFullYear()+' '+nextDay.getHours()+':'+nextDay.getMinutes());
                                                        </script>
                                                    `;
                                                const to1 = ticket_row_users_row.email;
                                                const toName1 = mailUserName1;
                                                const subject1 = "Better Luck Next Time!";
                                                const message1 = `Hi ${mailUserName1},<br />
                                                    This time it wasn't yours. You didn't hit the winning prize in your recent draw for the ${mailLotteryName1} 
                                                    and ticket number: ${mailTicketNumber1}. Maybe the next draw can bring luck for you.<br />
                                                    You can see your win/lose status from (<a href='${mailLink1}' target='_blank'>click here</a>) anytime.<br />
                                                    Your next draw for this lottery will take place on ${mailRemainingTime1}.<br /><br />
                                                    Keep playing, keep winning,<br />
                                                    The team Lifetime Lotto.`;

                                                const emailPromises = [];
                                                emailPromises.push(sendMail(to1, toName1, subject1, message1));


                                                Promise.all(emailPromises)
                                                    .then(() => {
                                                        console.log('All emails sent successfully');
                                                    })
                                                    .catch(error => {
                                                        console.error('Failed to send emails:', error);
                                                    });

                                                // sendMail(to1, toName1, subject1, message1);

                                            });
                                        });
                                    }
                                }

                            }
                        }
                        else if (game_data.frequency == 2) {
                            const current_day = moment().format('dddd').toLowerCase();
                            // console.log(current_day,"current_day")
                            // const schedule = [];
                            // for (const schedules of game_data.schedules) {
                            //     if (schedules.value === current_day) {
                            //         schedule.push(schedules.value);
                            //     }
                            // }
                            const schedule = game_data.schedules
                                .filter(schedules => schedules.value === current_day)
                                .map(schedules => schedules.value);

                            console.log(schedule, "weekly 111111111111111111")
                            if (schedule.length > 0) {
                                const weeklyDaysDate = [];

                                // for (let scheduleIndex = 0; scheduleIndex < schedule.length; scheduleIndex++) {
                                //     const sche = schedule[scheduleIndex];
                                schedule.map(async (sche) => {
                                    const weeklyDate = moment().day(sche).add(7, 'days');
                                    const formattedDate = weeklyDate.format('YYYY-MM-DD');
                                    if (formattedDate > (lotteryData.info.info_duration)) {
                                        weeklyDaysDate.push(formattedDate);
                                    }
                                    if (current_day == sche) {
                                        // let numbers;
                                        let numbers = lotteryData.info.ticket_numbers.split(",");
                                        const winners = game_data.winners;
                                        if (winners != 0) {
                                            let nuGet = [];
                                            if (winners == 1) {
                                                nuGet = Array.from({ length: parseInt(winners) }, () => Math.floor(Math.random() * numbers.length));
                                            } else {
                                                for (let i = 0; i < parseInt(winners); i++) {
                                                    const randomIndex = Math.floor(Math.random() * numbers.length);
                                                    nuGet.push(randomIndex);
                                                }
                                            }
                                            if (nuGet.length > 0) {
                                                // for (let numsIndex = 0; numsIndex < nuGet.length; numsIndex++) {
                                                //     const nums = nuGet[numsIndex];
                                                nuGet.map(async (nums) => {
                                                    const [ticket_qry_1] = await db.query(`select * from BuyTickets where tickets like '%${numbers[nums]}%'`);
                                                    const [ticket] = ticket_qry_1;
                                                    // console.log(ticket,'ticket')
                                                    if (ticket) {
                                                        await db.query(`insert into Winners (gameInformationId, UserId, gamePhaseId, ticketNumber, frequency) values('${phase["lottery_id"]}', '${parseInt(ticket["UserId"])}', '${phase["phase_id"]}', '${numbers[nums]}', '${game_data.frequency}')`)

                                                        // const rows = [
                                                        //     {
                                                        //         gameInformationId: phase.lottery_id,
                                                        //         UserId: parseInt(ticket.UserId),
                                                        //         gamePhaseId: phase.phase_id,
                                                        //         ticketNumber: numbers[nums],
                                                        //         frequency: game_data.frequency,
                                                        //     }
                                                        // ];
                                                        // await db.query('insert into Winners (gameInformationId, UserId, gamePhaseId, ticketNumber, frequency) values (?)', rows);



                                                        const [users_qry] = await db.query(`select * from Users where id = '${parseInt(ticket["UserId"])}'`);
                                                        // while (users_row = users_qry.fetchSync()) {
                                                        // console.log(ticket, "winners")
                                                        // for (let users_qryIndex = 0; users_qryIndex < users_qry.length; users_qryIndex++) {
                                                        //     const users_row = users_qry[users_qryIndex];
                                                        users_qry.map(async (users_row) => {
                                                            const totalBalance = parseInt(users_row.balance) + parseInt(game_data.prize);
                                                            const winTransactionRes = await postWinTransaction(Number(game_data.prize), ticket?.UserId, numbers[nums], lotteryData.info.info_name)
                                                            console.log(winTransactionRes, "winTransactionRes")
                                                            if (winTransactionRes.message === "Success") {
                                                                getCommission(Number(game_data.prize), ticket?.UserId)
                                                            }
                                                            // console.log("kjslhgjhdghfg")
                                                            // Change with Tushar Start
                                                            const cwts_qry = db.query(`select win_trx_count from Users where id = '${users_row["id"]}'`)
                                                            const cwts_win_trx = [];
                                                            // for (let cwts_qryIndex = 0; cwts_qryIndex < cwts_qry.length; cwts_qryIndex++) {
                                                            //     const cwts_row = cwts_qry[cwts_qryIndex];
                                                            cwts_qry.map(async (cwts_row) => {
                                                                // console.log(cwts_row,"cwts_row")
                                                                const win_trx_count = parseInt(cwts_row["win_trx_count"]) + 1;
                                                                cwts_win_trx.push(win_trx_count);
                                                            })
                                                            // Change with Tushar END

                                                            // console.log(users_row, "users_row")
                                                            // console.log("first!!!!!!!!!!!!!!!!!!!"); break;
                                                            // await db.query(`update Users set balance = '${totalBalance}', win_trx_count = '${cwts_win_trx[0]}' where id = '${users_row["id"]}'`);
                                                            const mailUserName = users_row.fname + " " + users_row.lname;
                                                            const mailTicketNumber = numbers[nums];
                                                            const mailLotteryName = lotteryData.info.info_name;
                                                            const mailLink = "http://159.223.51.198:5000/winners";
                                                            const mailWinningAmount = game_data.prize;
                                                            const mailRemainingTime = `
                                                            <script>
                                                                var day = new Date(${lotteryData.info.info_duration} ${lotteryData.info.info_time});
                                                                var nextDay = new Date(day);
                                                                nextDay.setDate(day.getDate() + 1);
                                                                document.write(nextDay.getDate()+'/'+(nextDay.getMonth() + 1)+'/'+nextDay.getFullYear()+' '+nextDay.getHours()+':'+nextDay.getMinutes());
                                                            </script>
                                                                `;
                                                            const to = users_row.email;
                                                            const toName = mailUserName;
                                                            const subject = "Congratulations " + mailUserName;
                                                            const message = `Hi ${mailUserName},<br />
                                                            Congratulations! You have won ${mailWinningAmount} in your recent draw for the ${mailLotteryName} and 
                                                            ticket number: ${mailTicketNumber}.<br />
                                                            See your winning status (<a href='${mailLink}' target='_blank'>click here</a>).<br />
                                                            Your next draw for this lottery will take place on ${mailRemainingTime}.<br /><br />
                                                             Keep playing, keep winning,<br />
                                                            The team Lifetime Lotto.`;

                                                            console.log("winnnnnnnnnnnnn")
                                                            sendMail(to, toName, subject, message);


                                                        });
                                                    }

                                                    else {
                                                        // console.log("ss!!!!!!!!!!!!!!!!!!!"); break;

                                                        await db.query(`insert into Winners (gameInformationId, UserId, gamePhaseId, ticketNumber, frequency) values('${phase["lottery_id"]}', null, '${phase["phase_id"]}', '${numbers[nums]}', '${game_data.frequency}')`);
                                                        // const rows = [
                                                        //     {
                                                        //         gameInformationId: phase.lottery_id,
                                                        //         UserId: null,
                                                        //         gamePhaseId: phase.phase_id,
                                                        //         ticketNumber: numbers[nums],
                                                        //         frequency: game_data.frequency,
                                                        //     }
                                                        // ];
                                                        // await db.query('insert into Winners (gameInformationId, UserId, gamePhaseId, ticketNumber, frequency) values (?)', rows);

                                                    }
                                                    const [ticket_qry_2] = await db.query(`select * from BuyTickets where lotteryId = '${lotteryData.info.info_id}' and tickets not like '%${numbers[nums]}%'`)
                                                    // while (ticket_row_2 = ticket_qry_2.fetchSync()) {
                                                    // for (let ticket_qry_2Index = 0; ticket_qry_2Index < ticket_qry_2.length; ticket_qry_2Index++) {
                                                    //     const ticket_row_2 = ticket_qry_2[ticket_qry_2Index];
                                                    ticket_qry_2.map(async (ticket_row_2) => {
                                                        // console.log(ticket_row_2, 'ticket_row_2'); break

                                                        const [ticket_row_users_qry] = await db.query(`select * from Users where id = '${parseInt(ticket_row_2["UserId"])}'`);
                                                        const [ticket_row_users_row] = ticket_row_users_qry;
                                                        const ticket_row_2_split = ticket_row_2.tickets.split(',');

                                                        // for (let ticket_row_2_splitIndex = 0; ticket_row_2_splitIndex < ticket_row_2_split.length; ticket_row_2_splitIndex++) {
                                                        //     const row_2_split = ticket_row_2_split[ticket_row_2_splitIndex];
                                                        ticket_row_2_split.map(async (row_2_split) => {

                                                            const mailUserName1 = ticket_row_users_row.fname + " " + ticket_row_users_row.lname;
                                                            const mailLotteryName1 = lotteryData.info.info_name;
                                                            const mailTicketNumber1 = row_2_split;
                                                            const mailLink1 = "http://159.223.51.198:5000/winners";
                                                            const mailRemainingTime1 = `
                                                                <script>
                                                                    var day = new Date(${lotteryData.info.info_duration} ${lotteryData.info.info_time});
                                                                    var nextDay = new Date(day);
                                                                    nextDay.setDate(day.getDate() + 1);
                                                                    document.write(nextDay.getDate()+'/'+(nextDay.getMonth() + 1)+'/'+nextDay.getFullYear()+' '+nextDay.getHours()+':'+nextDay.getMinutes());
                                                                </script>
                                                            `;
                                                            const to1 = ticket_row_users_row.email;
                                                            const toName1 = mailUserName1;
                                                            const subject1 = "Better Luck Next Time!";
                                                            const message1 = `Hi ${mailUserName1},<br />
                                                            This time it wasn't yours. You didn't hit the winning prize in your recent draw for the ${mailLotteryName1} 
                                                            and ticket number: ${mailTicketNumber1}. Maybe the next draw can bring luck for you.<br />
                                                            You can see your win/lose status from (<a href='${mailLink1}' target='_blank'>click here</a>) anytime.<br />
                                                            Your next draw for this lottery will take place on ${mailRemainingTime1}.<br /><br />
                                                            Keep playing, keep winning,<br />
                                                            The team Lifetime Lotto.`;
                                                            console.log("lossssssssssssssss")
                                                            sendMail(to1, toName1, subject1, message1);
                                                        });
                                                    });

                                                });
                                            }
                                        }

                                    }
                                });
                                if ((weeklyDaysDate.length) > 0) {
                                    await db.query(`update gameInformations set gameDuration = '${weeklyDaysDate[0]}', nextDraw = '1' where id = '${lotteryData.info.info_id}'`)
                                }
                            }
                        }
                        else if (game_data.frequency == 3) {
                            const current_day = (new Date()).getDate();
                            // const schedule = [];
                            // console.log(game_data.schedules)
                            // for (const schedules of game_data.schedules) {
                            //     // console.log(schedules.value === current_day)
                            //     if (schedules.value == current_day) {
                            //         schedule.push(schedules.value);
                            //     }
                            // };
                            const schedule = game_data.schedules
                                .filter(schedules => schedules.value === current_day)
                                .map(schedules => schedules.value);
                            if ((schedule.length) > 0) {
                                const monthlyDaysDate = [];
                                // for (let scheduleIndex = 0; scheduleIndex < schedule.length; scheduleIndex++) {
                                //     const sche = schedule[scheduleIndex];
                                schedule.map(async (sche) => {
                                    // console.log(sche,"sche")
                                    const currentDate = moment().format('YYYY') + '-' + moment().format('MM') + '-' + sche;
                                    const monthlyDate = moment(currentDate);
                                    const formattedDate = monthlyDate.format('YYYY-MM-DD');
                                    // console.log(formattedDate)
                                    // console.log(lotteryData.info.info_duration);
                                    if (formattedDate > lotteryData.info.info_duration) {
                                        monthlyDaysDate.push(formattedDate);
                                    }
                                    // console.log(current_day)
                                    if (current_day == sche) {
                                        numbers = lotteryData.info.ticket_numbers.split(",");
                                        winners = game_data.winners;
                                        // console.log(winners,"hii");break;
                                        if (winners != 0) {
                                            let nuGet = [];
                                            if (winners == 1) {
                                                nuGet = Array.from({ length: parseInt(winners) }, () => Math.floor(Math.random() * numbers.length));
                                            } else {
                                                for (let i = 0; i < parseInt(winners); i++) {
                                                    const randomIndex = Math.floor(Math.random() * numbers.length);
                                                    nuGet.push(randomIndex);
                                                }
                                            }
                                            if (nuGet.length > 0) {
                                                // for (let numsIndex = 0; numsIndex < nuGet.length; numsIndex++) {
                                                //     const nums = nuGet[numsIndex];
                                                nuGet.map(async (nums) => {
                                                    // console.log(`SELECT * FROM BuyTickets WHERE tickets LIKE '%${numbers[nums]}%'`)
                                                    const [ticket_qry_1] = await db.query(`SELECT * FROM BuyTickets WHERE tickets LIKE '%${numbers[nums]}%'`);
                                                    const [ticket] = ticket_qry_1;
                                                    // console.log(numbers);
                                                    // console.log(nums);
                                                    if (ticket) {
                                                        // console.log(ticket, "ticket"); break;
                                                        await db.query(`insert into Winners (gameInformationId, UserId, gamePhaseId, ticketNumber, frequency) values('${phase["lottery_id"]}', '${parseInt(ticket["UserId"])}', '${phase["phase_id"]}', '${numbers[nums]}', '${game_data.frequency}')`)

                                                        // const rows = [
                                                        //     {
                                                        //         gameInformationId: phase.lottery_id,
                                                        //         UserId: parseInt(ticket.UserId),
                                                        //         gamePhaseId: phase.phase_id,
                                                        //         ticketNumber: numbers[nums],
                                                        //         frequency: game_data.frequency,
                                                        //     }
                                                        // ];
                                                        // await db.query('insert into Winners (gameInformationId, UserId, gamePhaseId, ticketNumber, frequency) values (?)', rows);



                                                        const [users_qry] = await db.query(`select * from Users where id = '${parseInt(ticket["UserId"])}'`);
                                                        // console.log(numbers[nums],"numbers[nums]")
                                                        // while (users_row = users_qry.fetchSync()) {
                                                        // console.log(users_qry,"users_qry")
                                                        // for (let users_qryIndex = 0; users_qryIndex < users_qry.length; users_qryIndex++) {
                                                        //     const users_row = users_qry[users_qryIndex];
                                                        users_qry.map(async (users_row) => {
                                                            const totalBalance = parseInt(users_row["balance"]) + parseInt(game_data.prize);
                                                            const winTransactionRes = await postWinTransaction(Number(game_data.prize), ticket?.UserId, numbers[nums], lotteryData.info.info_name)
                                                            // console.log(winTransactionRes, "winTransactionRes")                                                                // console.log(ticket, "ticket"); break;
                                                            if (winTransactionRes.message === "Success") {
                                                                getCommission(Number(game_data.prize), ticket?.UserId)
                                                            }
                                                            console.log("kjslhgjhdghfg")
                                                            // Change with Tushar Start
                                                            const cwts_qry = await db.query(`select win_trx_count from Users where id = '${users_row["id"]}'`)
                                                            const cwts_win_trx = [];
                                                            // for (let cwts_qryIndex = 0; cwts_qryIndex < cwts_qry.length; cwts_qryIndex++) {
                                                            //     const cwts_row = cwts_qry[cwts_qryIndex];
                                                            cwts_qry.map(async (cwts_row) => {
                                                                const win_trx_count = parseInt(cwts_row["win_trx_count"]) + 1;
                                                                cwts_win_trx.push(win_trx_count);
                                                            });
                                                            // Change with Tushar END

                                                            // await db.query(`update Users set balance = '${totalBalance}', win_trx_count = '${cwts_win_trx[0]}' where id = '${users_row["id"]}'`);
                                                            const mailUserName = users_row.fname + ' ' + users_row.lname;
                                                            const mailTicketNumber = numbers[nums];
                                                            const mailLotteryName = lotteryData.info.info_name;
                                                            const mailLink = 'http://159.223.51.198:5000/winners';
                                                            const mailWinningAmount = game_data.prize;
                                                            const mailRemainingTime = `
                                                                    <script>
                                                                        var day = new Date(${lotteryData.info.info_duration} ${lotteryData.info.info_time});
                                                                        var nextDay = new Date(day);
                                                                        nextDay.setDate(day.getDate() + 1);
                                                                        document.write(nextDay.getDate()+'/'+(nextDay.getMonth() + 1)+'/'+nextDay.getFullYear()+' '+nextDay.getHours()+':'+nextDay.getMinutes());
                                                                    </script>
                                                                `;
                                                            const to = users_row.email;
                                                            const toName = mailUserName;
                                                            const subject = 'Congratulation ' + mailUserName;
                                                            const message = `Hi ${mailUserName},<br />
                                                                Congratulations! you got the winning amount of ${mailWinningAmount} in your recent draw for 
                                                                the ${mailLotteryName} and ticket number: ${mailTicketNumber}.<br />
                                                                See your winning status (<a href="${mailLink}" target="_blank">click here</a>).<br />
                                                                Your next draw for this lottery will take place in ${mailRemainingTime}.<br /><br />
                                                                Keep playing, keep Winning,<br />
                                                                The team Lifetime Lotto.`;
                                                            console.log("winnnnnnnnnnnnn")
                                                            // sendMail(to, toName, subject, message);
                                                        })

                                                    } else {
                                                        await db.query(`insert into Winners (gameInformationId, UserId, gamePhaseId, ticketNumber, frequency) values('${phase["lottery_id"]}', null, '${phase["phase_id"]}', '%${numbers[nums]}%', '${game_data.frequency}')`);

                                                        // const rows = [
                                                        //     {
                                                        //         gameInformationId: phase.lottery_id,
                                                        //         UserId: null,
                                                        //         gamePhaseId: phase.phase_id,
                                                        //         ticketNumber: numbers[nums],
                                                        //         frequency: game_data.frequency,
                                                        //     }
                                                        // ];
                                                        // await db.query('insert into Winners (gameInformationId, UserId, gamePhaseId, ticketNumber, frequency) values (?)', rows);



                                                    }
                                                    const [ticket_qry_2] = await db.query(`select * from BuyTickets where lotteryId = '${lotteryData.info.info_id}' and tickets not like '%${numbers[nums]}%'`);
                                                    // while (ticket_row_2 = ticket_qry_2.fetchSync()) {
                                                    // for (let ticket_qry_2Index = 0; ticket_qry_2Index < ticket_qry_2.length; ticket_qry_2Index++) {
                                                    //     const ticket_row_2 = ticket_qry_2[ticket_qry_2Index];
                                                    ticket_qry_2.map(async (ticket_row_2) => {
                                                        const [ticket_row_users_qry] = await db.query(`select * from Users where id = '${parseInt(ticket_row_2["UserId"])}'`);
                                                        const [ticket_row_users_row] = ticket_row_users_qry;
                                                        const ticket_row_2_split = ticket_row_2.tickets.split("|");
                                                        // console.log(ticket_row_2_split, "ticket_row_2_split");
                                                        // console.log("Working.........."); break;
                                                        // for (let ticket_row_2_splitIndex = 0; ticket_row_2_splitIndex < ticket_row_2_split.length; ticket_row_2_splitIndex++) {
                                                        //     const row_2_split = ticket_row_2_split[ticket_row_2_splitIndex];
                                                        ticket_row_2_split.map(async (row_2_split) => {
                                                            const mailUserName1 = ticket_row_users_row["fname"] + " " + ticket_row_users_row["lname"];
                                                            const mailLotteryName1 = lotteryData.info.info_name;
                                                            const mailTicketNumber1 = row_2_split;
                                                            const mailLink1 = "http://159.223.51.198:5000/winners";
                                                            const mailRemainingTime1 = `
                                                                    <script>
                                                                        var day = new Date(${lotteryData.info.info_duration} ${lotteryData.info.info_time});
                                                                        var nextDay = new Date(day);
                                                                        nextDay.setDate(day.getDate() + 1);
                                                                        document.write(nextDay.getDate()+'/'+(nextDay.getMonth() + 1)+'/'+nextDay.getFullYear()+' '+nextDay.getHours()+':'+nextDay.getMinutes());
                                                                    </script> `;

                                                            const to1 = ticket_row_users_row["email"];
                                                            const toName1 = mailUserName1;
                                                            const subject1 = "Better Luck Next Time!";
                                                            const message1 = `Hi ${mailUserName1},
                                                                    This time it wasn't yours. You didn't hit the winning prize in your recent draw for the 
                                                                    ${mailLotteryName1} and ticket number: ${mailTicketNumber1}. Maybe the next draw can bring luck for you.
                                                                    You can see your win/lose status from (<a href='${mailLink1}' target='_blank'>click here</a>) anytime.
                                                                    Your next draw for this lottery will take place on ${mailRemainingTime1}.
                                                                    
                                                                    Keep playing, keep winning,
                                                                    The team Lifetime Lotto.`;
                                                            console.log("loss")
                                                            // sendMail(to1, toName1, subject1, message1);
                                                        });

                                                    });
                                                });
                                            }
                                        }
                                    }
                                });
                                if ((monthlyDaysDate.length) > 0) {
                                    await db.query(`update gameInformations set gameDuration = '${monthlyDaysDate[0]}', nextDraw = '1' where id = "${lotteryData.info.info_id}"`);
                                }

                            }

                        }
                    });
                })
                console.log("Job successfully started")
            }
            else {
                console.log("Job failed")
            }
        }
        else {
            console.log("Job failed! Last")
        }

    } catch (error) {
        console.log("error", error)

    }
}
// setInterval(main, 60000); // Execute the main function every 1 minute

// main()

module.exports = { main };