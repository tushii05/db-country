const crypto = require("crypto");

async function commissionRandomNo() {
    const currentDate = new Date();
    const year = currentDate.getFullYear();
    const digit = "LTLC";
    const lastTicket = await db.Commission.findOne({
        order: [["id", "DESC"]],
        attributes: ["randomNo"],
    });
    const lastSeqNumber = lastTicket ? parseInt(lastTicket.randomNo.slice(-4)) : 0;
    const seqNumber = (lastSeqNumber + 1).toString().padStart(4, "0");
    const randomNo = `${year}${digit}${seqNumber}`;
    return randomNo;
}

async function supportRandomNo() {
    const currentDate = new Date();
    const year = currentDate.getFullYear();
    const digit = "LTLS";
    const lastTicket = await db.supportTicket.findOne({
        order: [["id", "DESC"]],
        attributes: ["randomNo"],
    });
    const lastSeqNumber = lastTicket ? parseInt(lastTicket.randomNo.slice(-4)) : 0;
    const seqNumber = (lastSeqNumber + 1).toString().padStart(4, "0");
    const randomNo = `${year}${digit}${seqNumber}`;
    return randomNo;
}


function generateOTP() {
    const otpLength = 6;
    const digits = "0123456789";
    let OTP = "";
    for (let i = 0; i < otpLength; i++) {
        OTP += digits[crypto.randomInt(0, digits.length)];
    }
    return OTP;
}

function generateTransactionId() {
    const bytes = crypto.randomBytes(8);
    const transactionId = bytes.toString("hex");
    return transactionId;
}

async function generateRandom(min = 1000000000, max = 9999999999) {
    return new Promise((resolve, reject) => {
        const range = max - min;
        const randomBytes = crypto.randomBytes(8);
        const randomNumber = randomBytes.toString("hex");
        const randomFloat = parseInt(randomNumber.substring(randomNumber.length - 16, randomNumber.length), 16) / Math.pow(2, 64);
        const number = Math.floor(randomFloat * range) + min;
        resolve(number);
    });
}



async function generateRandomNumberScratch() {
    const min = 1;
    const max = 100;

    return new Promise((resolve, reject) => {
        const range = max - min;
        const randomBytes = crypto.randomBytes(8);
        const randomNumber = randomBytes.toString("hex");
        const randomFloat = parseInt(randomNumber.substring(randomNumber.length - 16, randomNumber.length), 16) / Math.pow(2, 64);
        const number = Math.floor(randomFloat * range) + min;
        resolve(number);
    });
}


async function generateRandomNumberTable(rangeStart, rangeEnd) {
    return new Promise((resolve, reject) => {
        const range = rangeStart - rangeEnd;
        const randomBytes = crypto.randomBytes(8);
        const randomNumber = randomBytes.toString("hex");
        const randomFloat = parseInt(randomNumber.substring(randomNumber.length - 16, randomNumber.length), 16) / Math.pow(2, 64);
        const number = Math.floor(randomFloat * range) + rangeEnd;
        resolve(number);
    });
}

module.exports = {
    commissionRandomNo,
    supportRandomNo,
    generateOTP,
    generateTransactionId,
    generateRandom,
    generateRandomNumberScratch,
    generateRandomNumberTable,
};