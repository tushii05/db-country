const mysql = require('mysql2/promise');
const { Sequelize, DataTypes } = require('sequelize');

module.exports = db = {};
initialize();
async function initialize() {
    const { DBHOST, DBPORT, DBUSER, DBPASSWORD, DBDB } = process.env;
    const connection = await mysql.createConnection({ host: DBHOST, port: DBPORT, user: DBUSER, password: DBPASSWORD });
    await connection.query(`CREATE DATABASE IF NOT EXISTS \`${DBDB}\`;`);
    const sequelize = new Sequelize(
        DBDB,
        DBUSER,
        DBPASSWORD,
        {
            port: DBPORT,
            host: DBHOST,
            dialect: 'mysql',
            logging: false
        });
    console.log(`DataBase Connect to -- ${DBDB}`)

    db.sequelize = sequelize;


    db.Admin = require('../modules/admin/admin.model')(sequelize);
    db.User = require('../modules/users/users.model')(sequelize);
    db.UserLoginLogs = require('../modules/userloginlogs/userloginlogs.model')(sequelize);
    db.UserTransaction = require('../modules/usertransaction/usertransaction.model')(sequelize);
    db.Timezone = require('../modules/timezone/timezone.model')(sequelize);
    db.GameInfo = require('../modules/gameinfo/gameinfo.model')(sequelize);
    db.GamePhase = require('../modules/gamephase/gamephase.model')(sequelize);
    db.Currency = require('../modules/currency/currency.model')(sequelize);
    db.scratchCard = require('../modules/scratchcard/scratchcard.model')(sequelize);
    db.scratchCardPlay = require('../modules/scratchcardplay/scratchcardplay.model')(sequelize);
    db.supportTicket = require('../modules/supportticket/supportticket.model')(sequelize);
    db.supportTicketMessage = require('../modules/supportticketmessage/supportticketmessage.model')(sequelize);
    db.SupportTicketAttachment = require('../modules/supportticketattachment/supportticketattachment.model')(sequelize);
    db.buyTicket = require('../modules/buyticket/buyticket.model')(sequelize);
    db.Winners = require('../modules/winnerticket/winnerticket.model')(sequelize);
    db.Referral = require('../modules/userreferal/userreferal.model')(sequelize);
    db.Email = require('../modules/sendemail/sendemail.model')(sequelize);
    db.ContactUs = require('../modules/contactus/contactus.model')(sequelize);
    db.Subscribe = require('../modules/subscribe/subscribe.model')(sequelize);
    db.Notification = require('../modules/notification/notification.model')(sequelize);
    db.UserNotification = require('../modules/usernotification/usernotification.model')(sequelize);
    db.Withdrawals = require('../modules/withdrawals/withdrawals.model')(sequelize);
    db.Commission = require('../modules/commissionlog/commissionlog.model')(sequelize);
    db.generateRandomNoScratch = require('../modules/scratchgeneratno/scratchgeneratno.model')(sequelize);
    db.generateRandomNoLottery = require('../modules/lotterygenerat/lotterygenerat.model')(sequelize);
    db.Countries = require('../modules/countries/countries.model')(sequelize);
    db.States = require('../modules/state/states.model')(sequelize);
    db.Cities = require('../modules/city/city.model')(sequelize);
    db.ScratchTable = require('../modules/adminScratchTable/adminScratchTable.model')(sequelize);
    db.scratchCardWin = require('../modules/scratchCardWin/scratchcardwin.model')(sequelize);
    db.scratchCardLoss = require('../modules/scratchCardLoss/scratchcardloss.model')(sequelize);

    db.Withdrawals.belongsTo(db.User);
    db.User.hasMany(db.Withdrawals);

    db.UserTransaction.belongsTo(db.Withdrawals);
    db.Withdrawals.hasMany(db.UserTransaction);

    db.States.belongsTo(db.Countries)
    db.Countries.hasMany(db.States);
    db.Cities.belongsTo(db.States);
    db.States.hasMany(db.Cities);

    db.GameInfo.hasMany(db.Winners);
    db.Winners.belongsTo(db.GameInfo);

    db.GamePhase.hasMany(db.Winners);
    db.Winners.belongsTo(db.GamePhase);

    db.GamePhase.belongsTo(db.GameInfo);
    db.GameInfo.hasMany(db.GamePhase);

    db.User.hasMany(db.Winners);
    db.Winners.belongsTo(db.User);

    db.GameInfo.hasMany(db.generateRandomNoLottery);
    db.generateRandomNoLottery.belongsTo(db.GameInfo);

    db.scratchCard.hasMany(db.generateRandomNoScratch);
    db.generateRandomNoScratch.belongsTo(db.scratchCard);

    db.scratchCardPlay.belongsTo(db.scratchCard, { foreignKey: "scratchCardId" });

    db.scratchCard.hasMany(db.ScratchTable);
    db.ScratchTable.belongsTo(db.scratchCard);

    db.scratchCardPlay.hasMany(db.ScratchTable);
    db.ScratchTable.belongsTo(db.scratchCardPlay);

    db.scratchCard.hasMany(db.scratchCardWin);
    db.scratchCardWin.belongsTo(db.scratchCard);

    db.scratchCard.hasMany(db.scratchCardLoss);
    db.scratchCardLoss.belongsTo(db.scratchCard);


    db.User.hasMany(db.UserTransaction, { as: "deposit" });
    db.User.hasMany(db.UserTransaction, { as: "withdraw" });
    db.User.hasMany(db.UserTransaction, { as: "winning" });
    db.User.hasMany(db.UserTransaction, { as: "purchase" });
    db.User.hasMany(db.UserTransaction, { as: "card_Purchase" });
    db.User.hasMany(db.UserTransaction, { as: "card_Won" });
    db.User.hasMany(db.UserTransaction, { as: "adminWithdraw" });
    db.User.hasMany(db.UserTransaction, { as: "adminDeposit" });
    db.User.hasMany(db.UserTransaction, { as: "commission" });
    db.User.hasMany(db.UserTransaction);
    db.UserTransaction.belongsTo(db.User);

    db.User.hasMany(db.buyTicket);
    db.buyTicket.belongsTo(db.User);

    db.User.hasMany(db.scratchCardPlay);
    db.scratchCardPlay.belongsTo(db.User);

    db.User.hasMany(db.Commission);
    db.Commission.belongsTo(db.User);

    db.User.hasMany(db.UserLoginLogs);
    db.UserLoginLogs.belongsTo(db.User);

    db.User.hasMany(db.supportTicket);
    db.supportTicket.belongsTo(db.User);

    db.User.hasMany(db.scratchCardWin);
    db.scratchCardWin.belongsTo(db.User);

    db.User.hasMany(db.scratchCardLoss);
    db.scratchCardLoss.belongsTo(db.User);

    db.buyTicket.belongsTo(db.GameInfo, { foreignKey: "lotteryId" });
    db.buyTicket.belongsTo(db.GamePhase, { foreignKey: "gamePhaseId" });
    db.buyTicket.belongsTo(db.Currency, { foreignKey: "gameCurrencyId" });
    // db.buyTicket.belongsTo(db.Timezone, { foreignKey: "timeZoneId" });
    db.GamePhase.hasMany(db.buyTicket);
    // db.Timezone.hasMany(db.buyTicket);
    db.Currency.hasMany(db.buyTicket);


    db.supportTicketMessage.belongsTo(db.Admin);
    db.Admin.hasMany(db.supportTicketMessage);
    db.supportTicketMessage.belongsTo(db.supportTicket);
    db.supportTicket.hasMany(db.supportTicketMessage);
    db.SupportTicketAttachment.belongsTo(db.supportTicketMessage);

    db.GameInfo.belongsTo(db.Currency, { foreignKey: "gameCurrency" });
    // db.GameInfo.belongsTo(db.Timezone, { foreignKey: "timeZone" });


    db.Winners.belongsTo(db.Currency);
    db.Currency.hasMany(db.Winners);

    await sequelize.sync();
}