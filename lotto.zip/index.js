require('rootpath')();
const express = require('express');
const app = express();
const logger = require('./logger');
const cors = require('cors');
const bodyParser = require('body-parser');
var cron = require('node-cron');

const errorHandler = require('_middleware/error-handler');
const path = require('path');
const dotenv = require('dotenv');
const { main } = require('./job_cron');
// const queue = require('queue');

// const { Worker } = require('worker_threads');
dotenv.config();
const cronJob = require('./cronJob');
cronJob.start();


app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use(cors({ origin: '*' }));
const uploads = path.join(__dirname, 'uploads');
app.use(express.static(uploads));

app.use("/api", require('./routes'));
// app.use("/api", (req, res, next) => {
//   logger.info(`API Request: ${req.method} ${req.originalUrl}`);
//   next();
// }, require('./routes'));


// Serve frontend index.html page
app.use(express.static(path.join(__dirname, '/frontend/build')))
app.get('*', (req, res) => {
  // logger.info(`Serving frontend index.html: ${req.originalUrl}`);
  res.sendFile(path.resolve(__dirname, 'frontend', 'build', 'index.html'))
});


// app.use(function (err, req, res, next) {
//   // set locals, only providing error in production
//   res.locals.message = err.message;
//   res.locals.error = req.app.get(process.env.NODE_ENV) === "production" ? err : {};

//   logger.error(
//     `${err.status || 500} - ${err.message} - ${req.originalUrl} - ${req.method
//     } - ${req.ip}`
//   );

//   res.status(err.status || 500);
//   res.render("error");
// });

// cron.schedule('* * * * *', async () => {
//   console.log("Cron is Running")
//   try {
//     await main();
//   } catch (error) {
//     logger.logger(error, 'An error occurred in the main function of cron job');
//   }
//   console.log("Cron is Finished")
// });

// cron.schedule('*/20 * * * * *', async () => {
//   console.log("Cron is Running")
//   await main();
//   console.log("Cron is Finished");
// });


app.use(errorHandler);


const port = process.env.NODE_ENV === 'production' ? (process.env.PORT || 5000) : 5000;

app.listen(port, () => console.log(`LifeTime Lotto app started at ${process.env.ASSET_URL}`));